import { db } from './db'
import { buildLines } from './billing'
import type { Bill, Customer, Entry, Payment, Product, Rate } from './types'

/**
 * "Payment Pending" = what the customer still owes:
 *   previous dues + issued bills + deliveries not billed yet - payments received.
 * Deliveries count from the day they are saved, so the owner never has to create a bill first.
 */
export function computeOwed(customers: Customer[], bills: Bill[], payments: Payment[], unbilled: Entry[], rates: Rate[], products: Map<number, Product>): Map<number, number> {
  const byCust = new Map<number, Entry[]>()
  for (const e of unbilled) if (e.status === 'delivered' && e.billId === null) byCust.set(e.customerId, [...(byCust.get(e.customerId) ?? []), e])
  const billed = new Map<number, number>(); const paid = new Map<number, number>()
  for (const b of bills) if (b.status === 'issued') billed.set(b.customerId, (billed.get(b.customerId) ?? 0) + b.totalPaise)
  for (const p of payments) if (!p.voided) paid.set(p.customerId, (paid.get(p.customerId) ?? 0) + p.amountPaise)
  const out = new Map<number, number>()
  for (const c of customers) {
    const un = buildLines(byCust.get(c.id!) ?? [], rates, products).lines.reduce((s, l) => s + l.amountPaise, 0)
    out.set(c.id!, c.openingPaise + (billed.get(c.id!) ?? 0) + un - (paid.get(c.id!) ?? 0))
  }
  return out
}

export async function loadOwed(): Promise<Map<number, number>> {
  const [customers, bills, payments, rates, products, unbilled] = await Promise.all([
    db.customers.toArray(), db.bills.toArray(), db.payments.toArray(), db.rates.toArray(), db.products.toArray(),
    db.entries.filter(e => e.billId === null && e.status === 'delivered').toArray()
  ])
  return computeOwed(customers, bills, payments, unbilled, rates, new Map(products.map(p => [p.id!, p])))
}

export type PayStatus = 'Paid' | 'Part paid' | 'Unpaid'
/** Paid: nothing pending. Part paid: something pending but the customer paid something this month. Unpaid: pending and nothing paid this month. */
export function payStatus(owedPaise: number, paidThisMonthPaise: number): PayStatus {
  if (owedPaise <= 0) return 'Paid'
  return paidThisMonthPaise > 0 ? 'Part paid' : 'Unpaid'
}

/** One customer's Payment Pending (same rule as computeOwed, but only reads that customer's rows). */
export async function customerOwed(customerId: number): Promise<number> {
  const c = await db.customers.get(customerId)
  if (!c) return 0
  const [bills, payments, rates, products, unbilled] = await Promise.all([
    db.bills.where('customerId').equals(customerId).toArray(), db.payments.where('customerId').equals(customerId).toArray(), db.rates.toArray(), db.products.toArray(),
    db.entries.where('[customerId+date]').between([customerId, ''], [customerId, '\uffff']).filter(e => e.billId === null && e.status === 'delivered').toArray()
  ])
  return computeOwed([c], bills, payments, unbilled, rates, new Map(products.map(p => [p.id!, p]))).get(customerId) ?? 0
}
