import type { UnitKey } from './money'

export type CustomerStatus = 'active' | 'paused' | 'inactive'
export interface Customer {
  id?: number
  code: string
  name: string
  mobile: string
  whatsapp: string
  address: string
  area: string
  productId: number
  dailyMl: number
  startDate: string
  status: CustomerStatus
  prefTime: string
  notes: string
  openingPaise: number
  /** Optional customer group. Missing/null = not in any group. */
  groupId?: number | null
  /** Position in the delivery order (lower first). Missing = after the numbered ones, by name. */
  sortOrder?: number
  createdAt: number
}
export interface Group { id?: number; name: string; createdAt: number }
export interface Product { id?: number; name: string; unit: UnitKey; active: boolean; createdAt: number }
/** customerId 0 = product default. Latest effectiveFrom <= date wins. */
export interface Rate { id?: number; productId: number; customerId: number; ratePaise: number; extraRatePaise: number | null; /** What the milk costs you (only on standard rates, customerId 0). Used for profit and loss. */ buyRatePaise?: number | null; effectiveFrom: string; createdAt: number }
export type EntryStatus = 'delivered' | 'skipped'
export interface Entry { id?: number; customerId: number; date: string; productId: number; regularMl: number; extraMl: number; status: EntryStatus; billId: number | null; updatedAt: number }
export interface Pause { id?: number; customerId: number; from: string; to: string | null }
export interface Bill {
  id?: number; number: string; customerId: number; kind: 'daily' | 'monthly' | 'range'
  fromDate: string; toDate: string; subtotalPaise: number; discountPaise: number; totalPaise: number
  deliveredDays: number; skippedDays: number; pausedDays: number; status: 'issued' | 'void'; note: string; createdAt: number
}
export interface BillItem { id?: number; billId: number; productId: number; productName: string; kind: 'regular' | 'extra'; qtyMilli: number; ratePaise: number; milliPerUnit: number; unit: UnitKey; amountPaise: number }
export type PayMethod = 'Cash' | 'UPI' | 'Bank Transfer' | 'Other'
export interface Payment { id?: number; customerId: number; amountPaise: number; date: string; method: PayMethod; reference: string; note: string; voided: boolean; createdAt: number }
export interface Template { id?: number; key: string; name: string; body: string; builtin: boolean }
export interface MessageLog { id?: number; customerId: number; channel: 'whatsapp' | 'sms'; body: string; createdAt: number; status: 'opened' }
export interface Setting { key: string; value: unknown }
