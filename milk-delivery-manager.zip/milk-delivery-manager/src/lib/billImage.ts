import { formatQty, UNITS } from './money'
import { monthLabel, dateLabel } from './dates'
import type { MonthlyRow } from './monthly'
import type { Payment } from './types'
import { formatMoney } from './money'

export interface BillModel {
  shop: string; customer: string; period: string; symbol: string
  lines: { item: string; qty: string; rate: string; amount: string }[]
  discount: string | null; total: string; deliveredDays: number; absentDays: number; absentText: string | null
  payments: { label: string; amount: string }[]; paid: string; pending: string; pendingPaise: number
}

/** The same numbers the Monthly and Bill tabs show, laid out for a bill picture, PDF or message. */
export function buildBillModel(r: MonthlyRow, month: string, payments: Payment[], shop: string, symbol: string): BillModel {
  const m = (p: number) => formatMoney(p, symbol)
  const mine = payments.filter(p => p.customerId === r.customer.id && !p.voided && p.date.slice(0, 7) === month).sort((a, b) => a.date.localeCompare(b.date))
  const paid = mine.reduce((s, p) => s + p.amountPaise, 0)
  return {
    shop, customer: r.customer.name, period: monthLabel(month), symbol,
    lines: r.lines.map(l => ({ item: `${l.productName}${l.kind === 'extra' ? ' (extra)' : ''}`, qty: formatQty(l.qtyMilli, l.unit), rate: `${m(l.ratePaise)}/${UNITS[l.unit].short}`, amount: m(l.amountPaise) })),
    discount: r.discountPaise > 0 ? m(r.discountPaise) : null, total: m(r.amountPaise), deliveredDays: r.delivered, absentDays: r.absent,
    absentText: r.absentDates.length ? `Absent ${r.absentDates.length} day${r.absentDates.length === 1 ? '' : 's'} (${r.absentDates.map(d => dateLabel(d).slice(0, -5)).join(', ')}) - not charged` : null,
    payments: mine.map(p => ({ label: `${dateLabel(p.date).slice(0, -5)} · ${p.method}`, amount: m(p.amountPaise) })), paid: m(paid),
    pending: m(Math.max(0, r.owed)), pendingPaise: Math.max(0, r.owed)
  }
}

/** Plain text for WhatsApp / SMS. One milk per line. */
export function billText(b: BillModel): string {
  const out = [`Hello ${b.customer}, your milk bill for ${b.period}:`]
  if (b.lines.length === 0) out.push('No milk delivered')
  for (const l of b.lines) out.push(`${l.item} ${l.qty} x ${l.rate} = ${l.amount}`)
  if (b.discount) out.push(`Discount: ${b.discount}`)
  out.push(`Total: ${b.total}`)
  if (b.absentText) out.push(b.absentText)
  if (b.payments.length) out.push(`Paid: ${b.paid}`)
  out.push(`Payment Pending: ${b.pending}`)
  out.push(b.shop ? `Thank you. ${b.shop}` : 'Thank you.')
  return out.join('\n')
}

/** Draws the bill as a PNG (works on the phone). Returns null if the browser cannot draw it. */
export async function renderBillImage(b: BillModel, qrDataUrl?: string | null): Promise<Blob | null> {
  if (typeof document === 'undefined') return null
  const W = 720, P = 36
  const font = (w: number, s: number) => `${w} ${s}px Outfit, system-ui, sans-serif`
  try { await Promise.all([document.fonts?.load(font(700, 26)), document.fonts?.load(font(500, 22))]) } catch { /* fonts are optional */ }
  let qr: HTMLImageElement | null = null
  if (qrDataUrl) qr = await new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = qrDataUrl })
  const rows = b.lines.length + b.payments.length
  const H = 330 + rows * 44 + (b.absentText ? 70 : 0) + (b.discount ? 40 : 0) + 190 + (qr ? 230 : 0)
  const c = document.createElement('canvas'); c.width = W; c.height = H
  const x = c.getContext('2d'); if (!x) return null
  x.fillStyle = '#f0f4ff'; x.fillRect(0, 0, W, H)
  const g = x.createLinearGradient(0, 0, W, 170); g.addColorStop(0, '#0d1b2a'); g.addColorStop(0.55, '#1a3a5c'); g.addColorStop(1, '#1a6ef5')
  x.fillStyle = g; x.fillRect(0, 0, W, 170)
  x.fillStyle = '#fff'; x.font = font(800, 38); x.fillText(b.shop || 'Milk Delivery', P, 70)
  x.font = font(500, 24); x.fillStyle = '#bed4f5'; x.fillText(`Bill for ${b.period}`, P, 108)
  x.font = font(700, 28); x.fillStyle = '#fff'; x.fillText(b.customer, P, 148)
  let y = 210
  const right = (t: string, xx: number, yy: number) => { const w = x.measureText(t).width; x.fillText(t, xx - w, yy) }
  x.fillStyle = '#e8f0ff'; x.fillRect(P, y - 30, W - 2 * P, 42)
  x.fillStyle = '#1a6ef5'; x.font = font(700, 20); x.fillText('Item', P + 12, y); right('Quantity', 360, y); right('Rate', 510, y); right('Amount', W - P - 12, y)
  y += 44
  x.fillStyle = '#0f1b2d'
  for (const l of b.lines) { x.font = font(600, 22); x.fillText(l.item, P + 12, y); x.font = font(500, 22); right(l.qty, 360, y); right(l.rate, 510, y); x.font = font(700, 22); right(l.amount, W - P - 12, y); y += 44 }
  if (b.lines.length === 0) { x.font = font(500, 22); x.fillText('No milk delivered', P + 12, y); y += 44 }
  x.strokeStyle = '#d5dff0'; x.beginPath(); x.moveTo(P, y - 22); x.lineTo(W - P, y - 22); x.stroke()
  if (b.discount) { x.font = font(500, 22); x.fillText('Discount', P + 12, y); right(`-${b.discount}`, W - P - 12, y); y += 40 }
  x.font = font(800, 26); x.fillText('Total amount', P + 12, y + 4); right(b.total, W - P - 12, y + 4); y += 52
  if (b.absentText) {
    x.fillStyle = '#fee2e2'; x.fillRect(P, y - 26, W - 2 * P, 54); x.fillStyle = '#dc2626'; x.font = font(600, 19)
    const words = b.absentText.split(' '); let line = ''; let ly = y
    for (const w of words) { if (x.measureText(line + w).width > W - 2 * P - 24) { x.fillText(line, P + 12, ly); line = ''; ly += 24 } line += w + ' ' }
    x.fillText(line, P + 12, ly); y += 70
  }
  x.fillStyle = '#0f1b2d'
  if (b.payments.length) { x.font = font(700, 22); x.fillText('Payments received', P + 12, y); y += 38; for (const p of b.payments) { x.font = font(500, 21); x.fillStyle = '#6b7c93'; x.fillText(p.label, P + 12, y); x.fillStyle = '#16a34a'; x.font = font(700, 21); right(p.amount, W - P - 12, y); y += 40 } }
  x.fillStyle = b.pendingPaise > 0 ? '#dc2626' : '#16a34a'; x.font = font(800, 30); x.fillText('Payment Pending', P + 12, y + 20); right(b.pending, W - P - 12, y + 20); y += 70
  if (qr) { x.fillStyle = '#fff'; x.fillRect(P, y, 190, 190); x.drawImage(qr, P + 8, y + 8, 174, 174); x.fillStyle = '#0f1b2d'; x.font = font(700, 24); x.fillText('Scan to pay', P + 215, y + 70); x.font = font(500, 20); x.fillStyle = '#6b7c93'; x.fillText('UPI', P + 215, y + 104); y += 210 }
  x.fillStyle = '#6b7c93'; x.font = font(500, 19); x.fillText('Thank you', P, H - 30)
  return await new Promise<Blob | null>(res => c.toBlob(bl => res(bl), 'image/png'))
}
