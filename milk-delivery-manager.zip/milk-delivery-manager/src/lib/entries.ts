import { db, AppError } from './db'
import { isValidISO } from './dates'

export interface EntryDraft { customerId: number; productId: number; regularMl: number; extraMl: number; status: 'delivered' | 'skipped' | 'pending' }

/** Saves a day's drafts. One record per customer per date (enforced by a unique index). Billed entries are locked. */
export async function saveEntries(date: string, drafts: EntryDraft[]): Promise<{ saved: number; locked: number }> {
  if (!isValidISO(date)) throw new AppError('Choose a valid date')
  for (const d of drafts) {
    if (!Number.isInteger(d.regularMl) || !Number.isInteger(d.extraMl) || d.regularMl < 0 || d.extraMl < 0 || d.regularMl > 100000 || d.extraMl > 100000) throw new AppError('Quantities must be whole numbers, zero or more')
    if (d.status === 'delivered' && d.regularMl + d.extraMl <= 0) throw new AppError('A delivered entry needs a quantity greater than zero')
  }
  return db.transaction('rw', db.entries, async () => {
    let saved = 0, locked = 0
    for (const d of drafts) {
      const ex = await db.entries.where('[customerId+date+productId]').equals([d.customerId, date, d.productId]).first()
      if (ex?.billId) { locked++; continue }
      if (d.status === 'pending') { if (ex) await db.entries.delete(ex.id!); saved++; continue }
      const row = { customerId: d.customerId, date, productId: d.productId, regularMl: d.status === 'skipped' ? d.regularMl : d.regularMl, extraMl: d.status === 'skipped' ? 0 : d.extraMl, status: d.status, billId: null, updatedAt: Date.now() }
      if (ex) await db.entries.update(ex.id!, row)
      else await db.entries.add(row)
      saved++
    }
    return { saved, locked }
  })
}
