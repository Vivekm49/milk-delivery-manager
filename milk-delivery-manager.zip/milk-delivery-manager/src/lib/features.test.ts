import 'fake-indexeddb/auto'
import Dexie from 'dexie'
import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest'
import { db, MilkDB, ensureSeed, addRate } from './db'
import { eraseAll, exportAll, restoreAll, validateBackup } from './backup'
import { createCustomer, updateCustomer, validateCustomer, createGroup, renameGroup, deleteGroup, setCustomerGroup } from './customers'
import { saveEntries } from './entries'
import { generateBill } from './billing'
import { buildContext, renderTemplate, findUnknownTags, hasPhone, PLACEHOLDERS } from './messages'
import { addDays, todayISO, toISO, monthEnd, addMonths, daysBetween } from './dates'

let cow = 0
const base = (name: string, mobile = '') => ({ name, mobile, whatsapp: '', address: '', area: '', productId: cow, dailyMl: 1000, startDate: '2026-01-01', prefTime: 'Morning', notes: '', openingPaise: 0 })
beforeEach(async () => { await eraseAll(); await ensureSeed(); cow = (await db.products.where('name').equals('Cow Milk').first())!.id! })

describe('phone number is optional', () => {
  it('saves customers without a phone, several of them, and never invents a number', async () => {
    const a = await createCustomer(base('Ramu Kaka'))
    const b = await createCustomer(base('Sita Devi'))
    const rows = await db.customers.toArray()
    expect(rows.length).toBe(2)
    expect(rows.every(r => r.mobile === '')).toBe(true)
    expect(validateCustomer(base('Ramu Kaka')).length).toBe(0)
    expect(validateCustomer(base('Ramu Kaka', '123')).length).toBe(1) // a number that is typed must still be valid
    await updateCustomer(a, { ...base('Ramu Kaka'), mobile: '9876500001' })
    expect((await db.customers.get(a))!.mobile).toBe('9876500001')
    await updateCustomer(a, { ...base('Ramu Kaka'), mobile: '' }) // can also be removed again
    expect((await db.customers.get(a))!.mobile).toBe('')
    expect(b).toBeGreaterThan(a)
  })
  it('phone-dependent actions are off without a number, on with one', async () => {
    const a = await createCustomer(base('No Phone'))
    const b = await createCustomer(base('Has Phone', '9876500002'))
    const ca = (await db.customers.get(a))!, cb = (await db.customers.get(b))!
    expect(hasPhone(ca, 'sms')).toBe(false); expect(hasPhone(ca, 'whatsapp')).toBe(false)
    expect(hasPhone(cb, 'sms')).toBe(true); expect(hasPhone(cb, 'whatsapp')).toBe(true)
    expect(hasPhone({ ...ca, whatsapp: '9876500003' }, 'whatsapp')).toBe(true) // WhatsApp-only number
  })
})

describe('customer groups', () => {
  it('create, rename, move, filter, and delete a group without losing customers or history', async () => {
    await addRate(cow, 0, 6000, null, '2026-01-01')
    const g1 = await createGroup('Morning Route'), g2 = await createGroup('  Evening   Route ')
    expect((await db.groups.get(g2))!.name).toBe('Evening Route')
    await expect(createGroup('morning route')).rejects.toThrow(/already exists/)
    await expect(createGroup('   ')).rejects.toThrow(/group name/)
    await renameGroup(g1, 'Early Route')
    await expect(renameGroup(g1, 'evening route')).rejects.toThrow(/already exists/)
    const c = await createCustomer({ ...base('Grouped One', '9876500010'), groupId: g1 })
    const u = await createCustomer(base('Ungrouped'))
    expect((await db.customers.get(c))!.groupId).toBe(g1)
    expect((await db.customers.get(u))!.groupId ?? null).toBeNull() // customers with no group are fine
    await setCustomerGroup(c, g2)
    expect(await db.customers.where('groupId').equals(g2).count()).toBe(1)
    await expect(setCustomerGroup(c, 9999)).rejects.toThrow(/no longer exists/)
    // history exists, then the group is deleted
    await saveEntries('2026-04-01', [{ customerId: c, productId: cow, regularMl: 1000, extraMl: 0, status: 'delivered' }])
    await generateBill({ customerId: c, kind: 'daily', from: '2026-04-01', to: '2026-04-01' })
    expect(await deleteGroup(g2)).toBe(1)
    const after = (await db.customers.get(c))!
    expect(after.groupId ?? null).toBeNull()
    expect(after.name).toBe('Grouped One')
    expect(await db.entries.count()).toBe(1); expect(await db.bills.count()).toBe(1)
    expect(await db.groups.count()).toBe(1)
  })
  it('group assignments survive backup and restore, and old backups without groups still load', async () => {
    const g = await createGroup('Route A')
    const c = await createCustomer({ ...base('Persist', '9876500011'), groupId: g })
    const backup = JSON.parse(JSON.stringify(await exportAll()))
    await eraseAll(); await restoreAll(backup)
    expect((await db.customers.get(c))!.groupId).toBe(g)
    expect((await db.groups.get(g))!.name).toBe('Route A')
    const old = JSON.parse(JSON.stringify(backup)); delete old.data.groups; old.data.customers.forEach((x: any) => delete x.groupId)
    expect(() => validateBackup(old)).not.toThrow()
    await restoreAll(old)
    expect(await db.groups.count()).toBe(0); expect(await db.customers.count()).toBe(1)
  })
  it('upgrades a database from the previous version (v2) to groups (v3) without touching existing records', async () => {
    const name = 'mig-v2-to-v3'
    const old = new Dexie(name)
    old.version(1).stores({ customers: '++id, code, name, mobile, area, status, productId', products: '++id, name, active', rates: '++id, productId, customerId, effectiveFrom, [productId+customerId]', entries: '++id, &[customerId+date], date, billId, productId', pauses: '++id, customerId', bills: '++id, customerId, fromDate, status, number', billItems: '++id, billId', payments: '++id, customerId, date', templates: '++id, key', messageLog: '++id, customerId, createdAt', settings: 'key' })
    old.version(2).stores({ entries: '++id, &[customerId+date+productId], [customerId+date], date, billId, productId' })
    await old.open()
    await old.table('customers').add({ code: 'C001', name: 'Old Customer', mobile: '9876500012', whatsapp: '', address: '', area: '', productId: 1, dailyMl: 1000, startDate: '2026-01-01', status: 'active', prefTime: 'Morning', notes: '', openingPaise: 5000, createdAt: 1 })
    await old.table('payments').add({ customerId: 1, amountPaise: 1000, date: '2026-02-01', method: 'Cash', reference: '', note: '', voided: false, createdAt: 1 })
    old.close()
    const upgraded = new MilkDB(name)
    await upgraded.open()
    const c = (await upgraded.customers.get(1))!
    expect(c.name).toBe('Old Customer'); expect(c.openingPaise).toBe(5000); expect(c.groupId ?? null).toBeNull()
    expect(await upgraded.payments.count()).toBe(1)
    const gid = await upgraded.groups.add({ name: 'New Group', createdAt: 2 })
    await upgraded.customers.update(1, { groupId: gid })
    expect(await upgraded.customers.where('groupId').equals(gid).count()).toBe(1)
    upgraded.close()
  })
})

describe('dates use the local calendar day', () => {
  afterEach(() => vi.useRealTimers())
  it('addDays/addMonths handle month, year and leap-year changes', () => {
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01'); expect(addDays('2027-01-01', -1)).toBe('2026-12-31')
    expect(addDays('2028-02-28', 1)).toBe('2028-02-29'); expect(addDays('2027-02-28', 1)).toBe('2027-03-01')
    expect(addDays('2026-03-01', -1)).toBe('2026-02-28'); expect(monthEnd('2028-02')).toBe('2028-02-29')
    expect(addMonths('2026-12', 1)).toBe('2027-01'); expect(addMonths('2026-01', -1)).toBe('2025-12')
    expect(daysBetween('2026-12-30', '2027-01-02')).toEqual(['2026-12-30', '2026-12-31', '2027-01-01', '2027-01-02'])
  })
  it('todayISO matches the device calendar date, not the UTC date (checked around midnight)', () => {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone
    const local = (d: Date) => new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d)
    vi.useFakeTimers()
    for (const iso of ['2026-10-16T18:45:00Z', '2026-10-16T19:00:00Z', '2026-10-16T23:59:00Z', '2026-10-17T00:01:00Z', '2026-12-31T23:30:00Z', '2026-03-08T07:30:00Z']) {
      vi.setSystemTime(new Date(iso))
      expect(todayISO()).toBe(local(new Date(iso)))
      expect(toISO(new Date())).toBe(local(new Date(iso)))
    }
  })
})

describe('new message tags: Total Quantity and Current Month Amount', () => {
  it('are in the tag list and use the customer\'s own entries for the current month', async () => {
    expect(PLACEHOLDERS).toContain('Total Quantity'); expect(PLACEHOLDERS).toContain('Current Month Amount')
    await addRate(cow, 0, 6000, 6500, '2026-01-01')
    const a = await createCustomer(base('Tag One', '9876500020'))
    const b = await createCustomer(base('Tag Two', '9876500021'))
    const thisMonth = todayISO().slice(0, 7), lastMonth = addMonths(thisMonth, -1)
    await saveEntries(`${thisMonth}-01`, [{ customerId: a, productId: cow, regularMl: 1000, extraMl: 500, status: 'delivered' }])
    await saveEntries(`${thisMonth}-02`, [{ customerId: a, productId: cow, regularMl: 1000, extraMl: 0, status: 'delivered' }, { customerId: b, productId: cow, regularMl: 5000, extraMl: 0, status: 'delivered' }])
    await saveEntries(`${thisMonth}-03`, [{ customerId: a, productId: cow, regularMl: 1000, extraMl: 0, status: 'skipped' }]) // skipped is not counted
    await saveEntries(`${lastMonth}-15`, [{ customerId: a, productId: cow, regularMl: 9000, extraMl: 0, status: 'delivered' }]) // other month is not counted
    const ca = (await db.customers.get(a))!, cb = (await db.customers.get(b))!
    const ctxA = await buildContext(ca, thisMonth), ctxB = await buildContext(cb, thisMonth)
    expect(ctxA['Total Quantity']).toBe('2.5 L'); expect(ctxA['Current Month Amount']).toBe('152.50') // 2 L x 60 + 0.5 L extra x 65
    expect(ctxB['Total Quantity']).toBe('5 L'); expect(ctxB['Current Month Amount']).toBe('300')
  })
  it('render in previews and final messages, accept the {{short_form}}, and never leave a raw tag behind', async () => {
    await addRate(cow, 0, 6000, null, '2026-01-01')
    const c = await createCustomer(base('Nobody Yet', '9876500022'))
    const ctx = await buildContext((await db.customers.get(c))!, todayISO().slice(0, 7))
    expect(ctx['Total Quantity']).toBe('0 L'); expect(ctx['Current Month Amount']).toBe('0') // no entries this month
    const body = 'Hi {Customer Name}, total {Total Quantity}, amount ₹{Current Month Amount}. {{total_quantity}} / {{current_month_amount}} {oops}'
    const out = renderTemplate(body, ctx)
    expect(out).toBe('Hi Nobody Yet, total 0 L, amount ₹0. 0 L / 0')
    expect(out).not.toMatch(/[{}]/)
    expect(findUnknownTags(body)).toEqual(['{oops}'])
    expect(findUnknownTags('{Total Quantity} {{current_month_amount}} {Customer Name}')).toEqual([])
  })
})
