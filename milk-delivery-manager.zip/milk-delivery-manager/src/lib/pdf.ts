import { Capacitor } from '@capacitor/core'
import { Filesystem, Directory } from '@capacitor/filesystem'
import { Share } from '@capacitor/share'
import { NOTO_REGULAR, NOTO_BOLD } from './pdfFonts'

export interface PdfColumn { header: string; align?: 'left' | 'right' | 'center'; weight?: number }
export interface PdfReport {
  type: 'Daily' | 'Monthly' | 'Customer' | 'Bill'
  title: string
  business: string
  period: string
  generated: string // already formatted date
  currency: string
  summary: { label: string; value: string }[]
  columns: PdfColumn[]
  rows: string[][]
  totals?: string[]
  note?: string
  emptyText?: string
}

const BLUE: [number, number, number] = [31, 111, 235]
const INK: [number, number, number] = [14, 27, 46]
const MUTED: [number, number, number] = [90, 107, 128]
const LINE: [number, number, number] = [220, 230, 241]
const SOFT: [number, number, number] = [232, 241, 255]

/** Money for PDFs: always two decimals so columns line up. Falls back to "Rs." if the symbol is not in the PDF font. */
export function pdfMoney(paise: number, symbol: string): string {
  const sym = /^[\u0020-\u007E\u00A0-\u017F\u20B9]{1,4}$/.test(symbol) ? symbol : 'Rs.'
  const neg = paise < 0 ? '-' : ''
  const a = Math.abs(paise)
  return `${neg}${sym} ${Math.floor(a / 100).toLocaleString('en-IN')}.${String(a % 100).padStart(2, '0')}`
}

export function pdfFileName(type: string, isoDate: string) { return `Milk_Delivery_${type}_Report_${isoDate}.pdf` }

// Text the embedded font cannot draw (for example Hindi names) is drawn by the phone's own fonts and placed as a picture in that cell.
const needsImage = (s: string) => /[^\u0000-\u024F\u2010-\u203A\u20B9]/.test(s)
function textPicture(text: string, mmWidth: number, fontPt: number, bold: boolean): { data: string; w: number; h: number } | null {
  try {
    if (typeof document === 'undefined') return null
    const scale = 5
    const px = fontPt * 1.3333 * scale
    const c = document.createElement('canvas')
    const ctx = c.getContext('2d')
    if (!ctx) return null
    ctx.font = `${bold ? '700 ' : ''}${px}px "Noto Sans", "Noto Sans Devanagari", "Noto Sans Bengali", system-ui, sans-serif`
    const wpx = Math.ceil(ctx.measureText(text).width) + 4
    c.width = wpx; c.height = Math.ceil(px * 1.5)
    ctx.font = `${bold ? '700 ' : ''}${px}px "Noto Sans", "Noto Sans Devanagari", "Noto Sans Bengali", system-ui, sans-serif`
    ctx.fillStyle = '#0e1b2e'; ctx.textBaseline = 'top'
    ctx.fillText(text, 2, px * 0.15)
    let w = (wpx / scale) * 0.2646, h = (c.height / scale) * 0.2646
    if (w > mmWidth) { h = (h * mmWidth) / w; w = mmWidth }
    return { data: c.toDataURL('image/png'), w, h }
  } catch { return null }
}

export async function buildReportPdf(r: PdfReport, opts: { compress?: boolean } = {}) {
  const [{ jsPDF }, autoTableMod] = await Promise.all([import('jspdf'), import('jspdf-autotable')])
  const autoTable = (autoTableMod as any).default ?? autoTableMod
  const landscape = r.columns.length >= 7
  const doc = new jsPDF({ orientation: landscape ? 'landscape' : 'portrait', unit: 'mm', format: 'a4', compress: opts.compress ?? true })
  doc.addFileToVFS('NotoSans-Regular.ttf', NOTO_REGULAR); doc.addFont('NotoSans-Regular.ttf', 'NotoSans', 'normal')
  doc.addFileToVFS('NotoSans-Bold.ttf', NOTO_BOLD); doc.addFont('NotoSans-Bold.ttf', 'NotoSans', 'bold')
  doc.setProperties({ title: `${r.title} - ${r.period}`, subject: 'Milk delivery report', author: r.business || 'Milk Delivery Manager', creator: 'Milk Delivery Manager' })

  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), M = 12
  const usable = W - M * 2

  // ----- title block (first page)
  doc.setFont('NotoSans', 'bold'); doc.setFontSize(10); doc.setTextColor(...BLUE)
  doc.text(r.business || 'Milk Delivery Manager', M, M + 4)
  doc.setFontSize(18); doc.setTextColor(...INK)
  doc.text(r.title, M, M + 12)
  doc.setFont('NotoSans', 'normal'); doc.setFontSize(9.5); doc.setTextColor(...MUTED)
  doc.text(`Period: ${r.period}`, M, M + 18)
  doc.text(`Generated on: ${r.generated}`, W - M, M + 18, { align: 'right' })
  doc.setDrawColor(...BLUE); doc.setLineWidth(0.6); doc.line(M, M + 21, W - M, M + 21)
  let y = M + 27

  // ----- summary cards
  if (r.summary.length) {
    const cols = Math.min(r.summary.length, landscape ? 5 : 3), gap = 3
    const bw = (usable - gap * (cols - 1)) / cols, bh = 15
    r.summary.forEach((s, i) => {
      const cx = M + (i % cols) * (bw + gap), cy = y + Math.floor(i / cols) * (bh + gap)
      doc.setFillColor(...SOFT); doc.setDrawColor(...LINE); doc.setLineWidth(0.2); doc.roundedRect(cx, cy, bw, bh, 2, 2, 'FD')
      doc.setFont('NotoSans', 'normal'); doc.setFontSize(8); doc.setTextColor(...MUTED)
      doc.text(doc.splitTextToSize(s.label, bw - 6)[0], cx + 3, cy + 5.2)
      doc.setFont('NotoSans', 'bold'); doc.setFontSize(11); doc.setTextColor(...INK)
      const v = doc.splitTextToSize(s.value, bw - 6)[0]
      doc.text(v, cx + 3, cy + 11.5)
    })
    y += Math.ceil(r.summary.length / cols) * (bh + gap) + 3
  }

  // ----- table
  const totalWeight = r.columns.reduce((s, c) => s + (c.weight ?? 1), 0)
  const columnStyles: Record<number, any> = {}
  r.columns.forEach((c, i) => { columnStyles[i] = { cellWidth: (usable * (c.weight ?? 1)) / totalWeight, halign: c.align ?? 'left' } })
  const flagged = new Set<string>()
  if (r.rows.length === 0) {
    doc.setFont('NotoSans', 'normal'); doc.setFontSize(11); doc.setTextColor(...MUTED)
    doc.text(r.emptyText ?? 'No records found for this period.', W / 2, y + 14, { align: 'center' })
  } else {
    autoTable(doc, {
      startY: y, margin: { left: M, right: M, top: M + 10, bottom: 16 },
      head: [r.columns.map(c => c.header)], body: r.rows, foot: r.totals ? [r.totals] : undefined,
      showHead: 'everyPage', showFoot: 'lastPage', theme: 'grid', rowPageBreak: 'avoid',
      styles: { font: 'NotoSans', fontSize: 8.5, cellPadding: { top: 2, bottom: 2, left: 2, right: 2 }, lineColor: LINE, lineWidth: 0.2, textColor: INK, overflow: 'linebreak', valign: 'middle' },
      headStyles: { fillColor: BLUE, textColor: 255, fontStyle: 'bold', halign: 'left' },
      footStyles: { fillColor: SOFT, textColor: INK, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [255, 255, 255] }, columnStyles,
      didParseCell: (d: any) => {
        if (d.section === 'head') d.cell.styles.halign = r.columns[d.column.index]?.align ?? 'left'
        if (d.section === 'foot') d.cell.styles.halign = r.columns[d.column.index]?.align ?? 'left'
        if (d.section === 'body') {
          const t = (d.cell.raw as string) ?? ''
          if (needsImage(t)) { flagged.add(`${d.row.index}:${d.column.index}`); d.cell.styles.textColor = [255, 255, 255] }
        }
      },
      didDrawCell: (d: any) => {
        if (d.section !== 'body' || !flagged.has(`${d.row.index}:${d.column.index}`)) return
        const pic = textPicture(String(d.cell.raw), d.cell.width - 4, 8.5, false)
        if (pic) { doc.setFillColor(255, 255, 255); doc.rect(d.cell.x + 0.3, d.cell.y + 0.3, d.cell.width - 0.6, d.cell.height - 0.6, 'F'); doc.addImage(pic.data, 'PNG', d.cell.x + 2, d.cell.y + (d.cell.height - pic.h) / 2, pic.w, pic.h) }
      }
    })
  }
  if (r.note) {
    const endY = ((doc as any).lastAutoTable?.finalY ?? y) + 6
    doc.setFont('NotoSans', 'normal'); doc.setFontSize(8); doc.setTextColor(...MUTED)
    const lines = doc.splitTextToSize(r.note, usable)
    if (endY + lines.length * 4 > H - 16) doc.addPage()
    doc.text(lines, M, endY > H - 16 ? M + 6 : endY)
  }

  // ----- running header (pages after the first) and footer with page numbers
  const n = doc.getNumberOfPages()
  for (let i = 1; i <= n; i++) {
    doc.setPage(i)
    if (i > 1) {
      doc.setFont('NotoSans', 'bold'); doc.setFontSize(8.5); doc.setTextColor(...BLUE)
      doc.text(r.business || 'Milk Delivery Manager', M, M + 2)
      doc.setFont('NotoSans', 'normal'); doc.setTextColor(...MUTED)
      doc.text(`${r.title} | ${r.period}`, W - M, M + 2, { align: 'right' })
      doc.setDrawColor(...LINE); doc.setLineWidth(0.3); doc.line(M, M + 4, W - M, M + 4)
    }
    doc.setDrawColor(...LINE); doc.setLineWidth(0.3); doc.line(M, H - 11, W - M, H - 11)
    doc.setFont('NotoSans', 'normal'); doc.setFontSize(8); doc.setTextColor(...MUTED)
    doc.text('Milk Delivery Manager', M, H - 6.5)
    doc.text(`Page ${i} of ${n}`, W - M, H - 6.5, { align: 'right' })
  }
  return { doc, pages: n, bytes: new Uint8Array(doc.output('arraybuffer') as ArrayBuffer) }
}

function toBase64(bytes: Uint8Array): string {
  let s = ''
  const CH = 0x8000
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode(...bytes.subarray(i, i + CH))
  return btoa(s)
}

/** Builds the PDF and either opens the share sheet (Android) or downloads it (browser). */
export async function exportReportPdf(r: PdfReport, isoDate: string, fileName?: string): Promise<'shared' | 'downloaded'> {
  const { bytes } = await buildReportPdf(r)
  const name = fileName ?? pdfFileName(r.type, isoDate)
  if (Capacitor.isNativePlatform()) {
    const res = await Filesystem.writeFile({ path: name, data: toBase64(bytes), directory: Directory.Cache })
    await Share.share({ title: name, url: res.uri, dialogTitle: 'Open, print or share the report' })
    return 'shared'
  }
  const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type: 'application/pdf' }))
  const a = document.createElement('a'); a.href = url; a.download = name
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10000)
  return 'downloaded'
}
