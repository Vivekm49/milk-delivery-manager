import { pdfMoney, type PdfReport } from './pdf'
import { monthLabel, todayISO, dateLabel } from './dates'
import type { MonthlyData } from './monthly'
import type { BillModel } from './billImage'
import { formatMoney } from './money'

/** One PDF with every customer's month: quantity, Absent days, amount, paid and Payment Pending. */
export function allBillsReport(d: MonthlyData, shop: string, symbol: string): PdfReport {
  const m = (p: number) => pdfMoney(p, symbol)
  const rows = d.rows.filter(r => r.amountPaise > 0 || r.owed !== 0 || r.absent > 0)
  return {
    type: 'Bill', title: 'Monthly Bills', business: shop, period: monthLabel(d.month), generated: dateLabel(todayISO()), currency: symbol,
    summary: [{ label: 'Customers', value: String(rows.length) }, { label: 'Monthly Amount', value: m(d.totals.amountPaise) }, { label: 'Collected', value: m(d.totals.collectedPaise) }, { label: 'Payment Pending', value: m(d.totals.pendingPaise) }, { label: 'Absent days', value: String(d.totals.absentDays) }],
    columns: [{ header: 'Customer', weight: 3 }, { header: 'Total Quantity', align: 'right', weight: 2 }, { header: 'Absent', align: 'right', weight: 1 }, { header: 'Monthly Amount', align: 'right', weight: 2.3 }, { header: 'Paid', align: 'right', weight: 2.2 }, { header: 'Payment Pending', align: 'right', weight: 2.4 }, { header: 'Status', weight: 1.8 }],
    rows: rows.map(r => [r.customer.name, r.qtyText, String(r.absent), m(r.amountPaise), m(r.paidThisMonth), m(Math.max(0, r.owed)), r.status]),
    totals: ['Total', d.totals.quantity, String(d.totals.absentDays), m(d.totals.amountPaise), m(d.totals.collectedPaise), m(d.totals.pendingPaise), ''],
    emptyText: 'No bills for this month.'
  }
}

/** One customer's bill as a PDF. */
export function customerBillReport(b: BillModel, month: string): PdfReport {
  const plainMoney = (s: string) => s.replace(b.symbol, '').trim()
  const sym = b.symbol
  const m = (s: string) => `${/^[\u0020-\u007E\u20B9]{1,4}$/.test(sym) ? sym : 'Rs.'} ${plainMoney(s)}`
  return {
    type: 'Bill', title: `Bill - ${b.customer}`, business: b.shop, period: monthLabel(month), generated: dateLabel(todayISO()), currency: sym,
    summary: [{ label: 'Total amount', value: m(b.total) }, { label: 'Paid', value: m(b.paid) }, { label: 'Payment Pending', value: m(b.pending) }, { label: 'Delivered days', value: String(b.deliveredDays) }, { label: 'Absent days', value: String(b.absentDays) }],
    columns: [{ header: 'Item', weight: 3 }, { header: 'Quantity', align: 'right', weight: 2 }, { header: 'Rate', align: 'right', weight: 2 }, { header: 'Amount', align: 'right', weight: 2.4 }],
    rows: b.lines.map(l => [l.item, l.qty, m(l.rate.split('/')[0]) + '/' + l.rate.split('/')[1], m(l.amount)]),
    totals: ['Total amount', '', '', m(b.total)],
    note: [b.discount ? `Discount: ${m(b.discount)}` : '', b.absentText ?? ''].filter(Boolean).join('  |  ') || undefined,
    emptyText: 'No milk delivered this month.'
  }
}
export { formatMoney }
