import 'fake-indexeddb/auto'
import { describe, it, expect, beforeEach } from 'vitest'
import Dexie from 'dexie'
import { db, MilkDB, ensureSeed, addRate, resolveBuyRate } from './db'
import { createCustomer, setCustomerStatus, sortCustomers, moveCustomer, type CustomerInput } from './customers'
import { saveEntries } from './entries'
import { generateBill, recordPayment } from './billing'
import { dayStatuses, dayCounts } from './absent'
import { loadOwed, payStatus, customerOwed } from './owed'
import { loadMonthly } from './monthly'
import { loadProfit } from './profit'
import { buildContext, renderTemplate, findUnknownTags, productTags } from './messages'
import { eraseAll } from './backup'

let cow = 0, buf = 0, curd = 0
const base = (name: string, mobile = ''): CustomerInput => ({ name, mobile, whatsapp: '', address: '', area: '', productId: cow, dailyMl: 1000, startDate: '2026-01-01', prefTime: 'Morning', notes: '', openingPaise: 0 })
const del = (customerId: number, productId: number, ml: number, extra = 0) => ({ customerId, productId, regularMl: ml, extraMl: extra, status: 'delivered' as const })
const abs = (customerId: number, productId: number) => ({ customerId, productId, regularMl: 1000, extraMl: 0, status: 'skipped' as const })

beforeEach(async () => {
  await eraseAll(); await ensureSeed()
  const by = async (n: string) => (await db.products.where('name').equals(n).first())!.id!
  cow = await by('Cow Milk'); buf = await by('Buffalo Milk'); curd = await by('Curd')
  await addRate(cow, 0, 6000, 6500, '2026-01-01', 4800)
  await addRate(buf, 0, 7000, null, '2026-01-01', 5600)
  await addRate(curd, 0, 9000, null, '2026-01-01')
})

describe('Absent shows properly', () => {
  it('a day is Absent only when marked Absent; quantity 0 or no entry is never Absent', async () => {
    const id = await createCustomer(base('Rahul Sharma'))
    await saveEntries('2026-10-06', [abs(id, cow)])
    await saveEntries('2026-10-07', [del(id, cow, 1000)])
    await saveEntries('2026-10-08', [abs(id, cow), del(id, buf, 1000)]) // one milk absent, another delivered -> a delivered day
    await setCustomerStatus(id, 'paused', '2026-10-10'); await setCustomerStatus(id, 'active', '2026-10-12')
    const c = (await db.customers.get(id))!
    const map = dayStatuses(await db.entries.toArray(), await db.pauses.toArray(), c, '2026-10')
    expect(map.get('2026-10-06')).toBe('absent'); expect(map.get('2026-10-07')).toBe('delivered'); expect(map.get('2026-10-08')).toBe('delivered')
    expect(map.get('2026-10-09')).toBe('none'); expect(map.get('2026-10-10')).toBe('paused'); expect(map.get('2026-10-12')).toBe('none')
    expect(dayCounts(map)).toMatchObject({ delivered: 2, absent: 1, paused: 2, absentDates: ['2026-10-06'] })
  })
  it('Monthly rows, bill and totals all report the same Absent days', async () => {
    const id = await createCustomer(base('Rahul Sharma'))
    for (const d of ['2026-10-01', '2026-10-02', '2026-10-03']) await saveEntries(d, [del(id, cow, 1000)])
    await saveEntries('2026-10-04', [abs(id, cow)]); await saveEntries('2026-10-05', [abs(id, cow)])
    const m = await loadMonthly('2026-10')
    expect(m.rows[0]).toMatchObject({ delivered: 3, absent: 2, absentDates: ['2026-10-04', '2026-10-05'], amountPaise: 18000 })
    expect(m.totals.absentDays).toBe(2); expect(m.totals.absentCustomers).toBe(1)
    const bid = await generateBill({ customerId: id, kind: 'monthly', from: '2026-10-01', to: '2026-10-31' })
    expect((await db.bills.get(bid))!.skippedDays).toBe(2)
  })
})

describe('Payment Pending and Paid / Part paid / Unpaid', () => {
  it('counts deliveries as soon as they are saved, before any bill is made', async () => {
    const id = await createCustomer(base('Rahul Sharma'))
    await saveEntries('2026-10-01', [del(id, cow, 1000)])
    expect(await customerOwed(id)).toBe(6000)
    await recordPayment({ customerId: id, amountPaise: 2000, date: '2026-10-02', method: 'UPI' })
    expect(await customerOwed(id)).toBe(4000)
    await generateBill({ customerId: id, kind: 'monthly', from: '2026-10-01', to: '2026-10-31' }) // billing does not change what is owed
    expect(await customerOwed(id)).toBe(4000)
    expect((await loadOwed()).get(id)).toBe(4000)
  })
  it('tags: Paid / Part paid / Unpaid', async () => {
    expect(payStatus(0, 0)).toBe('Paid'); expect(payStatus(-500, 0)).toBe('Paid')
    expect(payStatus(500, 1000)).toBe('Part paid'); expect(payStatus(500, 0)).toBe('Unpaid')
    const a = await createCustomer(base('Amit Kumar')), b = await createCustomer(base('Suresh Patel')), c = await createCustomer(base('Meena Devi'))
    for (const id of [a, b, c]) await saveEntries('2026-10-01', [del(id, cow, 1000)])
    await recordPayment({ customerId: a, amountPaise: 6000, date: '2026-10-03', method: 'Cash' })
    await recordPayment({ customerId: c, amountPaise: 1000, date: '2026-10-03', method: 'Cash' })
    const rows = (await loadMonthly('2026-10')).rows
    expect(Object.fromEntries(rows.map(r => [r.customer.name, r.status]))).toEqual({ 'Amit Kumar': 'Paid', 'Suresh Patel': 'Unpaid', 'Meena Devi': 'Part paid' })
  })
})

describe('Profit and loss', () => {
  it('profit = sold - bought, per milk, using the rate of each day', async () => {
    const id = await createCustomer(base('Rahul Sharma'))
    await saveEntries('2026-10-01', [del(id, cow, 10000), del(id, buf, 2000)])
    await saveEntries('2026-10-02', [del(id, cow, 10000, 5000)])
    const p = await loadProfit('2026-10')
    const cowRow = p.rows.find(r => r.name === 'Cow Milk')!
    expect(cowRow.qtyMilli).toBe(25000); expect(cowRow.revenue).toBe(20 * 6000 + 5 * 6500); expect(cowRow.cost).toBe(25 * 4800); expect(cowRow.profit).toBe(152500 - 120000)
    expect(cowRow.perUnit).toBe(1300)
    const bufRow = p.rows.find(r => r.name === 'Buffalo Milk')!
    expect(bufRow.profit).toBe(2 * 7000 - 2 * 5600)
    expect(p.net).toBe(cowRow.profit + bufRow.profit); expect(p.missingBuy).toEqual([])
  })
  it('a milk with no buy rate is flagged, not counted as free', async () => {
    const id = await createCustomer(base('Rahul Sharma'))
    await saveEntries('2026-10-01', [del(id, curd, 1000)])
    const p = await loadProfit('2026-10')
    expect(p.missingBuy).toEqual(['Curd']); expect(p.rows[0].perUnit).toBeNull()
  })
  it('buy rate keeps history by date', async () => {
    await addRate(cow, 0, 6000, 6500, '2026-10-15', 5000)
    const rates = await db.rates.toArray()
    expect(resolveBuyRate(rates, cow, '2026-10-14')).toBe(4800); expect(resolveBuyRate(rates, cow, '2026-10-15')).toBe(5000)
  })
})

describe('Messages with every milk type', () => {
  it('{Milk Details} lists each milk on its own line; per-milk tags work; line breaks stay', async () => {
    const id = await createCustomer(base('Ramesh Gupta', '9812345678'))
    for (let d = 1; d <= 12; d++) await saveEntries(`2026-10-${String(d).padStart(2, '0')}`, [del(id, cow, 1000)])
    for (let d = 1; d <= 8; d++) await saveEntries(`2026-10-${String(d).padStart(2, '0')}`, [del(id, buf, 1000)])
    await saveEntries('2026-10-01', [del(id, curd, 2000)])
    const c = (await db.customers.get(id))!
    const ctx = await buildContext(c, '2026-10', '2026-10-05')
    const out = renderTemplate('Hello {Customer Name}, details for {Month}:\n{Milk Details}\nBuffalo: {Buffalo Milk Quantity} (₹{Buffalo Milk Amount}) at {Buffalo Milk Rate}. Curd {Curd Quantity}.', ctx)
    expect(out).toBe('Hello Ramesh Gupta, details for October 2026:\nBuffalo Milk 8 L x ₹70 = ₹560\nCow Milk 12 L x ₹60 = ₹720\nCurd 2 kg x ₹90 = ₹180\nBuffalo: 8 L (₹560) at 70/L. Curd 2 kg.')
    expect(renderTemplate('{Today Details}', ctx)).toBe('Buffalo Milk 1 L, Cow Milk 1 L')
  })
  it('handles one milk, no milk, and a milk the customer never took', async () => {
    const a = await createCustomer(base('Amit Kumar')), b = await createCustomer(base('Suresh Patel'))
    await saveEntries('2026-10-01', [del(a, cow, 2000)])
    const ca = await buildContext((await db.customers.get(a))!, '2026-10', '2026-10-05')
    expect(renderTemplate('{Milk Details}', ca)).toBe('Cow Milk 2 L x ₹60 = ₹120')
    expect(renderTemplate('Curd {Curd Quantity} (₹{Curd Amount})', ca)).toBe('Curd 0 kg (₹0)')
    const cb = await buildContext((await db.customers.get(b))!, '2026-10', '2026-10-05')
    expect(renderTemplate('{Milk Details}|{Today Details}', cb)).toBe('No milk delivered|No delivery today')
  })
  it('knows the product tags, so only real typos are reported', async () => {
    const products = await db.products.toArray()
    expect(productTags(products).find(x => x.product.name === 'Curd')!.tags).toEqual(['Curd Quantity', 'Curd Amount', 'Curd Rate'])
    expect(findUnknownTags('{Curd Quantity} {Milk Details} {Cow Milk Amount} {Curd Qty}', products)).toEqual(['{Curd Qty}'])
    const id = await db.products.add({ name: 'Ghee', unit: 'kg', active: true, createdAt: 1 })
    expect(findUnknownTags('{Ghee Amount}', await db.products.toArray())).toEqual([])
    expect(id).toBeGreaterThan(0)
  })
  it('{Balance} is the Payment Pending amount', async () => {
    const id = await createCustomer(base('Rahul Sharma'))
    await saveEntries('2026-10-01', [del(id, cow, 1000)])
    const ctx = await buildContext((await db.customers.get(id))!, '2026-10', '2026-10-05')
    expect(renderTemplate('Pending ₹{Balance}', ctx)).toBe('Pending ₹60')
  })
})

describe('delivery order and upgrade', () => {
  it('moves customers up and down and keeps the order', async () => {
    const a = await createCustomer(base('Anil')), b = await createCustomer(base('Bhola')), c = await createCustomer(base('Chandu'))
    expect(sortCustomers(await db.customers.toArray()).map(x => x.name)).toEqual(['Anil', 'Bhola', 'Chandu'])
    await moveCustomer(c, -1); await moveCustomer(c, -1)
    expect(sortCustomers(await db.customers.toArray()).map(x => x.name)).toEqual(['Chandu', 'Anil', 'Bhola'])
    await moveCustomer(c, -1) // already first: nothing happens
    expect(sortCustomers(await db.customers.toArray()).map(x => x.name)).toEqual(['Chandu', 'Anil', 'Bhola'])
    expect(a).not.toBe(b)
  })
  it('upgrades a v3 database (groups, no order, no buy rate) without losing anything', async () => {
    const name = 'mig-v3'
    const old = new Dexie(name)
    old.version(1).stores({ customers: '++id, code, name, mobile, area, status, productId', products: '++id, name, active', rates: '++id, productId, customerId, effectiveFrom, [productId+customerId]', entries: '++id, &[customerId+date], date, billId, productId', pauses: '++id, customerId', bills: '++id, customerId, fromDate, status, number', billItems: '++id, billId', payments: '++id, customerId, date', templates: '++id, key', messageLog: '++id, customerId, createdAt', settings: 'key' })
    old.version(2).stores({ entries: '++id, &[customerId+date+productId], [customerId+date], date, billId, productId' })
    old.version(3).stores({ groups: '++id, &name', customers: '++id, code, name, mobile, area, status, productId, groupId' })
    await old.open()
    await old.table('customers').add({ code: 'C001', name: 'Old Customer', mobile: '', whatsapp: '', address: '', area: '', productId: 1, dailyMl: 1000, startDate: '2026-01-01', status: 'active', prefTime: '', notes: '', openingPaise: 500, groupId: 1, createdAt: 1 })
    await old.table('groups').add({ name: 'Morning', createdAt: 1 })
    await old.table('rates').add({ productId: 1, customerId: 0, ratePaise: 6000, extraRatePaise: null, effectiveFrom: '2026-01-01', createdAt: 1 })
    old.close()
    const up = new MilkDB(name); await up.open()
    const c = (await up.customers.toArray())[0]
    expect(c).toMatchObject({ name: 'Old Customer', openingPaise: 500, groupId: 1 }); expect(c.sortOrder).toBeUndefined()
    expect(await up.groups.count()).toBe(1); expect((await up.rates.toArray())[0].buyRatePaise).toBeUndefined()
    await up.rates.add({ productId: 1, customerId: 0, ratePaise: 6100, extraRatePaise: null, buyRatePaise: 4800, effectiveFrom: '2026-02-01', createdAt: 2 })
    up.close()
  })
})
