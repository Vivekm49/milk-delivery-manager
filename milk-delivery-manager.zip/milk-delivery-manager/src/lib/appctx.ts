import { createContext, useContext } from 'react'
import { currentMonth } from './dates'

export interface AppCtxValue { month: string; setMonth: (m: string) => void; search: string; setSearch: (s: string) => void }
export const AppCtx = createContext<AppCtxValue>({ month: currentMonth(), setMonth: () => {}, search: '', setSearch: () => {} })
export const useApp = () => useContext(AppCtx)

/** What the top bar shows on each screen: the month selector and/or the search box. */
export function headerMeta(route: string[]): { month: boolean; search: string | null } {
  const [p, a] = route
  switch (p) {
    case 'dashboard': case '': return { month: true, search: 'Search customer...' }
    case 'customers': return a === 'new' || (a && a !== 'groups') ? { month: false, search: null } : { month: false, search: 'Search name, phone, ID or area' }
    case 'entry': return { month: false, search: 'Search customer' }
    case 'monthly': return { month: true, search: 'Search customer' }
    case 'billing': return a === 'new' || a === 'view' ? { month: false, search: null } : { month: true, search: 'Search customer' }
    case 'reports': return { month: true, search: null }
    case 'pending': return { month: false, search: 'Search customer' }
    default: return { month: false, search: null }
  }
}
