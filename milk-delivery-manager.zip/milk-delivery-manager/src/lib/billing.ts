import { db, resolveRate, customerBalance, AppError } from './db'
import { amountFor, UNITS, formatQty, type UnitKey } from './money'
import { daysBetween, isBetween, isValidISO, monthEnd, monthStart } from './dates'
import type { Entry, Product, Rate, Bill, BillItem, Pause } from './types'

export interface Line { productId: number; productName: string; kind: 'regular' | 'extra'; qtyMilli: number; ratePaise: number; milliPerUnit: number; unit: UnitKey; amountPaise: number }

/** Pure billing core: groups delivered quantities by product/kind/rate and rounds once per line. */
export function buildLines(entries: Entry[], rates: Rate[], products: Map<number, Product>): { lines: Line[]; missingRate: number[] } {
  const groups = new Map<string, Line>()
  const missing = new Set<number>()
  for (const e of entries) {
    if (e.status !== 'delivered') continue // skipped deliveries are never charged
    const p = products.get(e.productId)
    if (!p) continue
    const r = resolveRate(rates, e.customerId, e.productId, e.date)
    if (!r) { missing.add(e.productId); continue }
    const milli = UNITS[p.unit].milliPerUnit
    const add = (kind: 'regular' | 'extra', qty: number, rate: number) => {
      if (qty <= 0) return
      const key = `${e.productId}|${kind}|${rate}`
      const g = groups.get(key) ?? { productId: e.productId, productName: p.name, kind, qtyMilli: 0, ratePaise: rate, milliPerUnit: milli, unit: p.unit, amountPaise: 0 }
      g.qtyMilli += qty
      groups.set(key, g)
    }
    add('regular', e.regularMl, r.ratePaise)
    add('extra', e.extraMl, r.extraRatePaise)
  }
  const lines = [...groups.values()].map(l => ({ ...l, amountPaise: amountFor(l.qtyMilli, l.ratePaise, l.milliPerUnit) }))
  lines.sort((a, b) => a.productName.localeCompare(b.productName) || (a.kind === b.kind ? 0 : a.kind === 'regular' ? -1 : 1) || a.ratePaise - b.ratePaise)
  return { lines, missingRate: [...missing] }
}

/** Discounts given on active (not cancelled) bills that start in this month. */
export function discountsInMonth(bills: Bill[], month: string, customerId?: number): number {
  return bills.filter(b => b.status === 'issued' && b.fromDate.slice(0, 7) === month && (customerId === undefined || b.customerId === customerId)).reduce((s, b) => s + b.discountPaise, 0)
}

/** "30 L" or "30 L, 2 kg" - quantities added up per unit so litres and kilos are never mixed. */
export function quantityText(lines: Line[], fallback: UnitKey): string {
  const per = new Map<UnitKey, number>()
  for (const l of lines) per.set(l.unit, (per.get(l.unit) ?? 0) + l.qtyMilli)
  if (per.size === 0) return `0 ${UNITS[fallback].short === 'pack' ? 'L' : UNITS[fallback].short}`
  return [...per].map(([u, q]) => formatQty(q, u)).join(', ')
}

/** One customer's delivered quantity and amount for a calendar month, using the same rules as billing. */
export async function monthSummary(customerId: number, month: string, fallback: UnitKey = 'L') {
  const [entries, rates, products, bills] = await Promise.all([
    db.entries.where('[customerId+date]').between([customerId, monthStart(month)], [customerId, monthEnd(month)], true, true).toArray(),
    db.rates.toArray(), db.products.toArray(), db.bills.where('customerId').equals(customerId).toArray()
  ])
  const { lines } = buildLines(entries, rates, new Map(products.map(p => [p.id!, p])))
  const gross = lines.reduce((s, l) => s + l.amountPaise, 0)
  const amountPaise = Math.max(0, gross - discountsInMonth(bills, month, customerId))
  return { lines, amountPaise, quantity: quantityText(lines, fallback) }
}

export function pausedDaysIn(pauses: Pause[], customerId: number, from: string, to: string, startDate: string): number {
  let n = 0
  for (const d of daysBetween(from, to)) {
    if (d >= startDate && pauses.some(p => p.customerId === customerId && isBetween(d, p.from, p.to))) n++
  }
  return n
}

export interface BillRequest { customerId: number; kind: 'daily' | 'monthly' | 'range'; from: string; to: string; discountPaise?: number; productId?: number | null; note?: string }

export function periodFor(kind: 'daily' | 'monthly', value: string): { from: string; to: string } {
  return kind === 'monthly' ? { from: monthStart(value), to: monthEnd(value) } : { from: value, to: value }
}

async function loadUnbilled(customerId: number, from: string, to: string, productId?: number | null): Promise<Entry[]> {
  const rows = await db.entries.where('[customerId+date]').between([customerId, from], [customerId, to], true, true).toArray()
  return rows.filter(e => e.billId === null && (!productId || e.productId === productId))
}

/** Preview totals without saving anything. */
export async function previewBill(req: BillRequest) {
  if (!isValidISO(req.from) || !isValidISO(req.to) || req.from > req.to) throw new AppError('Choose a valid date range')
  const [entries, rates, products] = await Promise.all([loadUnbilled(req.customerId, req.from, req.to, req.productId), db.rates.toArray(), db.products.toArray()])
  const { lines, missingRate } = buildLines(entries, rates, new Map(products.map(p => [p.id!, p])))
  const subtotal = lines.reduce((s, l) => s + l.amountPaise, 0)
  return { lines, missingRate, subtotal, deliveredDays: new Set(entries.filter(e => e.status === 'delivered').map(e => e.date)).size }
}

export async function generateBill(req: BillRequest): Promise<number> {
  if (!isValidISO(req.from) || !isValidISO(req.to) || req.from > req.to) throw new AppError('Choose a valid date range')
  const discount = req.discountPaise ?? 0
  if (!Number.isInteger(discount) || discount < 0) throw new AppError('Discount must be zero or more')
  return db.transaction('rw', [db.entries, db.bills, db.billItems, db.rates, db.products, db.pauses, db.customers, db.settings], async () => {
    const customer = await db.customers.get(req.customerId)
    if (!customer) throw new AppError('Customer not found')
    if (req.kind === 'monthly') {
      const dup = await db.bills.where('customerId').equals(req.customerId).filter(b => b.status === 'issued' && b.kind === 'monthly' && b.fromDate === req.from && b.toDate === req.to).first()
      if (dup) throw new AppError(`A monthly bill (${dup.number}) already exists for this month. Cancel it first, or use a custom date range for late entries.`)
    }
    const entries = await loadUnbilled(req.customerId, req.from, req.to, req.productId)
    const delivered = entries.filter(e => e.status === 'delivered')
    if (delivered.length === 0) throw new AppError('There are no deliveries left to bill in this period.')
    const [rates, products, pauses] = await Promise.all([db.rates.toArray(), db.products.toArray(), db.pauses.where('customerId').equals(req.customerId).toArray()])
    const { lines, missingRate } = buildLines(entries, rates, new Map(products.map(p => [p.id!, p])))
    if (missingRate.length) {
      const names = products.filter(p => missingRate.includes(p.id!)).map(p => p.name).join(', ')
      throw new AppError(`Set a rate for ${names} (Products & Rates) before billing.`)
    }
    const subtotal = lines.reduce((s, l) => s + l.amountPaise, 0)
    if (discount > subtotal) throw new AppError('Discount cannot be more than the bill amount')
    const seqRow = await db.settings.get('billSeq')
    const seq = ((seqRow?.value as number) ?? 0) + 1
    await db.settings.put({ key: 'billSeq', value: seq })
    const allEntries = await db.entries.where('[customerId+date]').between([req.customerId, req.from], [req.customerId, req.to], true, true).toArray()
    const bill: Bill = {
      number: `B-${String(seq).padStart(5, '0')}`, customerId: req.customerId, kind: req.kind, fromDate: req.from, toDate: req.to,
      subtotalPaise: subtotal, discountPaise: discount, totalPaise: subtotal - discount,
      deliveredDays: new Set(delivered.map(e => e.date)).size,
      skippedDays: new Set(allEntries.filter(e => e.status === 'skipped' && !allEntries.some(o => o.date === e.date && o.status === 'delivered')).map(e => e.date)).size,
      pausedDays: pausedDaysIn(pauses, req.customerId, req.from, req.to, customer.startDate),
      status: 'issued', note: req.note ?? '', createdAt: Date.now()
    }
    const billId = await db.bills.add(bill)
    await db.billItems.bulkAdd(lines.map(l => ({ ...l, billId })) as BillItem[])
    // Mark entries as billed so they can never be billed twice (or edited silently).
    await db.entries.bulkPut(entries.map(e => ({ ...e, billId })))
    return billId
  })
}

/** Voiding keeps the record but releases its deliveries for re-billing. Needs explicit confirmation in the UI. */
export async function voidBill(billId: number) {
  await db.transaction('rw', db.bills, db.entries, async () => {
    const b = await db.bills.get(billId)
    if (!b) throw new AppError('Bill not found')
    if (b.status === 'void') return
    await db.bills.update(billId, { status: 'void' })
    const linked = await db.entries.where('billId').equals(billId).toArray()
    await db.entries.bulkPut(linked.map(e => ({ ...e, billId: null })))
  })
}

export async function recordPayment(p: { customerId: number; amountPaise: number; date: string; method: 'Cash' | 'UPI' | 'Bank Transfer' | 'Other'; reference?: string; note?: string }): Promise<number> {
  if (!Number.isInteger(p.amountPaise) || p.amountPaise <= 0) throw new AppError('Enter a payment amount greater than zero')
  if (!isValidISO(p.date)) throw new AppError('Choose a valid payment date')
  if (!['Cash', 'UPI', 'Bank Transfer', 'Other'].includes(p.method)) throw new AppError('Choose a payment method')
  if (!(await db.customers.get(p.customerId))) throw new AppError('Customer not found')
  return db.payments.add({ customerId: p.customerId, amountPaise: p.amountPaise, date: p.date, method: p.method, reference: (p.reference ?? '').trim().slice(0, 60), note: (p.note ?? '').trim().slice(0, 200), voided: false, createdAt: Date.now() })
}

export async function voidPayment(id: number) { await db.payments.update(id, { voided: true }) }

export { customerBalance }
