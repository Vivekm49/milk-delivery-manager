// Money is always integer paise. Quantity is always integer "milli-units"
// (ml for litre products, grams for kg, thousandths of a piece for pieces).

export type UnitKey = 'L' | '500ml' | 'kg' | 'pc'

export const UNITS: Record<UnitKey, { label: string; milliPerUnit: number; steps: number[]; short: string }> = {
  L: { label: 'Litre', milliPerUnit: 1000, steps: [250, 500, 1000], short: 'L' },
  '500ml': { label: '500 ml pack', milliPerUnit: 500, steps: [500, 1000], short: 'pack' },
  kg: { label: 'Kg', milliPerUnit: 1000, steps: [250, 500, 1000], short: 'kg' },
  pc: { label: 'Piece', milliPerUnit: 1000, steps: [1000, 2000], short: 'pc' }
}

/** amount (paise) = qty * rate / milliPerUnit, rounded half up, integers only. */
export function amountFor(qtyMilli: number, ratePaise: number, milliPerUnit: number): number {
  if (!Number.isInteger(qtyMilli) || !Number.isInteger(ratePaise)) throw new Error('Quantity and rate must be whole numbers')
  const num = qtyMilli * ratePaise
  return Math.floor((num * 2 + milliPerUnit) / (milliPerUnit * 2))
}

/** Parse a money string like "92.50" into paise. Returns null if invalid. */
export function parseMoney(input: string): number | null {
  const s = input.trim().replace(/,/g, '')
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(s)) return null
  const [r, p = ''] = s.split('.')
  return parseInt(r, 10) * 100 + parseInt((p + '00').slice(0, 2), 10)
}

/** Parse a quantity in units (e.g. "1.5") into milli-units. Returns null if invalid. */
export function parseQty(input: string): number | null {
  const s = input.trim()
  if (!/^\d{1,6}(\.\d{1,3})?$/.test(s)) return null
  const [w, f = ''] = s.split('.')
  return parseInt(w, 10) * 1000 + parseInt((f + '000').slice(0, 3), 10)
}

export function formatMoney(paise: number, symbol = '₹'): string {
  const neg = paise < 0
  const a = Math.abs(paise)
  const rupees = Math.floor(a / 100)
  const p = a % 100
  const r = rupees.toLocaleString('en-IN')
  return `${neg ? '-' : ''}${symbol}${r}${p ? '.' + String(p).padStart(2, '0') : ''}`
}

export function moneyInput(paise: number): string {
  const r = Math.floor(paise / 100)
  const p = paise % 100
  return p ? `${r}.${String(p).padStart(2, '0')}` : String(r)
}

export function formatQty(qtyMilli: number, unit: UnitKey = 'L'): string {
  if (unit === 'pc') return `${trim(qtyMilli / 1000)} pc`
  if (unit === 'kg') return qtyMilli < 1000 ? `${qtyMilli} g` : `${trim(qtyMilli / 1000)} kg`
  // litre-based (L and 500ml packs are stored in ml)
  return qtyMilli < 1000 ? `${qtyMilli} ml` : `${trim(qtyMilli / 1000)} L`
}

function trim(n: number): string {
  return String(Math.round(n * 1000) / 1000)
}

export function isValidPhone(v: string): boolean {
  const d = v.replace(/[\s-]/g, '')
  return /^(\+?91)?[6-9]\d{9}$/.test(d)
}

/** Normalised digits with country code for wa.me links (assumes India if 10 digits). */
export function phoneDigits(v: string): string {
  const d = v.replace(/[^\d]/g, '')
  if (d.length === 10) return '91' + d
  if (d.length === 12 && d.startsWith('91')) return d
  return d
}
