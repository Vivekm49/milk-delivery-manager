import { db, nextCustomerCode, addRate, AppError } from './db'
import { isValidPhone } from './money'
import { addDays, isValidISO, todayISO } from './dates'
import type { Customer } from './types'

export interface CustomerInput {
  name: string; mobile: string; whatsapp: string; address: string; area: string; productId: number
  dailyMl: number; startDate: string; prefTime: string; notes: string; openingPaise: number; groupId?: number | null
}

export function validateCustomer(i: CustomerInput): string[] {
  const e: string[] = []
  const name = i.name.trim()
  if (name.length < 2 || name.length > 60 || !/^[\p{L}\p{M}][\p{L}\p{M}\s.'-]*$/u.test(name)) e.push('Enter the customer name (letters only, 2 to 60 characters).')
  if (i.mobile.trim() && !isValidPhone(i.mobile)) e.push('Enter a valid 10-digit mobile number, or leave it empty.')
  if (i.whatsapp.trim() && !isValidPhone(i.whatsapp)) e.push('WhatsApp number is not valid.')
  if (!i.productId) e.push('Choose a product.')
  if (!Number.isInteger(i.dailyMl) || i.dailyMl <= 0 || i.dailyMl > 100000) e.push('Enter a daily quantity greater than zero.')
  if (!isValidISO(i.startDate)) e.push('Choose a valid start date.')
  if (i.address.length > 200 || i.notes.length > 500 || i.area.length > 60) e.push('Address, area or notes are too long.')
  if (!Number.isInteger(i.openingPaise) || i.openingPaise < 0) e.push('Previous amount due must be zero or more.')
  return e
}

export async function createCustomer(i: CustomerInput, customRatePaise?: number | null): Promise<number> {
  const errs = validateCustomer(i)
  if (errs.length) throw new AppError(errs[0])
  return db.transaction('rw', db.customers, db.rates, async () => {
    const dup = i.mobile.trim() ? await db.customers.where('mobile').equals(i.mobile.trim()).first() : undefined
    if (dup) throw new AppError(`${dup.name} already uses this mobile number.`)
    const c: Customer = {
      code: await nextCustomerCode(), name: i.name.trim(), mobile: i.mobile.trim(), whatsapp: i.whatsapp.trim(), address: i.address.trim(),
      area: i.area.trim(), productId: i.productId, dailyMl: i.dailyMl, startDate: i.startDate, status: 'active', prefTime: i.prefTime,
      notes: i.notes.trim(), openingPaise: i.openingPaise, groupId: i.groupId ?? null, createdAt: Date.now()
    }
    const id = await db.customers.add(c)
    if (customRatePaise) await addRate(i.productId, id, customRatePaise, null, i.startDate)
    return id
  })
}

export async function updateCustomer(id: number, i: CustomerInput, customRatePaise?: number | null) {
  const errs = validateCustomer(i)
  if (errs.length) throw new AppError(errs[0])
  await db.transaction('rw', db.customers, db.rates, async () => {
    const dup = i.mobile.trim() ? await db.customers.where('mobile').equals(i.mobile.trim()).first() : undefined
    if (dup && dup.id !== id) throw new AppError(`${dup.name} already uses this mobile number.`)
    await db.customers.update(id, {
      name: i.name.trim(), mobile: i.mobile.trim(), whatsapp: i.whatsapp.trim(), address: i.address.trim(), area: i.area.trim(),
      productId: i.productId, dailyMl: i.dailyMl, startDate: i.startDate, prefTime: i.prefTime, notes: i.notes.trim(), openingPaise: i.openingPaise,
      ...(i.groupId !== undefined ? { groupId: i.groupId } : {})
    })
    if (customRatePaise) {
      const cur = await db.rates.where({ productId: i.productId, customerId: id }).toArray()
      const latest = cur.sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom))[0]
      if (!latest || latest.ratePaise !== customRatePaise) await addRate(i.productId, id, customRatePaise, latest?.extraRatePaise ?? null, todayISO())
    }
  })
}

export async function setCustomerStatus(id: number, status: 'active' | 'paused' | 'inactive', on = todayISO()) {
  await db.transaction('rw', db.customers, db.pauses, async () => {
    const c = await db.customers.get(id)
    if (!c) throw new AppError('Customer not found')
    const open = await db.pauses.where('customerId').equals(id).filter(p => p.to === null).first()
    if (status === 'paused' && !open) await db.pauses.add({ customerId: id, from: on, to: null })
    if (status !== 'paused' && open) {
      const to = addDays(on, -1)
      if (to < open.from) await db.pauses.delete(open.id!) // paused and resumed the same day: no paused period
      else await db.pauses.update(open.id!, { to })
    }
    await db.customers.update(id, { status })
  })
}

/** Customers with any financial or delivery history are never hard-deleted. */
export async function deleteCustomer(id: number) {
  await db.transaction('rw', [db.customers, db.entries, db.bills, db.payments, db.pauses, db.rates, db.messageLog], async () => {
    const c = await db.customers.get(id)
    if (!c) return
    const [e, b, p] = await Promise.all([db.entries.where('[customerId+date]').between([id, ''], [id, '\uffff']).count(), db.bills.where('customerId').equals(id).count(), db.payments.where('customerId').equals(id).count()])
    if (e + b + p > 0 || c.openingPaise !== 0) throw new AppError('This customer has delivery or payment history, so it cannot be deleted. Deactivate the customer instead; all records stay safe.')
    await db.pauses.where('customerId').equals(id).delete()
    await db.rates.where('customerId').equals(id).delete()
    await db.messageLog.where('customerId').equals(id).delete()
    await db.customers.delete(id)
  })
}

// ---------- groups ----------
function cleanGroupName(raw: string): string {
  const n = raw.trim().replace(/\s+/g, ' ')
  if (n.length < 1 || n.length > 30) throw new AppError('Enter a group name (1 to 30 characters).')
  return n
}
async function assertUniqueGroup(name: string, exceptId?: number) {
  const dup = await db.groups.filter(g => g.name.toLowerCase() === name.toLowerCase() && g.id !== exceptId).first()
  if (dup) throw new AppError('A group with this name already exists.')
}
export async function createGroup(raw: string): Promise<number> {
  const name = cleanGroupName(raw)
  return db.transaction('rw', db.groups, async () => { await assertUniqueGroup(name); return db.groups.add({ name, createdAt: Date.now() }) })
}
export async function renameGroup(id: number, raw: string) {
  const name = cleanGroupName(raw)
  await db.transaction('rw', db.groups, async () => { await assertUniqueGroup(name, id); await db.groups.update(id, { name }) })
}
/** Deleting a group only clears the group on its customers. Customers and all their records are untouched. */
export async function deleteGroup(id: number): Promise<number> {
  return db.transaction('rw', db.groups, db.customers, async () => {
    const members = await db.customers.filter(c => c.groupId === id).toArray()
    for (const c of members) await db.customers.update(c.id!, { groupId: null })
    await db.groups.delete(id)
    return members.length
  })
}
export async function setCustomerGroup(customerId: number, groupId: number | null) {
  if (groupId !== null && !(await db.groups.get(groupId))) throw new AppError('This group no longer exists.')
  await db.customers.update(customerId, { groupId })
}

// ---------- delivery order ----------
/** Customers in the owner's order: numbered ones first (by sortOrder), the rest by name. */
export function sortCustomers<T extends { sortOrder?: number; name: string }>(list: T[]): T[] {
  return [...list].sort((a, b) => {
    const ao = a.sortOrder ?? Number.MAX_SAFE_INTEGER, bo = b.sortOrder ?? Number.MAX_SAFE_INTEGER
    return ao !== bo ? ao - bo : a.name.localeCompare(b.name)
  })
}

/** Moves one customer up (-1) or down (+1) in the delivery order. Nothing else about the customer changes. */
export async function moveCustomer(id: number, dir: -1 | 1) {
  await db.transaction('rw', db.customers, async () => {
    const all = sortCustomers(await db.customers.toArray())
    const i = all.findIndex(c => c.id === id)
    const j = i + dir
    if (i < 0 || j < 0 || j >= all.length) return
    const next = [...all]; [next[i], next[j]] = [next[j], next[i]]
    await Promise.all(next.map((c, k) => (c.sortOrder === k ? Promise.resolve() : db.customers.update(c.id!, { sortOrder: k }))))
  })
}
