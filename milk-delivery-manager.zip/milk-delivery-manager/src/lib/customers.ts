import { db, nextCustomerCode, addRate, AppError } from './db'
import { isValidPhone } from './money'
import { addDays, isValidISO, todayISO } from './dates'
import type { Customer } from './types'

export interface CustomerInput {
  name: string; mobile: string; whatsapp: string; address: string; area: string; productId: number
  dailyMl: number; startDate: string; prefTime: string; notes: string; openingPaise: number
}

export function validateCustomer(i: CustomerInput): string[] {
  const e: string[] = []
  const name = i.name.trim()
  if (name.length < 2 || name.length > 60 || !/^[\p{L}\p{M}][\p{L}\p{M}\s.'-]*$/u.test(name)) e.push('Enter the customer name (letters only, 2 to 60 characters).')
  if (!isValidPhone(i.mobile)) e.push('Enter a valid 10-digit mobile number.')
  if (i.whatsapp.trim() && !isValidPhone(i.whatsapp)) e.push('WhatsApp number is not valid.')
  if (!i.productId) e.push('Choose a product.')
  if (!Number.isInteger(i.dailyMl) || i.dailyMl <= 0 || i.dailyMl > 100000) e.push('Enter a daily quantity greater than zero.')
  if (!isValidISO(i.startDate)) e.push('Choose a valid start date.')
  if (i.address.length > 200 || i.notes.length > 500 || i.area.length > 60) e.push('Address, area or notes are too long.')
  if (!Number.isInteger(i.openingPaise) || i.openingPaise < 0) e.push('Opening balance must be zero or more.')
  return e
}

export async function createCustomer(i: CustomerInput, customRatePaise?: number | null): Promise<number> {
  const errs = validateCustomer(i)
  if (errs.length) throw new AppError(errs[0])
  return db.transaction('rw', db.customers, db.rates, async () => {
    const dup = await db.customers.where('mobile').equals(i.mobile.trim()).first()
    if (dup) throw new AppError(`${dup.name} already uses this mobile number.`)
    const c: Customer = {
      code: await nextCustomerCode(), name: i.name.trim(), mobile: i.mobile.trim(), whatsapp: i.whatsapp.trim(), address: i.address.trim(),
      area: i.area.trim(), productId: i.productId, dailyMl: i.dailyMl, startDate: i.startDate, status: 'active', prefTime: i.prefTime,
      notes: i.notes.trim(), openingPaise: i.openingPaise, createdAt: Date.now()
    }
    const id = await db.customers.add(c)
    if (customRatePaise) await addRate(i.productId, id, customRatePaise, null, i.startDate)
    return id
  })
}

export async function updateCustomer(id: number, i: CustomerInput, customRatePaise?: number | null) {
  const errs = validateCustomer(i)
  if (errs.length) throw new AppError(errs[0])
  await db.transaction('rw', db.customers, db.rates, async () => {
    const dup = await db.customers.where('mobile').equals(i.mobile.trim()).first()
    if (dup && dup.id !== id) throw new AppError(`${dup.name} already uses this mobile number.`)
    await db.customers.update(id, {
      name: i.name.trim(), mobile: i.mobile.trim(), whatsapp: i.whatsapp.trim(), address: i.address.trim(), area: i.area.trim(),
      productId: i.productId, dailyMl: i.dailyMl, startDate: i.startDate, prefTime: i.prefTime, notes: i.notes.trim(), openingPaise: i.openingPaise
    })
    if (customRatePaise) {
      const cur = await db.rates.where({ productId: i.productId, customerId: id }).toArray()
      const latest = cur.sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom))[0]
      if (!latest || latest.ratePaise !== customRatePaise) await addRate(i.productId, id, customRatePaise, latest?.extraRatePaise ?? null, todayISO())
    }
  })
}

export async function setCustomerStatus(id: number, status: 'active' | 'paused' | 'inactive', on = todayISO()) {
  await db.transaction('rw', db.customers, db.pauses, async () => {
    const c = await db.customers.get(id)
    if (!c) throw new AppError('Customer not found')
    const open = await db.pauses.where('customerId').equals(id).filter(p => p.to === null).first()
    if (status === 'paused' && !open) await db.pauses.add({ customerId: id, from: on, to: null })
    if (status !== 'paused' && open) {
      const to = addDays(on, -1)
      if (to < open.from) await db.pauses.delete(open.id!) // paused and resumed the same day: no paused period
      else await db.pauses.update(open.id!, { to })
    }
    await db.customers.update(id, { status })
  })
}

/** Customers with any financial or delivery history are never hard-deleted. */
export async function deleteCustomer(id: number) {
  await db.transaction('rw', [db.customers, db.entries, db.bills, db.payments, db.pauses, db.rates, db.messageLog], async () => {
    const c = await db.customers.get(id)
    if (!c) return
    const [e, b, p] = await Promise.all([db.entries.where('[customerId+date]').between([id, ''], [id, '\uffff']).count(), db.bills.where('customerId').equals(id).count(), db.payments.where('customerId').equals(id).count()])
    if (e + b + p > 0 || c.openingPaise !== 0) throw new AppError('This customer has delivery or payment history, so it cannot be deleted. Deactivate the customer instead; all records stay safe.')
    await db.pauses.where('customerId').equals(id).delete()
    await db.rates.where('customerId').equals(id).delete()
    await db.messageLog.where('customerId').equals(id).delete()
    await db.customers.delete(id)
  })
}
