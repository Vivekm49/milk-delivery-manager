import { Capacitor } from '@capacitor/core'
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem'
import { Share } from '@capacitor/share'

/** Saves/exports a text file. On Android it opens the share sheet (Save to Drive, WhatsApp, Files...). In a browser it downloads. */
export async function saveTextFile(name: string, content: string, mime = 'text/plain'): Promise<'shared' | 'downloaded'> {
  if (Capacitor.isNativePlatform()) {
    const res = await Filesystem.writeFile({ path: name, data: content, directory: Directory.Cache, encoding: Encoding.UTF8 })
    await Share.share({ title: name, url: res.uri, dialogTitle: 'Save or share file' })
    return 'shared'
  }
  const blob = new Blob([content], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = name
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 5000)
  return 'downloaded'
}
