import { daysBetween, isBetween, monthEnd, monthStart } from './dates'
import type { Customer, Entry, Pause } from './types'

export type DayStatus = 'delivered' | 'absent' | 'paused' | 'none'

/**
 * One status per day for one customer.
 * - delivered: at least one milk was delivered
 * - absent: the customer was marked Absent (every line of that day is Absent)
 * - paused: delivery was paused on that day and nothing was entered
 * - none: nothing entered yet (a quantity of 0 never means Absent)
 */
export function dayStatuses(entries: Entry[], pauses: Pause[], customer: Customer, month: string): Map<string, DayStatus> {
  const byDate = new Map<string, Entry[]>()
  for (const e of entries) if (e.customerId === customer.id) byDate.set(e.date, [...(byDate.get(e.date) ?? []), e])
  const out = new Map<string, DayStatus>()
  for (const d of daysBetween(monthStart(month), monthEnd(month))) {
    const rows = byDate.get(d) ?? []
    if (rows.some(e => e.status === 'delivered')) out.set(d, 'delivered')
    else if (rows.some(e => e.status === 'skipped')) out.set(d, 'absent')
    else if (d >= customer.startDate && pauses.some(p => p.customerId === customer.id && isBetween(d, p.from, p.to))) out.set(d, 'paused')
    else out.set(d, 'none')
  }
  return out
}

export function dayCounts(map: Map<string, DayStatus>) {
  let delivered = 0, absent = 0, paused = 0
  const absentDates: string[] = []
  for (const [d, s] of map) { if (s === 'delivered') delivered++; else if (s === 'absent') { absent++; absentDates.push(d) } else if (s === 'paused') paused++ }
  return { delivered, absent, paused, absentDates }
}
