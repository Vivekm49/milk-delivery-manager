import { db, isPausedOn } from './db'
import { todayISO } from './dates'

/** Today's numbers for the Home screen. Absent = the customer is marked Absent and nothing else was delivered. */
export async function loadToday(today = todayISO()) {
  const [customers, products, pauses, entries] = await Promise.all([db.customers.toArray(), db.products.toArray(), db.pauses.toArray(), db.entries.where('date').equals(today).toArray()])
  const litre = new Set(products.filter(p => p.unit === 'L' || p.unit === '500ml').map(p => p.id!))
  const delivered = entries.filter(e => e.status === 'delivered')
  const deliveredCust = new Set(delivered.map(e => e.customerId))
  const absentCust = new Set(entries.filter(e => e.status === 'skipped' && !deliveredCust.has(e.customerId)).map(e => e.customerId))
  const expected = customers.filter(c => c.status !== 'inactive' && c.startDate <= today && !isPausedOn(pauses, c.id!, today))
  const litreEntries = delivered.filter(e => litre.has(e.productId))
  return {
    today,
    litresMilli: litreEntries.reduce((s, e) => s + e.regularMl + e.extraMl, 0),
    extraMilli: litreEntries.reduce((s, e) => s + e.extraMl, 0),
    delivered: deliveredCust.size, expected: expected.length, absent: absentCust.size,
    active: customers.filter(c => c.status === 'active').length, totalCustomers: customers.length
  }
}
