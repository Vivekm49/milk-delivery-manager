import { describe, it, expect } from 'vitest'
import { writeFileSync, mkdirSync } from 'node:fs'
import { buildReportPdf, pdfMoney, pdfFileName, type PdfReport } from './pdf'

const base = (over: Partial<PdfReport>): PdfReport => ({
  type: 'Customer', title: 'Customer Report', business: 'Lucky Dairy & Sons Milk Delivery', period: 'October 2026', generated: '16 Oct 2026', currency: '₹',
  summary: [], columns: [], rows: [], ...over
})
const OUT = '/tmp/pdf-out'; mkdirSync(OUT, { recursive: true })

describe('PDF reports', () => {
  it('formats money with two decimals and a safe fallback symbol', () => {
    expect(pdfMoney(180000, '₹')).toBe('₹ 1,800.00')
    expect(pdfMoney(9250, '₹')).toBe('₹ 92.50')
    expect(pdfMoney(123456789, '₹')).toBe('₹ 12,34,567.89')
    expect(pdfMoney(500, '৳')).toBe('Rs. 5.00')
    expect(pdfFileName('Daily', '2026-10-16')).toBe('Milk_Delivery_Daily_Report_2026-10-16.pdf')
  })
  it('small report: one page, real PDF', async () => {
    const r = base({
      summary: [{ label: 'Customers', value: '3' }, { label: 'Total Quantity', value: '95 L' }, { label: 'Monthly Amount', value: pdfMoney(570000, '₹') }],
      columns: [{ header: 'Customer', weight: 3 }, { header: 'Total Quantity', align: 'right', weight: 2 }, { header: 'Monthly Amount', align: 'right', weight: 2 }, { header: 'Paid', align: 'right', weight: 2 }, { header: 'Amount Pending', align: 'right', weight: 2 }, { header: 'Status', weight: 2 }],
      rows: [['Rahul Sharma', '30 L', pdfMoney(180000, '₹'), pdfMoney(180000, '₹'), pdfMoney(0, '₹'), 'Paid'], ['Amit Kumar', '45 L', pdfMoney(270000, '₹'), pdfMoney(200000, '₹'), pdfMoney(70000, '₹'), 'Payment Pending'], ['Suresh', '20 L', pdfMoney(120000, '₹'), pdfMoney(0, '₹'), pdfMoney(120000, '₹'), 'Payment Pending']],
      totals: ['Total', '95 L', pdfMoney(570000, '₹'), pdfMoney(380000, '₹'), pdfMoney(190000, '₹'), '']
    })
    const { bytes, pages } = await buildReportPdf(r)
    expect(String.fromCharCode(...bytes.slice(0, 5))).toBe('%PDF-')
    expect(pages).toBe(1)
    writeFileSync(`${OUT}/small.pdf`, bytes)
  })
  it('large report: many rows, long names, big amounts -> several pages with repeated headings and page numbers', async () => {
    const rows: string[][] = []
    for (let i = 1; i <= 260; i++) rows.push([i % 7 === 0 ? 'Venkata Subramanian Ramakrishnan Iyer Krishnamurthy (Gandhi Nagar Block 12)' : i % 11 === 0 ? 'A'.repeat(58) : `Customer Number ${i}`, 'Cow Milk', '1 L', '500 ml', '1.5 L', pdfMoney(6000, '₹'), pdfMoney(9000 + i * 100000, '₹'), i % 3 ? 'Delivered' : 'Skipped'])
    const r = base({
      type: 'Daily', title: 'Daily Report', period: '16 Oct 2026', summary: [{ label: 'Total litres', value: '390 L' }, { label: 'Deliveries', value: '173' }, { label: 'Extra milk', value: '86 L' }, { label: 'Expected Collection', value: pdfMoney(999999999, '₹') }, { label: 'Skipped', value: '87' }],
      columns: [{ header: 'Customer', weight: 4 }, { header: 'Product', weight: 2 }, { header: 'Regular', align: 'right', weight: 1.4 }, { header: 'Extra', align: 'right', weight: 1.4 }, { header: 'Total', align: 'right', weight: 1.4 }, { header: 'Rate', align: 'right', weight: 1.8 }, { header: 'Amount', align: 'right', weight: 2.6 }, { header: 'Status', weight: 1.8 }],
      rows, totals: ['Total', '', '', '', '390 L', '', pdfMoney(999999999, '₹'), ''], note: 'Amounts use the rates that were active on each day.'
    })
    const { bytes, pages, doc } = await buildReportPdf(r)
    expect(pages).toBeGreaterThan(5)
    writeFileSync(`${OUT}/large.pdf`, bytes)
    const raw = await buildReportPdf(r, { compress: false })
    const text = Buffer.from(raw.bytes).toString('latin1')
    expect(doc.getNumberOfPages()).toBe(pages)
    expect(text).toContain('/Type /Pages')
  })
  it('empty report still produces a valid PDF with a clear message', async () => {
    const { bytes, pages } = await buildReportPdf(base({ type: 'Daily', title: 'Daily Report', period: '1 Jan 2026', summary: [{ label: 'Deliveries', value: '0' }], columns: [{ header: 'Customer' }, { header: 'Amount', align: 'right' }], rows: [], emptyText: 'No deliveries were recorded on this day.' }))
    expect(pages).toBe(1); writeFileSync(`${OUT}/empty.pdf`, bytes)
  })
})
