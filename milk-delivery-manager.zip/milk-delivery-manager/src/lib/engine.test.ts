import 'fake-indexeddb/auto'
import { describe, it, expect, beforeEach } from 'vitest'
import { db, ensureSeed, addRate, customerBalance, balanceOf } from './db'
import { amountFor, parseMoney, parseQty, formatMoney, isValidPhone, formatQty } from './money'
import { generateBill, previewBill, voidBill, recordPayment, voidPayment, buildLines } from './billing'
import { createCustomer, deleteCustomer, setCustomerStatus, validateCustomer } from './customers'
import { saveEntries } from './entries'
import { exportAll, restoreAll, validateBackup, eraseAll } from './backup'
import { renderTemplate, buildContext, messageLink } from './messages'
import { daysBetween } from './dates'
import Dexie from 'dexie'
import { MilkDB } from './db'

let cowId = 0
const base = (name: string, mobile: string) => ({ name, mobile, whatsapp: '', address: '', area: 'North', productId: cowId, dailyMl: 1000, startDate: '2026-01-01', prefTime: 'Morning', notes: '', openingPaise: 0 })

async function fillMonth(customerId: number, month: string, days: number, regular = 1000, extra = 0) {
  const dates = daysBetween(`${month}-01`, `${month}-${String(days).padStart(2, '0')}`)
  await saveEntries('x', []).catch(() => {})
  for (const d of dates) await saveEntries(d, [{ customerId, productId: cowId, regularMl: regular, extraMl: extra, status: 'delivered' }])
}

beforeEach(async () => {
  await eraseAll()
  await ensureSeed()
  cowId = (await db.products.where('name').equals('Cow Milk').first())!.id!
})

describe('required calculations', () => {
  it('1. 1 L x Rs60 = Rs60', () => expect(amountFor(1000, 6000, 1000)).toBe(6000))
  it('2. 1.5 L x Rs60 = Rs90', () => expect(amountFor(1500, 6000, 1000)).toBe(9000))
  it('3. 1 L x 60 + 0.5 L x 65 = Rs92.50', async () => {
    await addRate(cowId, 0, 6000, 6500, '2026-01-01')
    const id = await createCustomer(base('Rahul', '9876543210'))
    await saveEntries('2026-02-01', [{ customerId: id, productId: cowId, regularMl: 1000, extraMl: 500, status: 'delivered' }])
    const p = await previewBill({ customerId: id, kind: 'daily', from: '2026-02-01', to: '2026-02-01' })
    expect(p.subtotal).toBe(9250)
    expect(formatMoney(p.subtotal)).toBe('₹92.50')
  })
  it('4. 30 delivered days x 1 L x Rs60 = Rs1,800', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Amit', '9876543211'))
    await fillMonth(id, '2026-04', 30)
    const bid = await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    expect((await db.bills.get(bid))!.totalPaise).toBe(180000)
    expect(formatMoney(180000)).toBe('₹1,800')
  })
  it('5. skipped deliveries are not charged', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Suresh', '9876543212'))
    await fillMonth(id, '2026-04', 28)
    for (const d of ['2026-04-29', '2026-04-30']) await saveEntries(d, [{ customerId: id, productId: cowId, regularMl: 1000, extraMl: 0, status: 'skipped' }])
    const bid = await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    const b = (await db.bills.get(bid))!
    expect(b.totalPaise).toBe(28 * 6000)
    expect(b.skippedDays).toBe(2)
    expect(b.deliveredDays).toBe(28)
  })
  it('6. Rs2,125 bill - Rs2,000 payment = Rs125 (30 L x 60 + 5 L extra x 65)', async () => {
    await addRate(cowId, 0, 6000, 6500, '2026-01-01')
    const id = await createCustomer(base('Meena', '9876543213'))
    await fillMonth(id, '2026-04', 30)
    for (const d of ['2026-04-01', '2026-04-02', '2026-04-03', '2026-04-04', '2026-04-05']) await saveEntries(d, [{ customerId: id, productId: cowId, regularMl: 1000, extraMl: 1000, status: 'delivered' }])
    const bid = await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    expect((await db.bills.get(bid))!.totalPaise).toBe(212500)
    await recordPayment({ customerId: id, amountPaise: 200000, date: '2026-05-02', method: 'UPI', reference: 'UPI123' })
    expect(await customerBalance(id)).toBe(12500)
  })
  it('7. Rs1,000 bill - Rs1,000 payment = Rs0', async () => {
    await addRate(cowId, 0, 10000, null, '2026-01-01')
    const id = await createCustomer(base('Geeta', '9876543214'))
    await saveEntries('2026-04-01', Array.from({ length: 1 }, () => ({ customerId: id, productId: cowId, regularMl: 10000, extraMl: 0, status: 'delivered' as const })))
    await generateBill({ customerId: id, kind: 'daily', from: '2026-04-01', to: '2026-04-01' })
    await recordPayment({ customerId: id, amountPaise: 100000, date: '2026-04-02', method: 'Cash' })
    expect(await customerBalance(id)).toBe(0)
  })
})

describe('billing rules', () => {
  it('prevents a duplicate monthly bill and double-billing of entries', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Raju', '9876543215'))
    await fillMonth(id, '2026-03', 10)
    await generateBill({ customerId: id, kind: 'monthly', from: '2026-03-01', to: '2026-03-31' })
    await expect(generateBill({ customerId: id, kind: 'monthly', from: '2026-03-01', to: '2026-03-31' })).rejects.toThrow(/already exists/)
    await expect(generateBill({ customerId: id, kind: 'range', from: '2026-03-01', to: '2026-03-31' })).rejects.toThrow(/no deliveries left to bill/i)
    expect(await db.bills.count()).toBe(1)
  })
  it('old bills never change when the rate changes; mid-month rate change bills by effective date', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Sita', '9876543216'))
    await fillMonth(id, '2026-02', 28)
    const feb = await generateBill({ customerId: id, kind: 'monthly', from: '2026-02-01', to: '2026-02-28' })
    await addRate(cowId, 0, 7000, null, '2026-03-16')
    expect((await db.bills.get(feb))!.totalPaise).toBe(28 * 6000)
    await fillMonth(id, '2026-03', 31)
    const mar = await generateBill({ customerId: id, kind: 'monthly', from: '2026-03-01', to: '2026-03-31' })
    expect((await db.bills.get(mar))!.totalPaise).toBe(15 * 6000 + 16 * 7000)
    const items = await db.billItems.where('billId').equals(mar).toArray()
    expect(items.map(i => i.ratePaise).sort()).toEqual([6000, 7000])
  })
  it('customer-specific rate overrides the product rate', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Vip', '9876543217'), 5500)
    await saveEntries('2026-04-01', [{ customerId: id, productId: cowId, regularMl: 2000, extraMl: 0, status: 'delivered' }])
    expect((await previewBill({ customerId: id, kind: 'daily', from: '2026-04-01', to: '2026-04-01' })).subtotal).toBe(11000)
  })
  it('discount is applied and cannot exceed the bill', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Disc', '9876543218'))
    await fillMonth(id, '2026-04', 10)
    await expect(generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30', discountPaise: 99999999 })).rejects.toThrow(/Discount/)
    const bid = await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30', discountPaise: 5000 })
    expect((await db.bills.get(bid))!.totalPaise).toBe(60000 - 5000)
  })
  it('refuses to bill when no rate is set', async () => {
    const id = await createCustomer(base('NoRate', '9876543219'))
    await saveEntries('2026-04-01', [{ customerId: id, productId: cowId, regularMl: 1000, extraMl: 0, status: 'delivered' }])
    await expect(generateBill({ customerId: id, kind: 'daily', from: '2026-04-01', to: '2026-04-01' })).rejects.toThrow(/Set a rate/)
  })
  it('voiding a bill releases its deliveries and the balance drops', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Void', '9876543220'))
    await fillMonth(id, '2026-04', 5)
    const bid = await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    expect(await customerBalance(id)).toBe(30000)
    await voidBill(bid)
    expect(await customerBalance(id)).toBe(0)
    await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    expect(await customerBalance(id)).toBe(30000)
  })
  it('records pause days in the bill', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Pause', '9876543221'))
    await setCustomerStatus(id, 'paused', '2026-04-10')
    await setCustomerStatus(id, 'active', '2026-04-15')
    await fillMonth(id, '2026-04', 9)
    const bid = await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    expect((await db.bills.get(bid))!.pausedDays).toBe(5)
  })
  it('rounds once per line, not per day', () => {
    const products = new Map([[1, { id: 1, name: 'M', unit: 'L' as const, active: true, createdAt: 0 }]])
    const rates = [{ id: 1, productId: 1, customerId: 0, ratePaise: 5999, extraRatePaise: null, effectiveFrom: '2026-01-01', createdAt: 0 }]
    const entries = Array.from({ length: 3 }, (_, i) => ({ id: i, customerId: 1, date: `2026-01-0${i + 1}`, productId: 1, regularMl: 250, extraMl: 0, status: 'delivered' as const, billId: null, updatedAt: 0 }))
    expect(buildLines(entries, rates, products).lines[0].amountPaise).toBe(Math.round(750 * 5999 / 1000))
  })
})

describe('payments, customers, entries', () => {
  it('validates payments and keeps voided payments out of the balance', async () => {
    const id = await createCustomer({ ...base('Pay', '9876543222'), openingPaise: 50000 })
    await expect(recordPayment({ customerId: id, amountPaise: 0, date: '2026-04-01', method: 'Cash' })).rejects.toThrow()
    await expect(recordPayment({ customerId: id, amountPaise: 100, date: 'bad', method: 'Cash' })).rejects.toThrow()
    const pid = await recordPayment({ customerId: id, amountPaise: 20000, date: '2026-04-01', method: 'Cash' })
    expect(await customerBalance(id)).toBe(30000)
    await voidPayment(pid)
    expect(await customerBalance(id)).toBe(50000)
    expect(await db.payments.count()).toBe(1)
  })
  it('validates names and phone numbers', () => {
    expect(validateCustomer({ ...base('R', '9876543210') }).length).toBe(1)
    expect(validateCustomer({ ...base('Rahul123', '9876543210') }).length).toBe(1)
    expect(validateCustomer({ ...base('Rahul', '12345') }).length).toBe(1)
    expect(validateCustomer({ ...base('Rahul', '9876543210') }).length).toBe(0)
    expect(isValidPhone('+91 98765 43210')).toBe(true)
    expect(isValidPhone('5876543210')).toBe(false)
  })
  it('rejects duplicate mobile numbers', async () => {
    await createCustomer(base('One', '9876543230'))
    await expect(createCustomer(base('Two', '9876543230'))).rejects.toThrow(/already uses/)
  })
  it('cannot hard-delete a customer with history, can delete an unused one', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const a = await createCustomer(base('Used', '9876543231'))
    const b = await createCustomer(base('Unused', '9876543232'))
    await saveEntries('2026-04-01', [{ customerId: a, productId: cowId, regularMl: 1000, extraMl: 0, status: 'delivered' }])
    await expect(deleteCustomer(a)).rejects.toThrow(/history/)
    await deleteCustomer(b)
    expect(await db.customers.get(b)).toBeUndefined()
    await setCustomerStatus(a, 'inactive')
    expect((await db.customers.get(a))!.status).toBe('inactive')
    expect(await db.entries.count()).toBe(1)
  })
  it('never creates duplicate entries for a customer/date, and locks billed entries', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Dup', '9876543233'))
    const d = { customerId: id, productId: cowId, regularMl: 1000, extraMl: 0, status: 'delivered' as const }
    await saveEntries('2026-04-01', [d]); await saveEntries('2026-04-01', [{ ...d, extraMl: 500 }])
    expect(await db.entries.count()).toBe(1)
    expect((await db.entries.toArray())[0].extraMl).toBe(500)
    await generateBill({ customerId: id, kind: 'daily', from: '2026-04-01', to: '2026-04-01' })
    const r = await saveEntries('2026-04-01', [{ ...d, regularMl: 5000 }])
    expect(r.locked).toBe(1)
    expect((await db.entries.toArray())[0].regularMl).toBe(1000)
  })
  it('rejects bad quantities', async () => {
    const id = await createCustomer(base('Bad', '9876543234'))
    await expect(saveEntries('2026-04-01', [{ customerId: id, productId: cowId, regularMl: -5, extraMl: 0, status: 'delivered' }])).rejects.toThrow()
    await expect(saveEntries('2026-04-01', [{ customerId: id, productId: cowId, regularMl: 0, extraMl: 0, status: 'delivered' }])).rejects.toThrow()
    await expect(saveEntries('2026-04-01', [{ customerId: id, productId: cowId, regularMl: 1.5, extraMl: 0, status: 'delivered' }])).rejects.toThrow()
  })
})

describe('parsing and formatting', () => {
  it('parses money/quantity without floats', () => {
    expect(parseMoney('92.50')).toBe(9250); expect(parseMoney('60')).toBe(6000); expect(parseMoney('1,800')).toBe(180000)
    expect(parseMoney('-5')).toBeNull(); expect(parseMoney('abc')).toBeNull(); expect(parseMoney('1.234')).toBeNull(); expect(parseMoney('')).toBeNull()
    expect(parseQty('1.5')).toBe(1500); expect(parseQty('0.25')).toBe(250); expect(parseQty('x')).toBeNull(); expect(parseQty('-1')).toBeNull()
    expect(formatMoney(212500)).toBe('₹2,125'); expect(formatMoney(12500)).toBe('₹125'); expect(formatMoney(0)).toBe('₹0')
    expect(formatQty(1500)).toBe('1.5 L'); expect(formatQty(500)).toBe('500 ml'); expect(formatQty(2000, 'pc')).toBe('2 pc')
  })
})

describe('messages', () => {
  it('fills placeholders with real customer data', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Rahul', '9876543240'))
    await saveEntries('2026-04-10', [{ customerId: id, productId: cowId, regularMl: 1000, extraMl: 500, status: 'delivered' }])
    await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    await recordPayment({ customerId: id, amountPaise: 5000, date: '2026-04-11', method: 'Cash' })
    const c = (await db.customers.get(id))!
    const ctx = await buildContext(c, '2026-04', '2026-04-10')
    const tpl = (await db.templates.where('key').equals('reminder').first())!
    expect(renderTemplate(tpl.body, ctx)).toBe('Hello Rahul, your milk bill for April 2026 is ₹90. Pending amount: ₹40. Thank you.')
    const d = (await db.templates.where('key').equals('delivery').first())!
    expect(renderTemplate(d.body, ctx)).toBe("Hello Rahul, today's milk delivery quantity is 1.5 L. Extra milk: 500 ml. Thank you.")
    const r = (await db.templates.where('key').equals('received').first())!
    expect(renderTemplate(r.body, ctx)).toBe('Hello Rahul, we received your payment of ₹50. Your remaining balance is ₹40. Thank you.')
    // an unknown tag never reaches the customer as {something}
    expect(renderTemplate('{unknown} {customer name}', ctx)).toBe('Rahul')
    expect(messageLink('whatsapp', c, 'Hi there')).toBe('https://wa.me/919876543240?text=Hi%20there')
    expect(messageLink('sms', c, 'Hi')).toBe('sms:+919876543240?body=Hi')
  })
})

describe('backup and restore', () => {
  it('round-trips all data and rejects invalid files without touching existing data', async () => {
    await addRate(cowId, 0, 6000, null, '2026-01-01')
    const id = await createCustomer(base('Backup', '9876543250'))
    await fillMonth(id, '2026-04', 5)
    await generateBill({ customerId: id, kind: 'monthly', from: '2026-04-01', to: '2026-04-30' })
    await recordPayment({ customerId: id, amountPaise: 10000, date: '2026-05-01', method: 'UPI' })
    const backup = JSON.parse(JSON.stringify(await exportAll()))
    const before = await customerBalance(id)
    await eraseAll()
    expect(await db.customers.count()).toBe(0)
    await restoreAll(backup)
    expect(await db.customers.count()).toBe(1)
    expect(await db.entries.count()).toBe(5)
    expect(await customerBalance(id)).toBe(before)
    // invalid files
    expect(() => validateBackup(null)).toThrow()
    expect(() => validateBackup({ app: 'other' })).toThrow(/not created/)
    const broken = JSON.parse(JSON.stringify(backup)); broken.data.payments[0].amountPaise = -5
    await expect(restoreAll(broken)).rejects.toThrow(/invalid record/)
    const orphan = JSON.parse(JSON.stringify(backup)); orphan.data.entries[0].customerId = 999
    await expect(restoreAll(orphan)).rejects.toThrow(/missing data/)
    expect(await db.customers.count()).toBe(1) // existing data intact
    expect(await db.payments.count()).toBe(1)
  })
})
