import { db, TABLES, AppError } from './db'
import { isValidISO } from './dates'

export const BACKUP_APP = 'milk-delivery-manager'
export const BACKUP_VERSION = 1

export async function exportAll() {
  const data: Record<string, unknown[]> = {}
  for (const t of TABLES) data[t] = await (db as any)[t].toArray()
  return { app: BACKUP_APP, version: BACKUP_VERSION, exportedAt: new Date().toISOString(), data }
}

const isInt = (v: unknown) => Number.isInteger(v)
const isStr = (v: unknown) => typeof v === 'string'

type Check = (r: any) => boolean
const CHECKS: Record<string, Check> = {
  groups: r => isInt(r.id) && isStr(r.name) && r.name.length > 0,
  customers: r => isInt(r.id) && isStr(r.name) && r.name.length > 0 && isStr(r.mobile) && isInt(r.productId) && (r.groupId == null || isInt(r.groupId)) && isInt(r.dailyMl) && isValidISO(r.startDate) && ['active', 'paused', 'inactive'].includes(r.status) && isInt(r.openingPaise),
  products: r => isInt(r.id) && isStr(r.name) && ['L', '500ml', 'kg', 'pc'].includes(r.unit),
  rates: r => isInt(r.id) && isInt(r.productId) && isInt(r.customerId) && isInt(r.ratePaise) && r.ratePaise > 0 && isValidISO(r.effectiveFrom),
  entries: r => isInt(r.id) && isInt(r.customerId) && isValidISO(r.date) && isInt(r.regularMl) && isInt(r.extraMl) && r.regularMl >= 0 && r.extraMl >= 0 && ['delivered', 'skipped'].includes(r.status),
  pauses: r => isInt(r.id) && isInt(r.customerId) && isValidISO(r.from),
  bills: r => isInt(r.id) && isInt(r.customerId) && isStr(r.number) && isInt(r.totalPaise) && isInt(r.subtotalPaise) && isInt(r.discountPaise) && ['issued', 'void'].includes(r.status),
  billItems: r => isInt(r.id) && isInt(r.billId) && isInt(r.qtyMilli) && isInt(r.ratePaise) && isInt(r.amountPaise),
  payments: r => isInt(r.id) && isInt(r.customerId) && isInt(r.amountPaise) && r.amountPaise > 0 && isValidISO(r.date) && ['Cash', 'UPI', 'Bank Transfer', 'Other'].includes(r.method),
  templates: r => isInt(r.id) && isStr(r.key) && isStr(r.body),
  messageLog: r => isInt(r.id) && isInt(r.customerId) && isStr(r.body),
  settings: r => isStr(r.key)
}

export interface BackupSummary { counts: Record<string, number>; exportedAt: string }

/** Returns a summary or throws AppError with a readable reason. Nothing is written. */
export function validateBackup(obj: any): BackupSummary {
  if (!obj || typeof obj !== 'object') throw new AppError('This file is not a valid backup.')
  if (obj.app !== BACKUP_APP) throw new AppError('This file was not created by Milk Delivery Manager.')
  if (obj.version !== BACKUP_VERSION) throw new AppError('This backup version is not supported.')
  if (!obj.data || typeof obj.data !== 'object') throw new AppError('Backup has no data.')
  const counts: Record<string, number> = {}
  for (const t of TABLES) {
    const rows = obj.data[t] ?? (t === 'groups' ? [] : undefined) // backups made before groups existed
    if (!Array.isArray(rows)) throw new AppError(`Backup is missing "${t}".`)
    const bad = rows.findIndex((r: unknown) => !r || typeof r !== 'object' || !CHECKS[t](r))
    if (bad >= 0) throw new AppError(`Backup has an invalid record in "${t}" (row ${bad + 1}). Nothing was changed.`)
    counts[t] = rows.length
  }
  const ids = (t: string) => new Set<number>((obj.data[t] ?? []).map((r: any) => r.id))
  const cust = ids('customers'), prod = ids('products'), bills = ids('bills')
  const grp = new Set<number>((obj.data.groups ?? []).map((g: any) => g.id))
  for (const c of obj.data.customers) if (c.groupId != null && !grp.has(c.groupId)) throw new AppError('Backup has customers pointing to a missing group. Nothing was changed.')
  for (const e of obj.data.entries) if (!cust.has(e.customerId) || !prod.has(e.productId) || (e.billId != null && !bills.has(e.billId))) throw new AppError('Backup has delivery records pointing to missing data. Nothing was changed.')
  for (const b of obj.data.bills) if (!cust.has(b.customerId)) throw new AppError('Backup has bills for unknown customers. Nothing was changed.')
  for (const p of obj.data.payments) if (!cust.has(p.customerId)) throw new AppError('Backup has payments for unknown customers. Nothing was changed.')
  for (const i of obj.data.billItems) if (!bills.has(i.billId)) throw new AppError('Backup has bill items for unknown bills. Nothing was changed.')
  const dupes = new Set<string>()
  for (const e of obj.data.entries) { const k = `${e.customerId}|${e.date}|${e.productId}`; if (dupes.has(k)) throw new AppError('Backup has duplicate delivery records for the same customer, product and day. Nothing was changed.'); dupes.add(k) }
  return { counts, exportedAt: String(obj.exportedAt ?? '') }
}

/** Replaces everything in one transaction: if anything fails, the old data stays exactly as it was. */
export async function restoreAll(obj: any) {
  validateBackup(obj)
  const tables = TABLES.map(t => (db as any)[t])
  await db.transaction('rw', tables, async () => {
    for (const t of TABLES) {
      await (db as any)[t].clear()
      await (db as any)[t].bulkAdd(obj.data[t] ?? [])
    }
  })
}

export async function eraseAll() {
  const tables = TABLES.map(t => (db as any)[t])
  await db.transaction('rw', tables, async () => { for (const t of TABLES) await (db as any)[t].clear() })
}
