import 'fake-indexeddb/auto'
import { describe, it, expect, beforeEach } from 'vitest'
import { db, ensureSeed, addRate } from './db'
import { createCustomer } from './customers'
import { saveEntries } from './entries'
import { recordPayment } from './billing'
import { loadMonthly } from './monthly'
import { buildBillModel, billText } from './billImage'
import { allBillsReport, customerBillReport } from './billPdf'
import { buildReportPdf } from './pdf'
import { eraseAll } from './backup'

let cow = 0, curd = 0
beforeEach(async () => {
  await eraseAll(); await ensureSeed()
  cow = (await db.products.where('name').equals('Cow Milk').first())!.id!; curd = (await db.products.where('name').equals('Curd').first())!.id!
  await addRate(cow, 0, 6000, 6500, '2020-01-01', 4800); await addRate(curd, 0, 9000, null, '2020-01-01', 7000)
})
const cust = (name: string, mobile = '') => createCustomer({ name, mobile, whatsapp: '', address: '', area: '', productId: cow, dailyMl: 1000, startDate: '2026-01-01', prefTime: '', notes: '', openingPaise: 0 })

describe('bill picture, message and PDF all use the Monthly numbers', () => {
  it('bill model and text show every milk, Absent days (not charged), payments and Payment Pending', async () => {
    const id = await cust('Rahul Sharma', '9876543210')
    for (let d = 1; d <= 17; d++) await saveEntries(`2026-10-${String(d).padStart(2, '0')}`, [{ customerId: id, productId: cow, regularMl: 1000, extraMl: d === 3 ? 1500 : 0, status: 'delivered' }])
    for (const d of ['2026-10-18', '2026-10-19']) await saveEntries(d, [{ customerId: id, productId: cow, regularMl: 1000, extraMl: 0, status: 'skipped' }])
    await saveEntries('2026-10-02', [{ customerId: id, productId: curd, regularMl: 1000, extraMl: 0, status: 'delivered' }])
    await recordPayment({ customerId: id, amountPaise: 100000, date: '2026-10-10', method: 'UPI' })
    const data = await loadMonthly('2026-10')
    const model = buildBillModel(data.rows[0], '2026-10', await db.payments.toArray(), 'Lucky Dairy', '₹')
    // 17 L regular (₹1,020) + 1.5 L extra at the extra rate (₹97.50) + 1 kg curd (₹90) = ₹1,207.50
    expect(model.total).toBe('₹1,207.50'); expect(model.absentDays).toBe(2); expect(model.deliveredDays).toBe(17)
    expect(model.paid).toBe('₹1,000'); expect(model.pending).toBe('₹207.50')
    const text = billText(model)
    expect(text).toContain('Cow Milk 17 L x ₹60/L = ₹1,020'); expect(text).toContain('Cow Milk (extra) 1.5 L x ₹65/L = ₹97.50'); expect(text).toContain('Curd 1 kg x ₹90/kg = ₹90')
    expect(text).toContain('Absent 2 days (18 Oct, 19 Oct) - not charged'); expect(text).toContain('Payment Pending: ₹207.50'); expect(text.split('\n')[0]).toBe('Hello Rahul Sharma, your milk bill for October 2026:')
    // regular lines come before extra lines
    expect(model.lines.map(l => l.item)).toEqual(['Cow Milk', 'Cow Milk (extra)', 'Curd'])
  })
  it('customer with no milk gets a clear bill, not an empty one', async () => {
    await cust('Nobody')
    const data = await loadMonthly('2026-10')
    const model = buildBillModel(data.rows[0], '2026-10', [], 'Lucky Dairy', '₹')
    expect(billText(model)).toContain('No milk delivered'); expect(model.total).toBe('₹0')
  })
  it('makes real PDFs for one bill and for all bills', async () => {
    const a = await cust('Amit Kumar'), b = await cust('Venkata Subramanian Ramakrishnan Iyer')
    await saveEntries('2026-10-01', [{ customerId: a, productId: cow, regularMl: 2000, extraMl: 0, status: 'delivered' }, { customerId: b, productId: cow, regularMl: 1000, extraMl: 0, status: 'skipped' }])
    const data = await loadMonthly('2026-10')
    const all = await buildReportPdf(allBillsReport(data, 'Lucky Dairy', '₹'))
    expect(new TextDecoder().decode(all.bytes.slice(0, 5))).toBe('%PDF-'); expect(all.pages).toBe(1)
    const one = await buildReportPdf(customerBillReport(buildBillModel(data.rows[0], '2026-10', [], 'Lucky Dairy', '₹'), '2026-10'))
    expect(one.pages).toBe(1)
    const empty = await buildReportPdf(allBillsReport({ ...data, rows: [], totals: { ...data.totals, absentDays: 0 } }, 'Lucky Dairy', '₹'))
    expect(empty.pages).toBe(1)
  })
})
