import { useEffect, useId, useState, cloneElement, isValidElement, type ReactNode, type ReactElement } from 'react'
import { createPortal } from 'react-dom'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { formatMoney } from './money'
import { AppError } from './db'

// ---- currency (set from settings) ----
let currency = '₹'
export function setCurrency(c: string) { currency = c || '₹' }
export const getCurrency = () => currency
export const fmt = (paise: number) => formatMoney(paise, currency)

// ---- routing ----
export function useRoute(): string[] {
  const read = () => (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/')
  const [r, setR] = useState(read)
  useEffect(() => { const h = () => setR(read()); addEventListener('hashchange', h); return () => removeEventListener('hashchange', h) }, [])
  return r
}
export const go = (path: string) => { location.hash = '#/' + path }

// ---- toasts ----
type T = { id: number; msg: string; kind: 'ok' | 'err' | 'info' }
let toasts: T[] = []
let tsub: (() => void) | null = null
export function toast(msg: string, kind: T['kind'] = 'info') {
  const id = Date.now() + Math.random()
  toasts = [...toasts, { id, msg, kind }]
  tsub?.()
  setTimeout(() => { toasts = toasts.filter(t => t.id !== id); tsub?.() }, kind === 'err' ? 6000 : 2800)
}
export function errMsg(e: unknown, fallback = 'Something went wrong. Please try again.'): string {
  // Only our own readable errors are shown; internal database errors stay out of the UI.
  if (e instanceof AppError) return e.message
  console.error(e)
  return fallback
}
export function ToastHost() {
  const [, set] = useState(0)
  useEffect(() => { tsub = () => set(n => n + 1); return () => { tsub = null } }, [])
  return <div className="toasts" role="status" aria-live="polite">{toasts.map(t => <div key={t.id} className={`toast ${t.kind}`}>{t.msg}</div>)}</div>
}

// ---- confirm dialog (used only for destructive actions) ----
interface ConfirmOpts { title: string; body: ReactNode; confirmLabel: string; cancelLabel?: string; danger?: boolean; typeToConfirm?: string }
let confirmSet: ((o: (ConfirmOpts & { resolve: (v: boolean) => void }) | null) => void) | null = null
export function confirmDialog(o: ConfirmOpts): Promise<boolean> {
  return new Promise(resolve => { if (!confirmSet) return resolve(false); confirmSet({ ...o, resolve }) })
}
export function ConfirmHost() {
  const [o, setO] = useState<(ConfirmOpts & { resolve: (v: boolean) => void }) | null>(null)
  const [typed, setTyped] = useState('')
  useEffect(() => { confirmSet = setO; return () => { confirmSet = null } }, [])
  useEffect(() => {
    if (!o) return
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') { o.resolve(false); setO(null); setTyped('') } }
    addEventListener('keydown', h); return () => removeEventListener('keydown', h)
  }, [o])
  if (!o) return null
  const close = (v: boolean) => { o.resolve(v); setO(null); setTyped('') }
  const ok = !o.typeToConfirm || typed.trim() === o.typeToConfirm
  return createPortal(
    <div className="scrim" role="dialog" aria-modal="true" aria-label={o.title}>
      <div className="dialog stack">
        <h2 className="h2">{o.title}</h2>
        <div className="sub" style={{ color: 'var(--ink)' }}>{o.body}</div>
        {o.typeToConfirm && <Field label={`Type ${o.typeToConfirm} to continue`}><input className="in" value={typed} onChange={e => setTyped(e.target.value)} autoCapitalize="characters" /></Field>}
        <div className="row" style={{ marginTop: 16 }}>
          <button className="btn grow" onClick={() => close(false)}>{o.cancelLabel ?? 'Go back'}</button>
          <button className={`btn grow ${o.danger ? 'danger' : 'primary'}`} disabled={!ok} onClick={() => close(true)}>{o.confirmLabel}</button>
        </div>
      </div>
    </div>, document.body)
}

// ---- small pieces ----
export function Field({ label, hint, error, children }: { label: string; hint?: string; error?: string; children: ReactNode }) {
  const id = useId()
  const isControl = isValidElement(children) && typeof children.type === 'string' && ['input', 'select', 'textarea'].includes(children.type)
  const control = isControl ? cloneElement(children as ReactElement<any>, { id, 'aria-invalid': error ? true : undefined }) : children
  return <div className="field"><label htmlFor={isControl ? id : undefined}>{label}</label>{control}{hint && !error && <span className="hint">{hint}</span>}{error && <span className="err" role="alert">{error}</span>}</div>
}
export function Empty({ icon, title, text, action }: { icon: ReactNode; title: string; text?: string; action?: ReactNode }) {
  return <div className="empty">{icon}<div className="h2">{title}</div>{text && <p>{text}</p>}{action && <div style={{ marginTop: 14 }}>{action}</div>}</div>
}
export function Loading() { return <div className="spin" role="progressbar" aria-label="Loading" /> }
export function Seg<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { v: T; l: string }[] }) {
  return <div className="seg" role="tablist">{options.map(o => <button key={o.v} role="tab" aria-selected={value === o.v} className={value === o.v ? 'on' : ''} onClick={() => onChange(o.v)}>{o.l}</button>)}</div>
}
export function PageHead({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return <div className="pagehead"><div><h1 className="title">{title}</h1>{sub && <p className="sub">{sub}</p>}</div>{right}</div>
}
export function initials(name: string) { return name.trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase()).join('') || '?' }
export function useOnline() {
  const [on, set] = useState(navigator.onLine)
  useEffect(() => { const a = () => set(true), b = () => set(false); addEventListener('online', a); addEventListener('offline', b); return () => { removeEventListener('online', a); removeEventListener('offline', b) } }, [])
  return on
}

import { addMonths, monthLabel } from './dates'
export function MonthNav({ month, onChange, max }: { month: string; onChange: (m: string) => void; max?: string }) {
  return (
    <div className="row between" style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 14, padding: 4 }}>
      <button className="btn sm ghost" aria-label="Previous month" onClick={() => onChange(addMonths(month, -1))}><ChevronLeft size={20} /></button>
      <b>{monthLabel(month)}</b>
      <button className="btn sm ghost" aria-label="Next month" disabled={!!max && month >= max} onClick={() => onChange(addMonths(month, 1))}><ChevronRight size={20} /></button>
    </div>
  )
}
