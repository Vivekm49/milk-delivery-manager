import Dexie, { type Table } from 'dexie'
import type { Customer, Product, Rate, Entry, Pause, Bill, BillItem, Payment, Template, MessageLog, Setting, Group } from './types'
import { isBetween } from './dates'

export class MilkDB extends Dexie {
  customers!: Table<Customer, number>
  products!: Table<Product, number>
  rates!: Table<Rate, number>
  entries!: Table<Entry, number>
  pauses!: Table<Pause, number>
  bills!: Table<Bill, number>
  billItems!: Table<BillItem, number>
  payments!: Table<Payment, number>
  templates!: Table<Template, number>
  messageLog!: Table<MessageLog, number>
  settings!: Table<Setting, string>
  groups!: Table<Group, number>

  constructor(name = 'milk-delivery-manager') {
    super(name)
    this.version(1).stores({
      customers: '++id, code, name, mobile, area, status, productId',
      products: '++id, name, active',
      rates: '++id, productId, customerId, effectiveFrom, [productId+customerId]',
      entries: '++id, &[customerId+date], date, billId, productId',
      pauses: '++id, customerId',
      bills: '++id, customerId, fromDate, status, number',
      billItems: '++id, billId',
      payments: '++id, customerId, date',
      templates: '++id, key',
      messageLog: '++id, customerId, createdAt',
      settings: 'key'
    })
    // v2: a customer can have several products on the same day (cow + buffalo + curd...).
    this.version(2).stores({
      entries: '++id, &[customerId+date+productId], [customerId+date], date, billId, productId'
    })
    // v3: customer groups. Existing customers simply have no group; nothing is rewritten.
    this.version(3).stores({
      groups: '++id, &name',
      customers: '++id, code, name, mobile, area, status, productId, groupId'
    })
    // v4: delivery order of customers. Existing customers get no order until the owner reorders them.
    this.version(4).stores({
      customers: '++id, code, name, mobile, area, status, productId, groupId, sortOrder'
    })
  }
}

export const db = new MilkDB()

export const TABLES = ['customers', 'products', 'rates', 'entries', 'pauses', 'bills', 'billItems', 'payments', 'templates', 'messageLog', 'settings', 'groups'] as const

export const DEFAULT_TEMPLATES: Omit<Template, 'id'>[] = [
  { key: 'reminder', name: 'Payment reminder', builtin: true, body: 'Hello {Customer Name}, your milk bill for {Month} is ₹{Amount}. Pending amount: ₹{Balance}. Thank you.' },
  { key: 'delivery', name: 'Delivery message', builtin: true, body: "Hello {Customer Name}, today's milk delivery quantity is {Quantity}. Extra milk: {Extra Quantity}. Thank you." },
  { key: 'received', name: 'Payment received', builtin: true, body: 'Hello {Customer Name}, we received your payment of ₹{Paid Amount}. Your remaining balance is ₹{Balance}. Thank you.' }
]

export const DEFAULT_PRODUCTS: Omit<Product, 'id'>[] = [
  { name: 'Cow Milk', unit: 'L', active: true, createdAt: 0 },
  { name: 'Buffalo Milk', unit: 'L', active: true, createdAt: 0 },
  { name: 'Toned Milk', unit: 'L', active: true, createdAt: 0 },
  { name: 'Curd', unit: 'kg', active: true, createdAt: 0 },
  { name: 'Paneer', unit: 'kg', active: true, createdAt: 0 }
]

export interface AppSettings {
  setupDone: boolean
  businessName: string
  ownerName: string
  mobile: string
  address: string
  currency: string
  defaultProductId: number | null
  theme: 'light' | 'dark' | 'system'
}
export const DEFAULT_SETTINGS: AppSettings = {
  setupDone: false, businessName: '', ownerName: '', mobile: '', address: '', currency: '₹', defaultProductId: null, theme: 'system'
}

export async function getSettings(): Promise<AppSettings> {
  const rows = await db.settings.toArray()
  const out: Record<string, unknown> = { ...DEFAULT_SETTINGS }
  for (const r of rows) out[r.key] = r.value
  return out as unknown as AppSettings
}
export async function saveSettings(patch: Partial<AppSettings>) {
  await db.settings.bulkPut(Object.entries(patch).map(([key, value]) => ({ key, value })))
}
export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const r = await db.settings.get(key)
  return r ? (r.value as T) : fallback
}

/** Seeds products and message templates once. Never creates customers. */
export async function ensureSeed() {
  await db.transaction('rw', db.products, db.templates, async () => {
    if ((await db.products.count()) === 0) await db.products.bulkAdd(DEFAULT_PRODUCTS.map(p => ({ ...p, createdAt: Date.now() })))
    if ((await db.templates.count()) === 0) await db.templates.bulkAdd(DEFAULT_TEMPLATES)
  })
}

export async function resetDefaultTemplates() {
  await db.transaction('rw', db.templates, async () => {
    const all = await db.templates.toArray()
    for (const d of DEFAULT_TEMPLATES) {
      const ex = all.find(t => t.key === d.key)
      if (ex) await db.templates.update(ex.id!, { name: d.name, body: d.body, builtin: true })
      else await db.templates.add(d)
    }
  })
}

// ---------- rates ----------
export interface RateInfo { ratePaise: number; extraRatePaise: number }

export function resolveRate(rates: Rate[], customerId: number, productId: number, date: string): RateInfo | null {
  const pick = (cid: number) =>
    rates
      .filter(r => r.productId === productId && r.customerId === cid && r.effectiveFrom <= date)
      .sort((a, b) => (a.effectiveFrom === b.effectiveFrom ? (b.id ?? 0) - (a.id ?? 0) : b.effectiveFrom.localeCompare(a.effectiveFrom)))[0]
  const r = pick(customerId) ?? pick(0)
  if (!r) return null
  return { ratePaise: r.ratePaise, extraRatePaise: r.extraRatePaise ?? r.ratePaise }
}

/** What the product costs you on a date (latest standard rate that has a buy rate). null = not set. */
export function resolveBuyRate(rates: Rate[], productId: number, date: string): number | null {
  const r = rates
    .filter(x => x.productId === productId && x.customerId === 0 && x.effectiveFrom <= date && x.buyRatePaise != null)
    .sort((a, b) => (a.effectiveFrom === b.effectiveFrom ? (b.id ?? 0) - (a.id ?? 0) : b.effectiveFrom.localeCompare(a.effectiveFrom)))[0]
  return r ? r.buyRatePaise! : null
}

export async function addRate(productId: number, customerId: number, ratePaise: number, extraRatePaise: number | null, effectiveFrom: string, buyRatePaise?: number | null) {
  if (!Number.isInteger(ratePaise) || ratePaise <= 0) throw new Error('Enter a rate greater than zero')
  if (extraRatePaise !== null && (!Number.isInteger(extraRatePaise) || extraRatePaise <= 0)) throw new Error('Extra rate must be greater than zero')
  if (buyRatePaise != null && (!Number.isInteger(buyRatePaise) || buyRatePaise <= 0)) throw new Error('Buy rate must be greater than zero')
  // Same product/customer/date: replace instead of stacking duplicates.
  const same = await db.rates.where({ productId, customerId }).filter(r => r.effectiveFrom === effectiveFrom).first()
  if (same) await db.rates.update(same.id!, { ratePaise, extraRatePaise, ...(buyRatePaise !== undefined ? { buyRatePaise } : {}) })
  else await db.rates.add({ productId, customerId, ratePaise, extraRatePaise, ...(customerId === 0 && buyRatePaise !== undefined ? { buyRatePaise } : {}), effectiveFrom, createdAt: Date.now() })
}

// ---------- ledger ----------
export function balanceOf(customer: Customer, bills: Bill[], payments: Payment[]): number {
  const billed = bills.filter(b => b.customerId === customer.id && b.status === 'issued').reduce((s, b) => s + b.totalPaise, 0)
  const paid = payments.filter(p => p.customerId === customer.id && !p.voided).reduce((s, p) => s + p.amountPaise, 0)
  return customer.openingPaise + billed - paid
}

export async function customerBalance(customerId: number): Promise<number> {
  const c = await db.customers.get(customerId)
  if (!c) return 0
  const [bills, payments] = await Promise.all([db.bills.where('customerId').equals(customerId).toArray(), db.payments.where('customerId').equals(customerId).toArray()])
  return balanceOf(c, bills, payments)
}

export async function nextCustomerCode(): Promise<string> {
  const all = await db.customers.toArray()
  let max = 0
  for (const c of all) { const m = /^C(\d+)$/.exec(c.code); if (m) max = Math.max(max, parseInt(m[1], 10)) }
  return 'C' + String(max + 1).padStart(3, '0')
}

export function isPausedOn(pauses: Pause[], customerId: number, date: string): boolean {
  return pauses.some(p => p.customerId === customerId && isBetween(date, p.from, p.to))
}

export class AppError extends Error {}
