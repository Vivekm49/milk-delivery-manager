import { db } from './db'
import { buildLines, discountsInMonth, quantityText } from './billing'
import { sortCustomers } from './customers'
import { dayStatuses, dayCounts, type DayStatus } from './absent'
import { computeOwed, payStatus, type PayStatus } from './owed'
import { monthEnd, monthStart } from './dates'
import { UNITS } from './money'
import type { Customer } from './types'

export interface MonthlyRow {
  customer: Customer; qtyText: string; amountPaise: number
  delivered: number; absent: number; paused: number; absentDates: string[]
  paidThisMonth: number; owed: number; status: PayStatus; days: Map<string, DayStatus>
  lines: ReturnType<typeof buildLines>['lines']; discountPaise: number
}
export interface MonthlyData {
  month: string; rows: MonthlyRow[]
  totals: { customers: number; quantity: string; amountPaise: number; collectedPaise: number; pendingPaise: number; absentDays: number; absentCustomers: number }
}

/** Everything the Monthly and Bill tabs show, from the same numbers (so they always agree). */
export async function loadMonthly(month: string): Promise<MonthlyData> {
  const [customers, entries, rates, products, bills, payments, pauses, unbilled] = await Promise.all([
    db.customers.toArray(),
    db.entries.where('date').between(monthStart(month), monthEnd(month), true, true).toArray(),
    db.rates.toArray(), db.products.toArray(), db.bills.toArray(), db.payments.toArray(), db.pauses.toArray(),
    db.entries.filter(e => e.billId === null && e.status === 'delivered').toArray()
  ])
  const pmap = new Map(products.map(p => [p.id!, p]))
  const owed = computeOwed(customers, bills, payments, unbilled, rates, pmap)
  const live = customers.filter(c => c.startDate <= monthEnd(month) && (c.status !== 'inactive' || entries.some(e => e.customerId === c.id) || (owed.get(c.id!) ?? 0) !== 0))
  const rows: MonthlyRow[] = sortCustomers(live).map(c => {
    const mine = entries.filter(e => e.customerId === c.id)
    const { lines } = buildLines(mine, rates, pmap)
    const discountPaise = discountsInMonth(bills, month, c.id)
    const gross = lines.reduce((s, l) => s + l.amountPaise, 0)
    const days = dayStatuses(mine, pauses, c, month)
    const counts = dayCounts(days)
    const paid = payments.filter(p => p.customerId === c.id && !p.voided && p.date.slice(0, 7) === month).reduce((s, p) => s + p.amountPaise, 0)
    const o = owed.get(c.id!) ?? 0
    const unit = pmap.get(c.productId)?.unit ?? 'L'
    return { customer: c, qtyText: quantityText(lines, unit), amountPaise: Math.max(0, gross - discountPaise), delivered: counts.delivered, absent: counts.absent, paused: counts.paused, absentDates: counts.absentDates, paidThisMonth: paid, owed: o, status: payStatus(o, paid), days, lines, discountPaise }
  })
  const allLines = rows.flatMap(r => r.lines)
  return {
    month, rows,
    totals: {
      customers: customers.filter(c => c.status === 'active').length,
      quantity: quantityText(allLines, 'L'),
      amountPaise: rows.reduce((s, r) => s + r.amountPaise, 0),
      collectedPaise: payments.filter(p => !p.voided && p.date.slice(0, 7) === month).reduce((s, p) => s + p.amountPaise, 0),
      pendingPaise: customers.reduce((s, c) => s + Math.max(0, owed.get(c.id!) ?? 0), 0),
      absentDays: rows.reduce((s, r) => s + r.absent, 0),
      absentCustomers: rows.filter(r => r.absent > 0).length
    }
  }
}
export const unitShort = (u: keyof typeof UNITS) => UNITS[u].short
