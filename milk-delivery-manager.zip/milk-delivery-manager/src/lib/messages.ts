import { db, resolveRate, customerBalance } from './db'
import { formatMoney, formatQty, phoneDigits, UNITS, type UnitKey } from './money'
import { dateLabel, monthEnd, monthLabel, monthStart, todayISO } from './dates'
import { previewBill } from './billing'
import type { Customer } from './types'

export const PLACEHOLDERS = ['Customer Name', 'Mobile Number', 'Date', 'Month', 'Quantity', 'Extra Quantity', 'Amount', 'Paid Amount', 'Balance', 'Product', 'Rate'] as const

export type Ctx = Record<string, string>

/** Replace {Placeholders} (case-insensitive). Unknown placeholders are left untouched. Money placeholders carry no symbol, templates add ₹. */
export function renderTemplate(body: string, ctx: Ctx): string {
  const map = new Map(Object.entries(ctx).map(([k, v]) => [k.toLowerCase(), v]))
  return body.replace(/\{([^{}]+)\}/g, (m, k: string) => map.get(k.trim().toLowerCase()) ?? m)
}

const plain = (paise: number) => formatMoney(paise, '').replace(/^-/, '-')

export async function buildContext(c: Customer, month: string, date = todayISO()): Promise<Ctx> {
  const [product, rates, entry, payments, balance, bills] = await Promise.all([
    db.products.get(c.productId), db.rates.toArray(),
    db.entries.where('[customerId+date]').equals([c.id!, date]).first(),
    db.payments.where('customerId').equals(c.id!).toArray(),
    customerBalance(c.id!),
    db.bills.where('customerId').equals(c.id!).toArray()
  ])
  const unit: UnitKey = product?.unit ?? 'L'
  const billed = bills.filter(b => b.status === 'issued' && b.fromDate >= monthStart(month) && b.fromDate <= monthEnd(month)).reduce((s, b) => s + b.totalPaise, 0)
  const unbilled = (await previewBill({ customerId: c.id!, kind: 'monthly', from: monthStart(month), to: monthEnd(month) })).subtotal
  const lastPay = payments.filter(p => !p.voided).sort((a, b) => b.createdAt - a.createdAt)[0]
  const r = resolveRate(rates, c.id!, c.productId, date)
  const regular = entry && entry.status === 'delivered' ? entry.regularMl : c.dailyMl
  const extra = entry && entry.status === 'delivered' ? entry.extraMl : 0
  return {
    'Customer Name': c.name, 'Mobile Number': c.mobile, Date: dateLabel(date), Month: monthLabel(month),
    Quantity: formatQty(regular + extra, unit), 'Extra Quantity': extra === 0 ? 'none' : formatQty(extra, unit),
    Amount: plain(billed + unbilled), 'Paid Amount': plain(lastPay?.amountPaise ?? 0), Balance: plain(balance),
    Product: product?.name ?? '', Rate: r ? `${plain(r.ratePaise)}/${UNITS[unit].short}` : '-'
  }
}

export type Channel = 'whatsapp' | 'sms'

/** Builds an official deep link. Opening it does NOT mean the message was sent; the user presses send in the app. */
export function messageLink(channel: Channel, c: Customer, text: string): string {
  const enc = encodeURIComponent(text)
  if (channel === 'whatsapp') return `https://wa.me/${phoneDigits(c.whatsapp || c.mobile)}?text=${enc}`
  return `sms:${phoneDigits(c.mobile).replace(/^91/, '+91')}?body=${enc}`
}

export async function logOpened(customerId: number, channel: Channel, body: string) {
  await db.messageLog.add({ customerId, channel, body, createdAt: Date.now(), status: 'opened' })
}
