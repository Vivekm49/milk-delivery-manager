import { db, resolveRate, getSettings } from './db'
import { customerOwed } from './owed'
import { formatMoney, formatQty, phoneDigits, UNITS, type UnitKey } from './money'
import { currentMonth, dateLabel, monthEnd, monthLabel, monthStart, todayISO } from './dates'
import { previewBill, monthSummary } from './billing'
import type { Customer, Product } from './types'

export const PLACEHOLDERS = ['Customer Name', 'Mobile Number', 'Date', 'Month', 'Quantity', 'Extra Quantity', 'Total Quantity', 'Milk Details', 'Today Details', 'Amount', 'Current Month Amount', 'Paid Amount', 'Balance', 'Product', 'Rate'] as const
/** Tags whose value is money. They are shown without a currency symbol, so tapping the tag inserts the symbol too. */
export const MONEY_TAGS = new Set<string>(['Amount', 'Current Month Amount', 'Paid Amount', 'Balance', 'Rate'])
/** Short forms like {{total_quantity}} also work. */
const ALIASES: Record<string, string> = { total_quantity: 'total quantity', current_month_amount: 'current month amount' }

/** Tags made from the product list: {Cow Milk Quantity}, {Cow Milk Amount}, {Cow Milk Rate}. A new product gets its tags by itself. */
export const PRODUCT_TAG_KINDS = ['Quantity', 'Amount', 'Rate'] as const
export function productTags(products: Product[]): { product: Product; tags: string[] }[] {
  return products.map(p => ({ product: p, tags: PRODUCT_TAG_KINDS.map(k => `${p.name} ${k}`) }))
}
export const isMoneyTag = (tag: string) => MONEY_TAGS.has(tag) || / Amount$/.test(tag)

export type Ctx = Record<string, string>

/** Replace {Placeholders} (case-insensitive). Unknown placeholders are left untouched. Money placeholders carry no symbol, templates add ₹. */
export function renderTemplate(body: string, ctx: Ctx): string {
  const map = new Map(Object.entries(ctx).map(([k, v]) => [k.toLowerCase(), v]))
  const look = (k: string) => { const key = k.trim().toLowerCase(); return map.get(ALIASES[key] ?? key) }
  // A tag we do not know is removed instead of being sent to the customer as {something}.
  return body
    .replace(/\{\{\s*([^{}]+?)\s*\}\}/g, (_m, k: string) => look(k) ?? '')
    .replace(/\{([^{}]+)\}/g, (_m, k: string) => look(k) ?? '')
    .replace(/[ \t]{2,}/g, ' ').replace(/ +([.,!?])/g, '$1').trim()
}

/** Tags in a template that the app does not recognise (typos). */
export function findUnknownTags(body: string, products: Product[] = []): string[] {
  const known = new Set([...PLACEHOLDERS.map(p => p.toLowerCase()), ...Object.keys(ALIASES), ...productTags(products).flatMap(x => x.tags.map(t => t.toLowerCase()))])
  const found = new Set<string>()
  for (const m of body.matchAll(/\{\{?\s*([^{}]+?)\s*\}?\}/g)) if (!known.has(m[1].trim().toLowerCase())) found.add(m[0])
  return [...found]
}

const plain = (paise: number) => formatMoney(paise, '').replace(/^-/, '-')

export async function buildContext(c: Customer, month: string, date = todayISO()): Promise<Ctx> {
  const [product, rates, entry, payments, owed, bills, products, settings] = await Promise.all([
    db.products.get(c.productId), db.rates.toArray(),
    db.entries.where('[customerId+date]').equals([c.id!, date]).toArray(),
    db.payments.where('customerId').equals(c.id!).toArray(),
    customerOwed(c.id!),
    db.bills.where('customerId').equals(c.id!).toArray(),
    db.products.toArray(), getSettings()
  ])
  const sym = settings.currency || '₹'
  const unit: UnitKey = product?.unit ?? 'L'
  const billed = bills.filter(b => b.status === 'issued' && b.fromDate >= monthStart(month) && b.fromDate <= monthEnd(month)).reduce((s, b) => s + b.totalPaise, 0)
  const unbilled = (await previewBill({ customerId: c.id!, kind: 'monthly', from: monthStart(month), to: monthEnd(month) })).subtotal
  const summary = await monthSummary(c.id!, currentMonth(), unit) // always the real current calendar month
  const selected = month === currentMonth() ? summary : await monthSummary(c.id!, month, unit)
  const lastPay = payments.filter(p => !p.voided).sort((a, b) => b.createdAt - a.createdAt)[0]
  const r = resolveRate(rates, c.id!, c.productId, date)
  // Today's delivered lines that use the same unit as the customer's main product are added together.
  const delivered = entry.filter(e => e.status === 'delivered')
  const sameUnit = delivered.filter(e => products.find(p => p.id === e.productId)?.unit === unit)
  const hasToday = sameUnit.length > 0
  const regular = hasToday ? sameUnit.reduce((s, e) => s + e.regularMl, 0) : c.dailyMl
  const extra = hasToday ? sameUnit.reduce((s, e) => s + e.extraMl, 0) : 0

  // One line per milk type for the chosen month, e.g. "Cow Milk 12 L x ₹60 = ₹720".
  const per = new Map<number, { name: string; unit: UnitKey; qty: number; amount: number; rates: Set<number> }>()
  for (const l of selected.lines) {
    const x = per.get(l.productId) ?? { name: l.productName, unit: l.unit, qty: 0, amount: 0, rates: new Set<number>() }
    x.qty += l.qtyMilli; x.amount += l.amountPaise; x.rates.add(l.ratePaise); per.set(l.productId, x)
  }
  const milkLines = [...per.values()].sort((a, b) => a.name.localeCompare(b.name)).map(x =>
    `${x.name} ${formatQty(x.qty, x.unit)}${x.rates.size === 1 ? ` x ${formatMoney([...x.rates][0], sym)}` : ''} = ${formatMoney(x.amount, sym)}`)
  const todayLines = delivered.map(e => ({ name: products.find(p => p.id === e.productId)?.name ?? '', text: formatQty(e.regularMl + e.extraMl, products.find(p => p.id === e.productId)?.unit ?? 'L') }))
    .sort((a, b) => a.name.localeCompare(b.name)).map(x => `${x.name} ${x.text}`)

  const ctx: Ctx = {
    'Customer Name': c.name, 'Mobile Number': c.mobile || '-', Date: dateLabel(date), Month: monthLabel(month),
    Quantity: formatQty(regular + extra, unit), 'Extra Quantity': extra === 0 ? 'none' : formatQty(extra, unit),
    'Total Quantity': summary.quantity, 'Current Month Amount': plain(summary.amountPaise),
    'Milk Details': milkLines.length ? milkLines.join('\n') : 'No milk delivered', 'Today Details': todayLines.length ? todayLines.join(', ') : 'No delivery today',
    Amount: plain(billed + unbilled), 'Paid Amount': plain(lastPay?.amountPaise ?? 0), Balance: plain(owed),
    Product: product?.name ?? '', Rate: r ? `${plain(r.ratePaise)}/${UNITS[unit].short}` : '-'
  }
  for (const p of products) {
    const mine = per.get(p.id!)
    const rate = resolveRate(rates, c.id!, p.id!, date)
    ctx[`${p.name} Quantity`] = mine ? formatQty(mine.qty, p.unit) : `0 ${p.unit === 'pc' ? 'pc' : p.unit === 'kg' ? 'kg' : 'L'}`
    ctx[`${p.name} Amount`] = plain(mine?.amount ?? 0)
    ctx[`${p.name} Rate`] = rate ? `${plain(rate.ratePaise)}/${UNITS[p.unit].short}` : '-'
  }
  return ctx
}

export type Channel = 'whatsapp' | 'sms'

/** Builds an official deep link. Opening it does NOT mean the message was sent; the user presses send in the app. */
export function hasPhone(c: Customer, channel: Channel = 'sms'): boolean {
  return !!(channel === 'whatsapp' ? c.whatsapp || c.mobile : c.mobile).trim()
}

export function messageLink(channel: Channel, c: Customer, text: string): string {
  const enc = encodeURIComponent(text)
  if (channel === 'whatsapp') return `https://wa.me/${phoneDigits(c.whatsapp || c.mobile)}?text=${enc}`
  return `sms:${phoneDigits(c.mobile).replace(/^91/, '+91')}?body=${enc}`
}

export async function logOpened(customerId: number, channel: Channel, body: string) {
  await db.messageLog.add({ customerId, channel, body, createdAt: Date.now(), status: 'opened' })
}
