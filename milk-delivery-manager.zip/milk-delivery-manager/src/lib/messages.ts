import { db, resolveRate, customerBalance } from './db'
import { formatMoney, formatQty, phoneDigits, UNITS, type UnitKey } from './money'
import { currentMonth, dateLabel, monthEnd, monthLabel, monthStart, todayISO } from './dates'
import { previewBill, monthSummary } from './billing'
import type { Customer } from './types'

export const PLACEHOLDERS = ['Customer Name', 'Mobile Number', 'Date', 'Month', 'Quantity', 'Extra Quantity', 'Total Quantity', 'Amount', 'Current Month Amount', 'Paid Amount', 'Balance', 'Product', 'Rate'] as const
/** Tags whose value is money. They are shown without a currency symbol, so tapping the tag inserts the symbol too. */
export const MONEY_TAGS = new Set<string>(['Amount', 'Current Month Amount', 'Paid Amount', 'Balance', 'Rate'])
/** Short forms like {{total_quantity}} also work. */
const ALIASES: Record<string, string> = { total_quantity: 'total quantity', current_month_amount: 'current month amount' }

export type Ctx = Record<string, string>

/** Replace {Placeholders} (case-insensitive). Unknown placeholders are left untouched. Money placeholders carry no symbol, templates add ₹. */
export function renderTemplate(body: string, ctx: Ctx): string {
  const map = new Map(Object.entries(ctx).map(([k, v]) => [k.toLowerCase(), v]))
  const look = (k: string) => { const key = k.trim().toLowerCase(); return map.get(ALIASES[key] ?? key) }
  // A tag we do not know is removed instead of being sent to the customer as {something}.
  return body
    .replace(/\{\{\s*([^{}]+?)\s*\}\}/g, (_m, k: string) => look(k) ?? '')
    .replace(/\{([^{}]+)\}/g, (_m, k: string) => look(k) ?? '')
    .replace(/[ \t]{2,}/g, ' ').replace(/ +([.,!?])/g, '$1').trim()
}

/** Tags in a template that the app does not recognise (typos). */
export function findUnknownTags(body: string): string[] {
  const known = new Set([...PLACEHOLDERS.map(p => p.toLowerCase()), ...Object.keys(ALIASES)])
  const found = new Set<string>()
  for (const m of body.matchAll(/\{\{?\s*([^{}]+?)\s*\}?\}/g)) if (!known.has(m[1].trim().toLowerCase())) found.add(m[0])
  return [...found]
}

const plain = (paise: number) => formatMoney(paise, '').replace(/^-/, '-')

export async function buildContext(c: Customer, month: string, date = todayISO()): Promise<Ctx> {
  const [product, rates, entry, payments, balance, bills] = await Promise.all([
    db.products.get(c.productId), db.rates.toArray(),
    db.entries.where('[customerId+date]').equals([c.id!, date]).toArray(),
    db.payments.where('customerId').equals(c.id!).toArray(),
    customerBalance(c.id!),
    db.bills.where('customerId').equals(c.id!).toArray()
  ])
  const unit: UnitKey = product?.unit ?? 'L'
  const billed = bills.filter(b => b.status === 'issued' && b.fromDate >= monthStart(month) && b.fromDate <= monthEnd(month)).reduce((s, b) => s + b.totalPaise, 0)
  const unbilled = (await previewBill({ customerId: c.id!, kind: 'monthly', from: monthStart(month), to: monthEnd(month) })).subtotal
  const summary = await monthSummary(c.id!, currentMonth(), unit) // always the real current calendar month
  const lastPay = payments.filter(p => !p.voided).sort((a, b) => b.createdAt - a.createdAt)[0]
  const r = resolveRate(rates, c.id!, c.productId, date)
  // Today's delivered lines that use the same unit as the customer's main product are added together.
  const same = entry.filter(e => e.status === 'delivered')
  const prods = await db.products.toArray()
  const sameUnit = same.filter(e => prods.find(p => p.id === e.productId)?.unit === unit)
  const hasToday = sameUnit.length > 0
  const regular = hasToday ? sameUnit.reduce((s, e) => s + e.regularMl, 0) : c.dailyMl
  const extra = hasToday ? sameUnit.reduce((s, e) => s + e.extraMl, 0) : 0
  return {
    'Customer Name': c.name, 'Mobile Number': c.mobile || '-', Date: dateLabel(date), Month: monthLabel(month),
    Quantity: formatQty(regular + extra, unit), 'Extra Quantity': extra === 0 ? 'none' : formatQty(extra, unit),
    'Total Quantity': summary.quantity, 'Current Month Amount': plain(summary.amountPaise),
    Amount: plain(billed + unbilled), 'Paid Amount': plain(lastPay?.amountPaise ?? 0), Balance: plain(balance),
    Product: product?.name ?? '', Rate: r ? `${plain(r.ratePaise)}/${UNITS[unit].short}` : '-'
  }
}

export type Channel = 'whatsapp' | 'sms'

/** Builds an official deep link. Opening it does NOT mean the message was sent; the user presses send in the app. */
export function hasPhone(c: Customer, channel: Channel = 'sms'): boolean {
  return !!(channel === 'whatsapp' ? c.whatsapp || c.mobile : c.mobile).trim()
}

export function messageLink(channel: Channel, c: Customer, text: string): string {
  const enc = encodeURIComponent(text)
  if (channel === 'whatsapp') return `https://wa.me/${phoneDigits(c.whatsapp || c.mobile)}?text=${enc}`
  return `sms:${phoneDigits(c.mobile).replace(/^91/, '+91')}?body=${enc}`
}

export async function logOpened(customerId: number, channel: Channel, body: string) {
  await db.messageLog.add({ customerId, channel, body, createdAt: Date.now(), status: 'opened' })
}
