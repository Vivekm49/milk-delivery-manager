import { db, resolveBuyRate } from './db'
import { buildLines, discountsInMonth } from './billing'
import { amountFor, UNITS, type UnitKey } from './money'
import { monthEnd, monthStart } from './dates'

export interface ProfitRow { productId: number; name: string; unit: UnitKey; qtyMilli: number; revenue: number; cost: number; profit: number; perUnit: number | null; hasBuy: boolean; sellRate: number | null; buyRate: number | null }
export interface ProfitReport { month: string; rows: ProfitRow[]; revenue: number; discounts: number; cost: number; net: number; missingBuy: string[] }

/** Profit and loss for a month: what you sold (with the rate on each day) minus what the milk cost you (buy rate on each day). */
export async function loadProfit(month: string): Promise<ProfitReport> {
  const [entries, rates, products, bills] = await Promise.all([
    db.entries.where('date').between(monthStart(month), monthEnd(month), true, true).toArray(), db.rates.toArray(), db.products.toArray(), db.bills.toArray()
  ])
  const pmap = new Map(products.map(p => [p.id!, p]))
  const delivered = entries.filter(e => e.status === 'delivered')
  const { lines } = buildLines(delivered, rates, pmap)
  const revenueBy = new Map<number, number>(); const qtyBy = new Map<number, number>(); const sellBy = new Map<number, number>()
  for (const l of lines) { revenueBy.set(l.productId, (revenueBy.get(l.productId) ?? 0) + l.amountPaise); qtyBy.set(l.productId, (qtyBy.get(l.productId) ?? 0) + l.qtyMilli); if (l.kind === 'regular') sellBy.set(l.productId, l.ratePaise) }
  // cost: group by product and buy rate, round once per group
  const groups = new Map<string, { pid: number; buy: number; qty: number }>()
  const noBuy = new Set<number>()
  for (const e of delivered) {
    const buy = resolveBuyRate(rates, e.productId, e.date)
    if (buy === null) { noBuy.add(e.productId); continue }
    const k = `${e.productId}|${buy}`
    const g = groups.get(k) ?? { pid: e.productId, buy, qty: 0 }
    g.qty += e.regularMl + e.extraMl; groups.set(k, g)
  }
  const costBy = new Map<number, number>()
  for (const g of groups.values()) costBy.set(g.pid, (costBy.get(g.pid) ?? 0) + amountFor(g.qty, g.buy, UNITS[pmap.get(g.pid)!.unit].milliPerUnit))
  const rows: ProfitRow[] = [...qtyBy.keys()].map(pid => {
    const p = pmap.get(pid)!; const revenue = revenueBy.get(pid) ?? 0; const cost = costBy.get(pid) ?? 0; const qty = qtyBy.get(pid) ?? 0
    const hasBuy = !noBuy.has(pid)
    const profit = hasBuy ? revenue - cost : 0
    return { productId: pid, name: p.name, unit: p.unit, qtyMilli: qty, revenue, cost, profit, perUnit: hasBuy && qty > 0 ? Math.round((profit * UNITS[p.unit].milliPerUnit) / qty) : null, hasBuy, sellRate: sellBy.get(pid) ?? null, buyRate: resolveBuyRate(rates, pid, monthEnd(month)) }
  }).sort((a, b) => a.name.localeCompare(b.name))
  const revenue = rows.reduce((s, r) => s + r.revenue, 0)
  const discounts = discountsInMonth(bills, month)
  const cost = rows.reduce((s, r) => s + r.cost, 0)
  return { month, rows, revenue, discounts, cost, net: revenue - discounts - cost, missingBuy: rows.filter(r => !r.hasBuy).map(r => r.name) }
}
