export function pad(n: number) { return String(n).padStart(2, '0') }
export function toISO(d: Date): string { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` }
export function todayISO(): string { return toISO(new Date()) }
export function monthOf(iso: string): string { return iso.slice(0, 7) }
export function currentMonth(): string { return todayISO().slice(0, 7) }
export function monthStart(m: string): string { return `${m}-01` }
export function monthEnd(m: string): string {
  const [y, mo] = m.split('-').map(Number)
  return `${m}-${pad(new Date(y, mo, 0).getDate())}`
}
export function addDays(iso: string, n: number): string {
  const [y, m, d] = iso.split('-').map(Number)
  return toISO(new Date(y, m - 1, d + n))
}
export function addMonths(m: string, n: number): string {
  const [y, mo] = m.split('-').map(Number)
  const d = new Date(y, mo - 1 + n, 1)
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`
}
export function daysBetween(from: string, to: string): string[] {
  const out: string[] = []
  for (let d = from; d <= to; d = addDays(d, 1)) out.push(d)
  return out
}
export function isValidISO(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false
  const [y, m, d] = s.split('-').map(Number)
  const dt = new Date(y, m - 1, d)
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d
}
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']
export function monthLabel(m: string): string {
  const [y, mo] = m.split('-').map(Number)
  return `${MONTHS[mo - 1]} ${y}`
}
export function dateLabel(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number)
  return `${d} ${MONTHS[m - 1].slice(0, 3)} ${y}`
}
export function isBetween(d: string, from: string, to: string | null) { return d >= from && (to === null || d <= to) }
