import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Capacitor } from '@capacitor/core'
import './styles.css'
import App from './App'

// Ask the browser to keep our data safe from automatic cleanup.
navigator.storage?.persist?.().catch(() => {})

// Service worker is for the installable web version only; the Android app already ships all files inside it.
if (!Capacitor.isNativePlatform() && 'serviceWorker' in navigator) {
  import('virtual:pwa-register').then(m => m.registerSW({ immediate: true })).catch(() => {})
}

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)
