// @vitest-environment jsdom
import 'fake-indexeddb/auto'
import { describe, it, expect, beforeAll } from 'vitest'
import { render, screen, fireEvent, waitFor, within, cleanup } from '@testing-library/react'
import { db } from './lib/db'
import { eraseAll } from './lib/backup'
import App from './App'

beforeAll(() => {
  window.matchMedia = window.matchMedia || ((q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}, onchange: null, dispatchEvent: () => false }) as any)
  Element.prototype.scrollIntoView = () => {}
})

const type = (el: HTMLElement, v: string) => fireEvent.change(el, { target: { value: v } })
const go = (h: string) => { location.hash = h; window.dispatchEvent(new HashChangeEvent('hashchange')) }

describe('app smoke test (jsdom, real Dexie)', () => {
  it('runs first-run setup, daily entry, billing and payment end to end', async () => {
    await eraseAll()
    render(<App />)
    await screen.findByText('Welcome')
    type(screen.getByLabelText('Business name'), 'Lucky Dairy')
    fireEvent.click(screen.getByText('Continue'))
    // step 2: rate
    const rate = await screen.findByLabelText(/Rate per/)
    type(rate, '60')
    fireEvent.click(screen.getByText('Continue'))
    // step 3: first customer
    type(await screen.findByLabelText('Name'), 'Rahul Sharma')
    type(screen.getByLabelText('Mobile number'), '9876543210')
    type(screen.getByLabelText('Area'), 'North')
    fireEvent.click(screen.getByText('Save customer and start'))
    await screen.findByText('Lucky Dairy')
    expect(await db.customers.count()).toBe(1)
    expect(screen.getByText("Today's milk")).toBeTruthy()

    // daily entry
    go('#/entry')
    await screen.findByText('Rahul Sharma')
    fireEvent.click(screen.getByLabelText('Increase extra for Rahul Sharma'))
    fireEvent.click(screen.getByRole('button', { name: '+500 ml' }))
    fireEvent.click(screen.getByText('Delivered?'))
    await screen.findByText('Unsaved')
    fireEvent.click(screen.getByText('Save all'))
    await waitFor(async () => expect(await db.entries.count()).toBe(1))
    const e = (await db.entries.toArray())[0]
    expect(e.regularMl).toBe(1000); expect(e.extraMl).toBe(750); expect(e.status).toBe('delivered')
    await screen.findByText('Saved')

    // dashboard reflects it
    go('#/dashboard')
    await screen.findByText('1 of 1 deliveries done')

    // billing
    go('#/billing/new')
    const sel = await screen.findByLabelText('Customer')
    const cid = String((await db.customers.toArray())[0].id)
    fireEvent.change(sel, { target: { value: cid } })
    await screen.findByText('Preview')
    await waitFor(() => expect(screen.getAllByText(/₹/).length).toBeGreaterThan(0))
    fireEvent.click(screen.getAllByText('Generate bill').slice(-1)[0])
    await waitFor(async () => expect(await db.bills.count()).toBe(1))
    expect((await db.bills.toArray())[0].totalPaise).toBe(Math.round(1750 * 60 / 1000 * 100))

    // payment
    go('#/payments')
    fireEvent.change(await screen.findByLabelText('Customer'), { target: { value: cid } })
    type(screen.getByLabelText('Amount'), '50')
    fireEvent.click(screen.getByText('Record payment'))
    await waitFor(async () => expect(await db.payments.count()).toBe(1))
  }, 30000)

  it('renders every screen without crashing', async () => {
    const routes: [string, RegExp][] = [
      ['#/dashboard', /Recent activity/], ['#/customers', /Customers/], ['#/entry', /Daily Entry/], ['#/billing', /Billing/], ['#/payments', /Payment history/],
      ['#/messages', /Messages/], ['#/reports', /Reports/], ['#/products', /Products & Rates/], ['#/settings', /Backup and restore/], ['#/more', /More/]
    ]
    for (const [h, re] of routes) { go(h); await screen.findAllByText(re) }
    const id = (await db.customers.toArray())[0].id
    for (const h of [`#/customers/${id}`, `#/customers/${id}/edit`, `#/customers/new`, `#/billing/view/1`]) { go(h); await waitFor(() => expect(document.querySelector('.main')!.textContent!.length).toBeGreaterThan(20)) }
    go(`#/customers/${id}`)
    await screen.findByText('Rahul Sharma')
    for (const tab of ['Bills', 'Payments', 'Rates', 'Message', 'Deliveries']) fireEvent.click(within(document.querySelector('.seg') as HTMLElement).getByText(tab))
    go('#/messages'); fireEvent.click(await screen.findByText('Templates')); await screen.findByText('Payment reminder')
    go('#/reports'); fireEvent.click(await screen.findByText('Monthly')); fireEvent.click(screen.getByText('Customer')); await screen.findAllByText(/Reports/)
    cleanup()
  }, 30000)
})
