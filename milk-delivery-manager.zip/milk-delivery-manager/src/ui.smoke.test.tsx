// @vitest-environment jsdom
import 'fake-indexeddb/auto'
import { describe, it, expect, beforeAll, vi } from 'vitest'
import { render, screen, fireEvent, waitFor, within, cleanup } from '@testing-library/react'
import { db } from './lib/db'
import { eraseAll } from './lib/backup'
import { todayISO, addDays } from './lib/dates'
import App from './App'

beforeAll(() => {
  window.matchMedia = window.matchMedia || ((q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}, onchange: null, dispatchEvent: () => false }) as any)
  Element.prototype.scrollIntoView = () => {}
})

const type = (el: HTMLElement, v: string) => fireEvent.change(el, { target: { value: v } })
const go = (h: string) => { location.hash = h; window.dispatchEvent(new HashChangeEvent('hashchange')) }

describe('app smoke test (jsdom, real Dexie)', () => {
  it('runs first-run setup, daily entry, billing and payment end to end', async () => {
    await eraseAll()
    render(<App />)
    await screen.findByText('Welcome')
    type(screen.getByLabelText('Business name'), 'Lucky Dairy')
    fireEvent.click(screen.getByText('Continue'))
    // step 2: rate
    const rate = await screen.findByLabelText(/Rate per/)
    type(rate, '60')
    fireEvent.click(screen.getByText('Continue'))
    // step 3: first customer
    type(await screen.findByLabelText('Name'), 'Rahul Sharma')
    type(screen.getByLabelText('Area'), 'North')
    fireEvent.click(screen.getByText('Save customer and start'))
    await screen.findByText('Lucky Dairy')
    expect(await db.customers.count()).toBe(1)
    expect((await db.customers.toArray())[0].mobile).toBe('') // phone number is optional
    expect(screen.getByText("Today's milk")).toBeTruthy()

    // daily entry
    go('#/entry')
    await screen.findByText('Rahul Sharma')
    fireEvent.click(screen.getByLabelText('Increase extra for Rahul Sharma'))
    fireEvent.click(screen.getByLabelText('More actions for Rahul Sharma'))
    fireEvent.click(screen.getByRole('menuitem', { name: /\+500 ml extra/ }))
    fireEvent.click(screen.getByText('Delivered?'))
    await screen.findByText('Unsaved')
    fireEvent.click(screen.getByText('Save all'))
    await waitFor(async () => expect(await db.entries.count()).toBe(1))
    const e = (await db.entries.toArray())[0]
    expect(e.regularMl).toBe(1000); expect(e.extraMl).toBe(750); expect(e.status).toBe('delivered')
    await screen.findByText('Saved')

    // dashboard reflects it
    go('#/dashboard')
    await screen.findByText('1 of 1 deliveries done')

    // billing
    go('#/billing/new')
    const sel = await screen.findByLabelText('Customer')
    const cid = String((await db.customers.toArray())[0].id)
    fireEvent.change(sel, { target: { value: cid } })
    await screen.findByText('Preview')
    await waitFor(() => expect(screen.getAllByText(/₹/).length).toBeGreaterThan(0))
    fireEvent.click(screen.getAllByText('Create Bill').slice(-1)[0])
    await waitFor(async () => expect(await db.bills.count()).toBe(1))
    expect((await db.bills.toArray())[0].totalPaise).toBe(Math.round(1750 * 60 / 1000 * 100))

    // payment
    go('#/payments')
    fireEvent.change(await screen.findByLabelText('Customer'), { target: { value: cid } })
    type(screen.getByLabelText('Amount'), '50')
    fireEvent.click(screen.getByText('Save payment'))
    await waitFor(async () => expect(await db.payments.count()).toBe(1))
  }, 30000)

  it('lets you add another milk type for a customer on the Daily Entry screen', async () => {
    go('#/entry')
    await screen.findByText('Add customer')
    await screen.findByText('Rahul Sharma')
    expect(document.querySelector('.main .back')).toBeNull() // no redundant back button on main screens
    fireEvent.click(screen.getByLabelText('More actions for Rahul Sharma'))
    // the person has no phone number, so Call is switched off
    expect((screen.getByRole('menuitem', { name: /Call/ }) as HTMLButtonElement).disabled).toBe(true)
    fireEvent.click(screen.getByRole('menuitem', { name: /Add other milk/ }))
    const pick = await screen.findByLabelText('Choose product to add')
    const buffalo = (await db.products.where('name').equals('Buffalo Milk').first())!.id
    fireEvent.change(pick, { target: { value: String(buffalo) } })
    await screen.findByText('Buffalo Milk')
    fireEvent.click(screen.getByLabelText(/Delivered Buffalo Milk for Rahul Sharma/))
    fireEvent.click(await screen.findByText('Save all'))
    await waitFor(async () => expect(await db.entries.count()).toBe(2))
    expect((await db.entries.filter(e => e.productId === buffalo).toArray())[0].regularMl).toBe(1000)
  }, 30000)

  it('customer groups: create, assign, filter, delete (customer stays)', async () => {
    const id = (await db.customers.toArray())[0].id!
    go('#/customers')
    fireEvent.click(await screen.findByRole('button', { name: /Groups/ }))
    type(await screen.findByLabelText('New group name'), 'Morning Route')
    fireEvent.click(screen.getByRole('button', { name: /Add$/ }))
    await waitFor(async () => expect(await db.groups.count()).toBe(1))
    const gid = (await db.groups.toArray())[0].id!
    go(`#/customers/${id}`)
    fireEvent.change(await screen.findByLabelText('Group'), { target: { value: String(gid) } })
    await waitFor(async () => expect((await db.customers.get(id))!.groupId).toBe(gid))
    go('#/customers')
    fireEvent.click(await screen.findByText(/Morning Route \(1\)/))
    await screen.findByText('Rahul Sharma')
    fireEvent.click(screen.getByText(/No group \(0\)/))
    await screen.findByText('No customers found')
    // delete the group: the customer and its records stay
    fireEvent.click(screen.getByRole('button', { name: /Groups/ }))
    fireEvent.click(await screen.findByLabelText('Delete group Morning Route'))
    fireEvent.click(await screen.findByRole('button', { name: 'Delete group' }))
    await waitFor(async () => expect(await db.groups.count()).toBe(0))
    expect((await db.customers.get(id))!.groupId ?? null).toBeNull()
    expect(await db.entries.count()).toBe(2)
  }, 30000)

  it('Daily Entry: Today button, remembers a date you picked, handles dates with no entries', async () => {
    const yesterday = addDays(todayISO(), -1)
    go('#/entry')
    await screen.findByText('Rahul Sharma')
    const today = screen.getByLabelText('Go to today') as HTMLButtonElement
    expect(today.disabled).toBe(true) // already on today
    fireEvent.change(screen.getByLabelText('Date'), { target: { value: yesterday } })
    await waitFor(() => expect((screen.getByLabelText('Go to today') as HTMLButtonElement).disabled).toBe(false))
    expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe(yesterday)
    // leaving and coming back must NOT force today
    go('#/dashboard'); await screen.findByText('Recent activity')
    go('#/entry'); await screen.findByLabelText('Date')
    expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe(yesterday)
    // a day with no entries shows the customer as not saved yet (no crash)
    expect(screen.queryByText('Saved')).toBeNull()
    fireEvent.click(screen.getByLabelText('Go to today'))
    await waitFor(() => expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe(todayISO()))
    await screen.findAllByText('Saved')
    // month/year change
    fireEvent.change(screen.getByLabelText('Date'), { target: { value: '2025-12-31' } })
    await waitFor(() => expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe('2025-12-31'))
    fireEvent.click(screen.getByLabelText('Go to today'))
    await waitFor(() => expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe(todayISO()))
  }, 30000)

  it('pull-to-refresh: one refresh per pull, ignores pulls inside inputs, shows an indicator', async () => {
    go('#/dashboard'); await screen.findByText('Recent activity')
    const count = vi.spyOn(db.customers, 'count')
    const touch = (type: string, y: number, target: EventTarget = window) => { const ev: any = new Event(type, { bubbles: true, cancelable: true }); ev.touches = type === 'touchend' ? [] : [{ clientX: 50, clientY: y }]; target.dispatchEvent(ev) }
    // pulling inside a text box does nothing
    const box = document.createElement('input'); document.body.appendChild(box)
    touch('touchstart', 100, box); touch('touchmove', 300, box); touch('touchend', 300, box)
    expect(count).not.toHaveBeenCalled()
    box.remove()
    // a real pull from the top
    touch('touchstart', 100); touch('touchmove', 140); touch('touchmove', 300)
    await screen.findByRole('status', { name: /release to refresh|refreshing/i })
    touch('touchend', 300)
    await waitFor(() => expect(count).toHaveBeenCalledTimes(1))
    // a second pull straight away is ignored
    touch('touchstart', 100); touch('touchmove', 300); touch('touchend', 300)
    await new Promise(r => setTimeout(r, 100))
    expect(count).toHaveBeenCalledTimes(1)
    await screen.findByText('Recent activity') // screen came back after refresh
    // a short pull does not refresh
    await new Promise(r => setTimeout(r, 700))
    touch('touchstart', 100); touch('touchmove', 130); touch('touchend', 130)
    await new Promise(r => setTimeout(r, 50))
    expect(count).toHaveBeenCalledTimes(1)
    count.mockRestore()
  }, 30000)

  it('Reports: the PDF button makes a real PDF file (not CSV)', async () => {
    const made: Blob[] = []
    ;(URL as any).createObjectURL = (b: Blob) => { made.push(b); return 'blob:test' }
    ;(URL as any).revokeObjectURL = () => {}
    const click = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {})
    go('#/reports')
    fireEvent.click(await screen.findByText('Monthly'))
    fireEvent.click(await screen.findByRole('button', { name: /Download PDF report/ }))
    await waitFor(() => expect(made.length).toBe(1), { timeout: 15000 })
    expect(made[0].type).toBe('application/pdf')
    const buf = await new Promise<ArrayBuffer>(res => { const r = new FileReader(); r.onload = () => res(r.result as ArrayBuffer); r.readAsArrayBuffer(made[0]) })
    const head = new TextDecoder().decode(new Uint8Array(buf).slice(0, 5))
    expect(head).toBe('%PDF-')
    expect(screen.queryByText(/CSV/i)).toBeNull()
    click.mockRestore()
  }, 30000)

  it('renders every screen without crashing', async () => {
    const routes: [string, RegExp][] = [
      ['#/dashboard', /Recent activity/], ['#/customers', /Customers/], ['#/entry', /Daily Entry/], ['#/billing', /Billing/], ['#/payments', /Payment history/],
      ['#/messages', /Messages/], ['#/reports', /Reports/], ['#/products', /Product Rates/], ['#/settings', /Backup and restore/], ['#/more', /More/]
    ]
    for (const [h, re] of routes) { go(h); await screen.findAllByText(re) }
    const id = (await db.customers.toArray())[0].id
    for (const h of [`#/customers/${id}`, `#/customers/${id}/edit`, `#/customers/new`, `#/billing/view/1`]) { go(h); await waitFor(() => expect(document.querySelector('.main')!.textContent!.length).toBeGreaterThan(20)) }
    go(`#/customers/${id}`)
    await screen.findByText('Rahul Sharma')
    for (const tab of ['Bills', 'Payments', 'Rates', 'Message', 'Deliveries']) fireEvent.click(within(document.querySelector('.seg') as HTMLElement).getByText(tab))
    go('#/messages'); fireEvent.click(await screen.findByText('Templates')); await screen.findByText('Payment reminder')
    go('#/reports'); fireEvent.click(await screen.findByText('Monthly')); fireEvent.click(within(document.querySelector('.seg') as HTMLElement).getByText('Customers')); await screen.findAllByText(/Reports/)
    cleanup()
  }, 30000)
})
