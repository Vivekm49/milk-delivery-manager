// @vitest-environment jsdom
import 'fake-indexeddb/auto'
import { describe, it, expect, beforeAll, vi } from 'vitest'
import { render, screen, fireEvent, waitFor, within, cleanup } from '@testing-library/react'
import { db } from './lib/db'
import { eraseAll } from './lib/backup'
import { createCustomer } from './lib/customers'
import { todayISO, addDays } from './lib/dates'
import App from './App'

beforeAll(() => {
  window.matchMedia = window.matchMedia || ((q: string) => ({ matches: false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}, onchange: null, dispatchEvent: () => false }) as any)
  Element.prototype.scrollIntoView = () => {}
})

const type = (el: HTMLElement, v: string) => fireEvent.change(el, { target: { value: v } })
const go = (h: string) => { location.hash = h; window.dispatchEvent(new HashChangeEvent('hashchange')) }
const rahul = async () => (await db.customers.filter(c => c.name === 'Rahul Sharma').first())!.id!

describe('app smoke test (jsdom, real Dexie)', () => {
  it('first-run setup, then Daily Entry, Bill and Payment work together', async () => {
    await eraseAll()
    render(<App />)
    await screen.findByText('Welcome')
    type(screen.getByLabelText('Business name'), 'Lucky Dairy')
    fireEvent.click(screen.getByText('Continue'))
    type(await screen.findByLabelText(/Rate per/), '60')
    fireEvent.click(screen.getByText('Continue'))
    type(await screen.findByLabelText('Name'), 'Rahul Sharma')
    type(screen.getByLabelText('Area'), 'North')
    fireEvent.click(screen.getByText('Save customer and start')) // no phone number typed: it is optional
    await screen.findByText("Today's milk")
    expect((await db.customers.toArray())[0].mobile).toBe('')
    expect(document.querySelector('.hdr h1')!.textContent).toBe('Lucky Dairy') // shop name in the top bar
    expect(document.querySelectorAll('.bottom a').length).toBe(6)
    expect([...document.querySelectorAll('.bottom a')].map(a => a.textContent)).toEqual(['Home', 'Customers', 'Entry', 'Monthly', 'Bill', 'More'])

    // Daily Entry: old-style card, extra milk, no phone => Call is off, Save per card
    go('#/entry')
    await screen.findByText('Rahul Sharma')
    expect(document.querySelector('.main .back')).toBeNull()
    fireEvent.click(screen.getByRole('button', { name: 'Extra milk for Rahul Sharma' }))
    fireEvent.click(await screen.findByLabelText('Increase extra for Rahul Sharma'))
    fireEvent.click(screen.getByLabelText('More actions for Rahul Sharma'))
    expect((screen.getByRole('menuitem', { name: /Call/ }) as HTMLButtonElement).disabled).toBe(true)
    fireEvent.click(screen.getByLabelText('More actions for Rahul Sharma')) // close
    fireEvent.click(screen.getByLabelText('Save Rahul Sharma'))
    await waitFor(async () => expect(await db.entries.count()).toBe(1))
    const e = (await db.entries.toArray())[0]
    expect(e.regularMl).toBe(1000); expect(e.extraMl).toBe(250); expect(e.status).toBe('delivered')
    await screen.findByText('Done')

    // Home reflects it
    go('#/dashboard')
    await screen.findByText('1 of 1')

    // Bill tab: the live month bill, WhatsApp off without a phone number
    go('#/billing')
    fireEvent.click(await screen.findByRole('button', { name: /Rahul Sharma, .*Show bill/ }))
    await screen.findByText('Total amount')
    expect((screen.getByRole('button', { name: /No phone number/ }) as HTMLButtonElement).disabled).toBe(true)
    // formal bill
    const id = await rahul()
    go(`#/billing/new/${id}`)
    await screen.findByText('Preview')
    await waitFor(() => expect(screen.getAllByText(/₹/).length).toBeGreaterThan(0))
    fireEvent.click(screen.getAllByText('Create Bill').slice(-1)[0])
    await waitFor(async () => expect(await db.bills.count()).toBe(1))
    expect((await db.bills.toArray())[0].totalPaise).toBe(Math.round(1250 * 60 / 1000 * 100))

    // Payment lowers Payment Pending
    go('#/payments')
    fireEvent.change(await screen.findByLabelText('Customer'), { target: { value: String(id) } })
    type(screen.getByLabelText('Amount'), '50')
    fireEvent.click(screen.getByText('Save payment'))
    await waitFor(async () => expect(await db.payments.count()).toBe(1))
  }, 40000)

  it('Daily Entry: add another milk type, mark Absent, and Absent shows in Monthly, Home and the calendar', async () => {
    const sid = await createCustomer({ name: 'Suresh Patel', mobile: '9876543210', whatsapp: '', address: '', area: 'Mill Road', productId: (await db.products.where('name').equals('Cow Milk').first())!.id!, dailyMl: 1500, startDate: '2026-01-01', prefTime: 'Morning', notes: '', openingPaise: 0 })
    go('#/entry')
    await screen.findByText('Suresh Patel')
    // another milk for Rahul
    fireEvent.click(screen.getByLabelText('More actions for Rahul Sharma'))
    fireEvent.click(screen.getByRole('menuitem', { name: /Add other milk/ }))
    const buffalo = (await db.products.where('name').equals('Buffalo Milk').first())!.id
    fireEvent.change(await screen.findByLabelText('Choose product to add'), { target: { value: String(buffalo) } })
    await screen.findByText('Buffalo Milk')
    fireEvent.click(screen.getByLabelText('Save Rahul Sharma'))
    await waitFor(async () => expect((await db.entries.filter(e => e.productId === buffalo).toArray()).length).toBe(1))
    // Suresh is Absent
    fireEvent.click(screen.getByLabelText('Mark Suresh Patel absent'))
    await screen.findByText(/unsaved/)
    fireEvent.click(await screen.findByText('Save all'))
    await waitFor(async () => expect((await db.entries.where('customerId').equals(sid).toArray())[0]?.status).toBe('skipped'))
    // a quantity of 0 never means Absent: nothing else was saved for Suresh
    expect(await db.entries.where('customerId').equals(sid).count()).toBe(1)
    go('#/monthly')
    fireEvent.click(await screen.findByRole('button', { name: /Suresh Patel, .*Show month details/ }))
    await screen.findByText('Absent 1 days')
    const day = String(Number(todayISO().slice(8)))
    expect(screen.getByLabelText(`${day}: absent`)).toBeTruthy()
    go('#/dashboard')
    const tile = (await screen.findByText('Absent today')).parentElement!
    expect(tile.textContent).toContain('1')
    go('#/pending')
    await screen.findByText('Total Payment Pending')
    // Rahul has no phone number: the reminder is off
    const rahulCard = (await screen.findByText('Rahul Sharma')).closest('.mcard') as HTMLElement
    expect((within(rahulCard).getByRole('button', { name: /Send reminder/ }) as HTMLButtonElement).disabled).toBe(true)
  }, 40000)

  it('top bar: month selector and search work from every tab', async () => {
    go('#/monthly')
    await screen.findByText('Total Quantity')
    const label = document.querySelector('.monthpill b')!.textContent
    fireEvent.click(screen.getByLabelText('Previous month'))
    await waitFor(() => expect(document.querySelector('.monthpill b')!.textContent).not.toBe(label))
    expect((screen.getByLabelText('Next month') as HTMLButtonElement).disabled).toBe(false)
    fireEvent.click(screen.getByLabelText('Next month'))
    go('#/customers')
    await screen.findByText('Rahul Sharma')
    type(screen.getByLabelText('Search customers'), 'suresh')
    await screen.findByText('Suresh Patel')
    await waitFor(() => expect(screen.queryByText('Rahul Sharma')).toBeNull())
    fireEvent.click(screen.getByLabelText('Clear search'))
    await screen.findByText('Rahul Sharma')
  }, 30000)

  it('customers can be put in a delivery order', async () => {
    go('#/customers')
    fireEvent.click(await screen.findByRole('button', { name: /Reorder/ }))
    fireEvent.click(await screen.findByLabelText('Move Suresh Patel up'))
    await waitFor(async () => { const all = await db.customers.toArray(); expect(all.find(c => c.name === 'Suresh Patel')!.sortOrder).toBe(0) })
    fireEvent.click(screen.getByRole('button', { name: /Done/ }))
    go('#/entry'); await screen.findByLabelText('Date')
    const names = [...document.querySelectorAll('.ec-n b')].map(n => n.textContent)
    expect(names.indexOf('Suresh Patel')).toBeLessThan(names.indexOf('Rahul Sharma')) // Daily Entry follows the order
  }, 30000)

  it('customer groups: create, assign, filter, delete (customer stays)', async () => {
    const id = await rahul()
    const entriesBefore = await db.entries.count()
    go('#/customers')
    fireEvent.click(await screen.findByRole('button', { name: /Groups/ }))
    type(await screen.findByLabelText('New group name'), 'Morning Route')
    fireEvent.click(screen.getByRole('button', { name: /Add$/ }))
    await waitFor(async () => expect(await db.groups.count()).toBe(1))
    const gid = (await db.groups.toArray())[0].id!
    go(`#/customers/${id}`)
    fireEvent.change(await screen.findByLabelText('Group'), { target: { value: String(gid) } })
    await waitFor(async () => expect((await db.customers.get(id))!.groupId).toBe(gid))
    go('#/customers')
    fireEvent.click(await screen.findByText(/Morning Route \(1\)/))
    await screen.findByText('Rahul Sharma')
    expect(screen.queryByText('Suresh Patel')).toBeNull()
    fireEvent.click(screen.getByText(/No group \(1\)/))
    await screen.findByText('Suresh Patel')
    fireEvent.click(screen.getByRole('button', { name: /Groups/ }))
    fireEvent.click(await screen.findByLabelText('Delete group Morning Route'))
    fireEvent.click(await screen.findByRole('button', { name: 'Delete group' }))
    await waitFor(async () => expect(await db.groups.count()).toBe(0))
    expect((await db.customers.get(id))!.groupId ?? null).toBeNull()
    expect(await db.entries.count()).toBe(entriesBefore)
  }, 30000)

  it('Daily Entry: Today button, remembers a picked date, handles empty days and month/year changes', async () => {
    const yesterday = addDays(todayISO(), -1)
    go('#/entry')
    await screen.findByText('Rahul Sharma')
    expect((screen.getByLabelText('Go to today') as HTMLButtonElement).disabled).toBe(true)
    fireEvent.change(screen.getByLabelText('Date'), { target: { value: yesterday } })
    await waitFor(() => expect((screen.getByLabelText('Go to today') as HTMLButtonElement).disabled).toBe(false))
    go('#/dashboard'); await screen.findByText("Today's milk")
    go('#/entry'); await screen.findByLabelText('Date')
    expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe(yesterday) // not forced back to today
    fireEvent.click(screen.getByLabelText('Go to today'))
    await waitFor(() => expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe(todayISO()))
    await screen.findAllByText('Done')
    fireEvent.change(screen.getByLabelText('Date'), { target: { value: '2025-12-31' } })
    await waitFor(() => expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe('2025-12-31'))
    fireEvent.click(screen.getByLabelText('Go to today'))
    await waitFor(() => expect((screen.getByLabelText('Date') as HTMLInputElement).value).toBe(todayISO()))
  }, 30000)

  it('Messages: milk-type tags are in the editor and insert where the cursor is', async () => {
    go('#/messages')
    fireEvent.click(await screen.findByText('Templates'))
    fireEvent.click(await screen.findByText('New template'))
    await screen.findByText('Milk details (all milk types)', { exact: false })
    type(screen.getByLabelText('Name'), 'Milk list')
    const box = screen.getByLabelText('Message') as HTMLTextAreaElement
    type(box, 'Hello {Customer Name}, details:')
    box.setSelectionRange(box.value.length, box.value.length)
    fireEvent.click(screen.getByRole('button', { name: '{Milk Details}' }))
    await waitFor(() => expect(box.value).toContain('{Milk Details}'))
    fireEvent.click(screen.getByRole('button', { name: 'Curd' })) // pick a milk type
    fireEvent.click(await screen.findByRole('button', { name: '{Curd Quantity}' }))
    await waitFor(() => expect(box.value).toContain('{Curd Quantity}'))
    // preview fills real data
    await waitFor(() => expect(document.querySelector('.preview')!.textContent).toMatch(/Hello (Rahul Sharma|Suresh Patel), details:/))
    expect(document.querySelector('.preview')!.textContent).not.toMatch(/\{/)
    // a typo is warned about
    type(box, box.value + ' {Curd Qty}')
    await screen.findByText(/not recognised/)
    fireEvent.click(screen.getByText('Cancel'))
  }, 30000)

  it('pull-to-refresh: one refresh per pull, ignores pulls inside inputs, shows an indicator', async () => {
    go('#/dashboard'); await screen.findByText("Today's milk")
    const count = vi.spyOn(db.customers, 'count')
    const touch = (t: string, y: number, target: EventTarget = window) => { const ev: any = new Event(t, { bubbles: true, cancelable: true }); ev.touches = t === 'touchend' ? [] : [{ clientX: 50, clientY: y }]; target.dispatchEvent(ev) }
    const box = document.createElement('input'); document.body.appendChild(box)
    touch('touchstart', 100, box); touch('touchmove', 300, box); touch('touchend', 300, box)
    expect(count).not.toHaveBeenCalled(); box.remove()
    touch('touchstart', 100); touch('touchmove', 140); touch('touchmove', 300)
    await screen.findByRole('status', { name: /release to refresh|refreshing/i })
    touch('touchend', 300)
    await waitFor(() => expect(count).toHaveBeenCalledTimes(1))
    touch('touchstart', 100); touch('touchmove', 300); touch('touchend', 300)
    await new Promise(r => setTimeout(r, 100))
    expect(count).toHaveBeenCalledTimes(1)
    await screen.findByText("Today's milk")
    await new Promise(r => setTimeout(r, 700))
    touch('touchstart', 100); touch('touchmove', 130); touch('touchend', 130)
    await new Promise(r => setTimeout(r, 50))
    expect(count).toHaveBeenCalledTimes(1)
    count.mockRestore()
  }, 30000)

  it('Reports: Profit and loss needs a buy rate, and the PDF button makes a real PDF', async () => {
    const made: Blob[] = []
    ;(URL as any).createObjectURL = (b: Blob) => { made.push(b); return 'blob:test' }
    ;(URL as any).revokeObjectURL = () => {}
    const click = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {})
    go('#/reports')
    fireEvent.click(within(await screen.findByRole('tablist')).getByText('Monthly'))
    await screen.findByText(/Profit not known yet/) // no buy rate set yet
    fireEvent.click(await screen.findByRole('button', { name: /Download PDF report/ }))
    await waitFor(() => expect(made.length).toBe(1), { timeout: 15000 })
    expect(made[0].type).toBe('application/pdf')
    const buf = await new Promise<ArrayBuffer>(res => { const r = new FileReader(); r.onload = () => res(r.result as ArrayBuffer); r.readAsArrayBuffer(made[0]) })
    expect(new TextDecoder().decode(new Uint8Array(buf).slice(0, 5))).toBe('%PDF-')
    expect(screen.queryByText(/CSV/i)).toBeNull()
    click.mockRestore()
  }, 30000)

  it('renders every screen without crashing', async () => {
    const id = await rahul()
    const routes: [string, RegExp][] = [
      ['#/dashboard', /Today's milk/], ['#/customers', /customers/], ['#/entry', /Mark all done/], ['#/monthly', /Total Quantity/], ['#/billing', /Monthly Amount/], ['#/more', /Settings & Backup/],
      ['#/payments', /Payment history/], ['#/pending', /Total Payment Pending/], ['#/messages', /Send messages/], ['#/reports', /Daily/], ['#/calendar', /Customer calendar/],
      ['#/products', /Product Rates|Cow Milk/], ['#/settings', /Backup and restore/], ['#/billing/history', /Bill history/]
    ]
    for (const [h, re] of routes) { go(h); await screen.findAllByText(re) }
    for (const h of [`#/customers/${id}`, `#/customers/${id}/edit`, '#/customers/new', '#/billing/view/1', '#/billing/new']) { go(h); await waitFor(() => expect(document.querySelector('.main')!.textContent!.length).toBeGreaterThan(20)) }
    go(`#/customers/${id}`)
    await screen.findByText('Rahul Sharma')
    for (const tab of ['Bills', 'Payments', 'Rates', 'Message', 'Deliveries']) fireEvent.click(within(document.querySelector('.seg') as HTMLElement).getByText(tab))
    go('#/calendar'); await screen.findByLabelText('Delivery calendar')
    cleanup()
  }, 40000)
})
