import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Users, UserX, Check, ChevronDown, ChevronUp, Receipt, Eye } from 'lucide-react'
import { loadMonthly } from '../lib/monthly'
import { useApp } from '../lib/appctx'
import { dateLabel, monthLabel } from '../lib/dates'
import { fmt, Loading, Empty } from '../lib/ui'
import { Avatar, PayTag } from '../components/Tags'
import MonthCalendar from '../components/MonthCalendar'
import type { PayStatus } from '../lib/owed'

export default function Monthly() {
  const { month, search } = useApp()
  const data = useLiveQuery(() => loadMonthly(month), [month], undefined)
  const [filter, setFilter] = useState<'All' | PayStatus>('All')
  const [open, setOpen] = useState<number | null>(null)
  if (!data) return <Loading />
  const q = search.trim().toLowerCase()
  const rows = data.rows.filter(r => (filter === 'All' || r.status === filter) && (!q || r.customer.name.toLowerCase().includes(q) || r.customer.area.toLowerCase().includes(q) || r.customer.code.toLowerCase().includes(q)))
  const t = data.totals
  return (
    <div>
      <div className="strip" aria-label={`Summary for ${monthLabel(month)}`}>
        <div><b>{t.customers}</b><small>Customers</small></div>
        <div><b>{t.quantity}</b><small>Total Quantity</small></div>
        <div><b>{fmt(t.amountPaise)}</b><small>Monthly Amount</small></div>
        <div><b>{fmt(t.pendingPaise)}</b><small>Payment Pending</small></div>
      </div>
      {t.absentDays > 0 && <div className="abnote" style={{ marginTop: 10 }}><UserX size={18} />Absent days in {monthLabel(month)}: {t.absentDays} ({t.absentCustomers} customer{t.absentCustomers === 1 ? '' : 's'}). Not charged.</div>}
      <div className="chips" style={{ marginTop: 10 }}>
        {(['All', 'Paid', 'Part paid', 'Unpaid'] as const).map(k => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{k}</button>)}
      </div>
      {data.rows.length === 0
        ? <div className="card" style={{ marginTop: 10 }}><Empty icon={<Users />} title="No customers yet" text="Add customers and record deliveries to see the month here." action={<a className="btn primary" href="#/customers/new">Add Customer</a>} /></div>
        : rows.length === 0 ? <div className="card" style={{ marginTop: 10 }}><Empty icon={<Users />} title="No customer found" text="Try a different search or filter." /></div>
        : rows.map(r => {
          const c = r.customer; const isOpen = open === c.id
          return (
            <div className="mcard" key={c.id}>
              <button className="mh" aria-expanded={isOpen} aria-label={`${c.name}, ${r.status}. Show month details`} onClick={() => setOpen(isOpen ? null : c.id!)}>
                <Avatar name={c.name} />
                <div className="grow"><div className="nm">{c.name}</div><div className={`sb ${r.absent > 0 ? 'red' : ''}`}>Total Quantity {r.qtyText} · Absent {r.absent}</div></div>
                <div className="rt"><PayTag status={r.status} /><b style={{ fontSize: 13.5 }}>{fmt(r.amountPaise)}</b></div>
                {isOpen ? <ChevronUp size={18} color="var(--muted)" /> : <ChevronDown size={18} color="var(--muted)" />}
              </button>
              {isOpen && (
                <div className="mbody">
                  <div className="statline">
                    <span className="badge green"><Check size={13} />Delivered {r.delivered} days</span>
                    <span className="badge red"><UserX size={13} />Absent {r.absent} days</span>
                    {r.paused > 0 && <span className="badge amber">Paused {r.paused} days</span>}
                  </div>
                  <MonthCalendar month={month} days={r.days} />
                  {r.absentDates.length > 0 && <div className="abnote"><UserX size={16} style={{ flexShrink: 0 }} />Absent: {r.absentDates.map(d => dateLabel(d).slice(0, -5)).join(', ')} (not charged)</div>}
                  <div className="statrow">
                    <div className="stat"><div className="k">Monthly Amount</div><div className="v num" style={{ fontSize: 16 }}>{fmt(r.amountPaise)}</div></div>
                    <div className="stat good"><div className="k">Paid this month</div><div className="v num" style={{ fontSize: 16 }}>{fmt(r.paidThisMonth)}</div></div>
                    <div className={`stat ${r.owed > 0 ? 'bad' : 'good'}`}><div className="k">Payment Pending</div><div className="v num" style={{ fontSize: 16 }}>{fmt(Math.max(0, r.owed))}</div></div>
                  </div>
                  <div className="actrow">
                    <a className="btn" href={`#/customers/${c.id}`}><Eye size={18} />Customer</a>
                    <a className="btn primary" href="#/billing"><Receipt size={18} />Bill</a>
                  </div>
                </div>
              )}
            </div>
          )
        })}
    </div>
  )
}
