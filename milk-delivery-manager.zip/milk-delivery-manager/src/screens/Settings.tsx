import { useEffect, useRef, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Download, Upload, Trash2, Save, Package, MessageSquare } from 'lucide-react'
import { db, getSettings, saveSettings, addRate, resolveRate, ensureSeed, TABLES } from '../lib/db'
import { exportAll, validateBackup, restoreAll, eraseAll } from '../lib/backup'
import { saveTextFile } from '../lib/files'
import { isValidPhone, parseMoney, moneyInput, UNITS } from '../lib/money'
import { todayISO } from '../lib/dates'
import { Field, PageHead, Loading, toast, errMsg, confirmDialog, setCurrency } from '../lib/ui'

export default function Settings() {
  const s = useLiveQuery(() => getSettings(), [], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const rates = useLiveQuery(() => db.rates.toArray(), [], [])
  const last = useLiveQuery(async () => (await db.settings.get('lastBackup'))?.value as string | undefined, [], undefined)
  const counts = useLiveQuery(async () => ({ customers: await db.customers.count(), entries: await db.entries.count(), bills: await db.bills.count(), payments: await db.payments.count() }), [], undefined)
  const [f, setF] = useState<null | { business: string; owner: string; mobile: string; address: string; currency: string; productId: number; rate: string }>(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const file = useRef<HTMLInputElement>(null)
  useEffect(() => {
    if (!s || f || !products.length) return
    const pid = s.defaultProductId ?? products[0]?.id ?? 0
    const r = resolveRate(rates, 0, pid, todayISO())
    setF({ business: s.businessName, owner: s.ownerName, mobile: s.mobile, address: s.address, currency: s.currency, productId: pid, rate: r ? moneyInput(r.ratePaise) : '' })
  }, [s, f, products, rates])
  if (!s || !counts || !f) return <Loading />
  const set = (k: string, v: string | number) => setF({ ...f, [k]: v })

  const saveBusiness = async () => {
    setErr('')
    if (f.business.trim().length < 2) return setErr('Enter your business name.')
    if (f.mobile && !isValidPhone(f.mobile)) return setErr('Enter a valid 10-digit mobile number or leave it empty.')
    if (!f.currency.trim() || f.currency.length > 4) return setErr('Enter a currency symbol such as ₹.')
    const rate = f.rate.trim() ? parseMoney(f.rate) : null
    if (f.rate.trim() && !rate) return setErr('Default rate is not a valid amount.')
    try {
      await saveSettings({ businessName: f.business.trim(), ownerName: f.owner.trim(), mobile: f.mobile.trim(), address: f.address.trim(), currency: f.currency.trim(), defaultProductId: f.productId })
      setCurrency(f.currency.trim())
      const cur = resolveRate(rates, 0, f.productId, todayISO())
      if (rate && cur?.ratePaise !== rate) await addRate(f.productId, 0, rate, cur && cur.extraRatePaise !== cur.ratePaise ? cur.extraRatePaise : null, todayISO())
      toast('Settings saved', 'ok')
    } catch (e) { setErr(errMsg(e)) }
  }

  const backup = async () => {
    setBusy(true)
    try {
      const data = await exportAll()
      await saveTextFile(`milk-delivery-backup-${todayISO()}.json`, JSON.stringify(data), 'application/json')
      await db.settings.put({ key: 'lastBackup', value: new Date().toISOString() })
      toast('Backup created. Keep the file somewhere safe (Drive, WhatsApp to yourself).', 'ok')
    } catch (e) { toast(errMsg(e, 'Backup failed. Please try again.'), 'err') } finally { setBusy(false) }
  }
  const pick = async (ev: React.ChangeEvent<HTMLInputElement>) => {
    const fl = ev.target.files?.[0]; ev.target.value = ''
    if (!fl) return
    try {
      if (fl.size > 50 * 1024 * 1024) throw new Error('too big')
      let obj: unknown
      try { obj = JSON.parse(await fl.text()) } catch { toast('This file is not a readable backup.', 'err'); return }
      const sum = validateBackup(obj)
      const ok = await confirmDialog({
        title: 'Replace all data with this backup?',
        body: <>This backup has {sum.counts.customers} customers, {sum.counts.entries} delivery records, {sum.counts.bills} bills and {sum.counts.payments} payments{sum.exportedAt ? ` (saved ${new Date(sum.exportedAt).toLocaleDateString('en-IN')})` : ''}.<br /><br />Everything currently on this phone will be <b>replaced</b>. Create a backup first if you are not sure.</>,
        confirmLabel: 'Replace data', danger: true, typeToConfirm: 'RESTORE'
      })
      if (!ok) return
      setBusy(true)
      await restoreAll(obj)
      await ensureSeed()
      toast('Backup restored', 'ok'); setF(null)
    } catch (e) { toast(errMsg(e, 'Restore failed. Your existing data was not changed.'), 'err') } finally { setBusy(false) }
  }
  const erase = async () => {
    if (!(await confirmDialog({ title: 'Erase ALL data?', body: 'All customers, deliveries, bills and payments on this phone will be permanently deleted. Make a backup first.', confirmLabel: 'Erase everything', danger: true, typeToConfirm: 'DELETE' }))) return
    try { await eraseAll(); await ensureSeed(); toast('All data erased'); location.hash = '#/dashboard' } catch (e) { toast(errMsg(e), 'err') }
  }
  const unit = products.find(p => p.id === f.productId)?.unit ?? 'L'
  const age = last ? Math.floor((Date.now() - new Date(last).getTime()) / 86400000) : null

  return (
    <div className="stack">
      <PageHead title="Settings" />
      <div className="card formgrid">
        <h2 className="h2">Business</h2>
        <Field label="Business name"><input className="in" value={f.business} onChange={e => set('business', e.target.value)} maxLength={60} /></Field>
        <div className="formgrid two">
          <Field label="Owner name"><input className="in" value={f.owner} onChange={e => set('owner', e.target.value)} maxLength={60} /></Field>
          <Field label="Mobile number"><input className="in" inputMode="tel" value={f.mobile} onChange={e => set('mobile', e.target.value)} maxLength={16} /></Field>
        </div>
        <Field label="Address"><input className="in" value={f.address} onChange={e => set('address', e.target.value)} maxLength={200} /></Field>
        <div className="formgrid two">
          <Field label="Currency symbol"><input className="in" value={f.currency} onChange={e => set('currency', e.target.value)} maxLength={4} /></Field>
          <Field label="Default product"><select className="in" value={f.productId} onChange={e => { const id = Number(e.target.value); const r = resolveRate(rates, 0, id, todayISO()); setF({ ...f, productId: id, rate: r ? moneyInput(r.ratePaise) : '' }) }}>{products.filter(p => p.active).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
        </div>
        <Field label={`Default rate per ${UNITS[unit].short}`} hint="Changing it adds a new rate from today; old bills stay the same."><input className="in" inputMode="decimal" value={f.rate} onChange={e => set('rate', e.target.value)} /></Field>
        {err && <div className="notice bad" role="alert">{err}</div>}
        <button className="btn primary block" onClick={saveBusiness}><Save size={20} />Save settings</button>
      </div>

      <div className="card stack">
        <h2 className="h2">Appearance</h2>
        <div className="seg">{(['light', 'dark', 'system'] as const).map(t => <button key={t} className={s.theme === t ? 'on' : ''} onClick={() => saveSettings({ theme: t })}>{t === 'system' ? 'Auto' : t[0].toUpperCase() + t.slice(1)}</button>)}</div>
        <div className="row wrap"><a className="btn grow" href="#/products"><Package size={20} />Products & Rates</a><a className="btn grow" href="#/messages"><MessageSquare size={20} />Message templates</a></div>
      </div>

      <div className="card stack">
        <h2 className="h2">Backup and restore</h2>
        <p className="sub">Your data lives only on this phone. If the app is uninstalled or the phone is lost, a backup file is the only way to get it back.</p>
        <div className={`notice ${age === null || age > 7 ? 'warn' : ''}`}>{age === null ? 'You have not made a backup yet.' : age === 0 ? 'Last backup: today.' : `Last backup: ${age} day(s) ago.`}</div>
        <button className="btn primary block" onClick={backup} disabled={busy}><Download size={20} />Create backup</button>
        <button className="btn block" onClick={() => file.current?.click()} disabled={busy}><Upload size={20} />Restore from backup</button>
        <input ref={file} type="file" accept=".json,application/json" hidden onChange={pick} />
      </div>

      <div className="card stack">
        <h2 className="h2">Data</h2>
        <div className="kv"><span>Customers</span><span>{counts.customers}</span></div><div className="kv"><span>Delivery records</span><span>{counts.entries}</span></div><div className="kv"><span>Bills</span><span>{counts.bills}</span></div><div className="kv"><span>Payments</span><span>{counts.payments}</span></div>
        <button className="btn danger block" onClick={erase}><Trash2 size={20} />Erase all data</button>
      </div>

      <div className="card">
        <h2 className="h2">About</h2>
        <p className="sub">Milk Delivery Manager 1.0.0. Works offline. Data is stored on this device ({TABLES.length} tables). Messages open WhatsApp or SMS for you to send; the app never sends messages by itself.</p>
      </div>
    </div>
  )
}
