import { useEffect, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Receipt, Ban, MessageCircle, Wallet, FileText, Image as ImageIcon, ChevronDown, ChevronUp, UserX, History, Users } from 'lucide-react'
import { db, AppError } from '../lib/db'
import { customerOwed, type PayStatus } from '../lib/owed'
import { loadMonthly, type MonthlyRow } from '../lib/monthly'
import { buildBillModel, billText, renderBillImage } from '../lib/billImage'
import { allBillsReport, customerBillReport } from '../lib/billPdf'
import { exportReportPdf } from '../lib/pdf'
import { saveImageFile } from '../lib/files'
import { useApp } from '../lib/appctx'
import { Avatar, PayTag } from '../components/Tags'
import { generateBill, previewBill, voidBill, periodFor } from '../lib/billing'
import { formatQty, parseMoney, UNITS } from '../lib/money'
import { currentMonth, dateLabel, monthLabel, todayISO, isValidISO } from '../lib/dates'
import { messageLink, hasPhone } from '../lib/messages'
import { fmt, Field, PageHead, Empty, Loading, Seg, MonthNav, toast, errMsg, confirmDialog, go } from '../lib/ui'
import type { Bill } from '../lib/types'

export default function Billing({ route }: { route: string[] }) {
  if (route[1] === 'view' && route[2]) return <BillView id={Number(route[2])} />
  if (route[1] === 'new') return <Generate customerId={Number(route[2]) || 0} />
  if (route[1] === 'history') return <BillList />
  return <BillTab />
}

function BillList() {
  const bills = useLiveQuery(() => db.bills.toArray(), [], undefined)
  const customers = useLiveQuery(() => db.customers.toArray(), [], [])
  const [month, setMonth] = useState(currentMonth())
  const [all, setAll] = useState(false)
  if (!bills) return <Loading />
  const cname = new Map(customers.map(c => [c.id!, c.name]))
  const list = bills.filter(b => all || b.fromDate.slice(0, 7) === month || b.toDate.slice(0, 7) === month).sort((a, b) => b.createdAt - a.createdAt)
  const total = list.filter(b => b.status === 'issued').reduce((s, b) => s + b.totalPaise, 0)
  return (
    <div className="stack">
      <PageHead title="Bill history" right={<a className="btn primary" href="#/billing/new"><Receipt size={20} />Create Bill</a>} />
      <div className="row wrap"><div className="grow" style={{ minWidth: 200, opacity: all ? 0.4 : 1 }}><MonthNav month={month} onChange={m => { setMonth(m); setAll(false) }} /></div><button className={`chip ${all ? 'on' : ''}`} onClick={() => setAll(!all)}>All time</button></div>
      <div className="stat"><div className="k">Bills made in this view ({list.filter(b => b.status === 'issued').length} bills)</div><div className="v num">{fmt(total)}</div></div>
      <div className="card">
        {list.length === 0 ? <Empty icon={<Receipt />} title="No bills here" text="Create a monthly bill from the deliveries you have saved." action={<a className="btn primary" href="#/billing/new">Create Bill</a>} /> :
          <div className="list">{list.map(b => <a className="item" key={b.id} href={`#/billing/view/${b.id}`} style={{ opacity: b.status === 'void' ? 0.55 : 1 }}>
            <div className="grow"><div className="t">{cname.get(b.customerId) ?? 'Customer'} {b.status === 'void' && <span className="badge gray">Cancelled</span>}</div><div className="s">{b.number} · {b.kind === 'monthly' ? monthLabel(b.fromDate.slice(0, 7)) : b.fromDate === b.toDate ? dateLabel(b.fromDate) : `${dateLabel(b.fromDate)} to ${dateLabel(b.toDate)}`}</div></div>
            <div className="total num" style={{ fontSize: 17 }}>{fmt(b.totalPaise)}</div></a>)}</div>}
      </div>
    </div>
  )
}

function Generate({ customerId }: { customerId: number }) {
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const [kind, setKind] = useState<'monthly' | 'daily' | 'range'>('monthly')
  const [cid, setCid] = useState(customerId)
  const [month, setMonth] = useState(currentMonth())
  const [day, setDay] = useState(todayISO())
  const [from, setFrom] = useState(todayISO())
  const [to, setTo] = useState(todayISO())
  const [pid, setPid] = useState(0)
  const [dmode, setDmode] = useState<'amount' | 'percent'>('amount')
  const [dval, setDval] = useState('')
  const [prev, setPrev] = useState<Awaited<ReturnType<typeof previewBill>> | null>(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [results, setResults] = useState<string[] | null>(null)

  const range = kind === 'monthly' ? periodFor('monthly', month) : kind === 'daily' ? periodFor('daily', day) : { from, to }
  useEffect(() => {
    setPrev(null)
    if (!cid || !isValidISO(range.from) || !isValidISO(range.to) || range.from > range.to) return
    let alive = true
    previewBill({ customerId: cid, kind, from: range.from, to: range.to, productId: pid || null }).then(p => alive && setPrev(p)).catch(() => {})
    return () => { alive = false }
  }, [cid, kind, range.from, range.to, pid])
  if (!customers) return <Loading />

  const discount = (): number | null => {
    if (!dval.trim()) return 0
    const v = parseMoney(dval)
    if (v === null) return null
    if (dmode === 'amount') return v
    if (v > 10000) return null
    return Math.floor(((prev?.subtotal ?? 0) * v * 2 + 10000) / 20000)
  }
  const d = discount()
  const total = prev ? prev.subtotal - (d ?? 0) : 0

  const submit = async () => {
    setErr('')
    if (!cid) return setErr('Choose a customer, or "All customers".')
    if (d === null) return setErr('Discount is not valid.')
    setBusy(true)
    try {
      if (cid === -1) {
        if (!(await confirmDialog({ title: 'Create bills for all customers?', body: `Creates one ${kind} bill for every customer who has deliveries left to bill in this period. Customers who are already billed are skipped.`, confirmLabel: 'Generate all' }))) return
        const out: string[] = []
        let ok = 0
        for (const c of customers) {
          try { await generateBill({ customerId: c.id!, kind, from: range.from, to: range.to, productId: pid || null }); ok++ }
          catch (e) { if (e instanceof AppError && !/no deliveries left/.test(e.message)) out.push(`${c.name}: ${e.message}`) }
        }
        setResults([`${ok} bill(s) created.`, ...out]); toast(`${ok} bill(s) created`, ok ? 'ok' : 'info')
      } else {
        const id = await generateBill({ customerId: cid, kind, from: range.from, to: range.to, discountPaise: d, productId: pid || null })
        toast('Bill created', 'ok'); go(`billing/view/${id}`)
      }
    } catch (e) { setErr(errMsg(e)) } finally { setBusy(false) }
  }

  return (
    <div className="stack">
      
      <PageHead title="Create Bill" sub="Absent and paused days are never charged." />
      <div className="card formgrid">
        <Seg value={kind} onChange={setKind} options={[{ v: 'monthly', l: 'Monthly' }, { v: 'daily', l: 'Daily' }, { v: 'range', l: 'Custom range' }]} />
        <Field label="Customer"><select className="in" value={cid} onChange={e => { setCid(Number(e.target.value)); setResults(null) }}><option value={0}>Choose customer</option><option value={-1}>All customers</option>{[...customers].sort((a, b) => a.name.localeCompare(b.name)).map(c => <option key={c.id} value={c.id}>{c.name} ({c.code})</option>)}</select></Field>
        {kind === 'monthly' && <MonthNav month={month} onChange={setMonth} />}
        {kind === 'daily' && <Field label="Date"><input type="date" className="in" value={day} onChange={e => setDay(e.target.value)} /></Field>}
        {kind === 'range' && <div className="formgrid two"><Field label="From"><input type="date" className="in" value={from} onChange={e => setFrom(e.target.value)} /></Field><Field label="To"><input type="date" className="in" value={to} onChange={e => setTo(e.target.value)} /></Field></div>}
        <Field label="Product (optional)" hint="Pick one for a product-wise bill"><select className="in" value={pid} onChange={e => setPid(Number(e.target.value))}><option value={0}>All products</option>{products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
        {cid > 0 && <div className="formgrid two">
          <Field label="Discount (optional)"><input className="in" inputMode="decimal" value={dval} onChange={e => setDval(e.target.value)} placeholder="0" /></Field>
          <Field label="Discount type"><Seg value={dmode} onChange={setDmode} options={[{ v: 'amount', l: 'Amount' }, { v: 'percent', l: 'Percent' }]} /></Field>
        </div>}
      </div>

      {cid > 0 && <div className="card">
        <h2 className="h2">Preview</h2>
        {!prev ? <p className="sub">Loading...</p> : prev.deliveredDays === 0 ? <p className="sub">No deliveries left to bill in this period.</p> : <>
          <div className="table-wrap" style={{ marginTop: 8 }}><table><thead><tr><th>Item</th><th className="r">Qty</th><th className="r">Rate</th><th className="r">Amount</th></tr></thead><tbody>
            {prev.lines.map((l, i) => <tr key={i}><td>{l.productName} {l.kind === 'extra' ? '(extra)' : ''}</td><td className="r">{formatQty(l.qtyMilli, l.unit)}</td><td className="r">{fmt(l.ratePaise)}</td><td className="r">{fmt(l.amountPaise)}</td></tr>)}
          </tbody></table></div>
          <div className="kv"><span>{prev.deliveredDays} delivered days · Amount before discount</span><span className="num">{fmt(prev.subtotal)}</span></div>
          {d ? <div className="kv"><span>Discount</span><span className="num">-{fmt(d)}</span></div> : null}
          <div className="kv"><span className="total">Total</span><span className="total num">{fmt(total)}</span></div>
          {prev.missingRate.length > 0 && <div className="notice warn">Some products have no rate yet. Set it in Products & Rates.</div>}
        </>}
      </div>}

      {err && <div className="notice bad" role="alert">{err}</div>}
      {results && <div className="notice">{results.map((r, i) => <div key={i}>{r}</div>)}</div>}
      <button className="btn primary block" onClick={submit} disabled={busy}><Receipt size={20} />{busy ? 'Working...' : cid === -1 ? 'Create all bills' : 'Create Bill'}</button>
    </div>
  )
}

function BillView({ id }: { id: number }) {
  const bill = useLiveQuery(() => db.bills.get(id), [id], undefined)
  const items = useLiveQuery(() => db.billItems.where('billId').equals(id).toArray(), [id], [])
  const customers = useLiveQuery(() => db.customers.toArray(), [], [])
  const bills = useLiveQuery(() => db.bills.toArray(), [], [])
  const payments = useLiveQuery(() => db.payments.toArray(), [], [])
  const settings = useLiveQuery(() => db.settings.get('businessName'), [], undefined)
  const owedNow = useLiveQuery(async () => (bill ? customerOwed(bill.customerId) : 0), [bill?.customerId], 0)
  if (bill === undefined) return <Loading />
  if (!bill) return <><Empty icon={<Receipt />} title="Bill not found" /></>
  const c = customers.find(x => x.id === bill.customerId)
  const bal = owedNow ?? 0
  const period = bill.fromDate === bill.toDate ? dateLabel(bill.fromDate) : `${dateLabel(bill.fromDate)} to ${dateLabel(bill.toDate)}`
  const text = c ? `Hello ${c.name}, bill ${bill.number} (${period}):\n${items.map(i => `${i.productName}${i.kind === 'extra' ? ' extra' : ''} ${formatQty(i.qtyMilli, i.unit)} x ${fmt(i.ratePaise)} = ${fmt(i.amountPaise)}`).join('\n')}\n${bill.discountPaise ? `Discount: ${fmt(bill.discountPaise)}\n` : ''}Total: ${fmt(bill.totalPaise)}. Amount pending: ${fmt(bal)}.${settings?.value ? `\n${settings.value}` : ''} Thank you.` : ''
  const doVoid = async () => {
    if (await confirmDialog({ title: `Cancel bill ${bill.number}?`, body: 'The bill stays in your list as Cancelled. Its deliveries can be billed again, and they still count as Payment Pending until you do. Payments are not changed.', confirmLabel: 'Cancel bill', cancelLabel: 'No, keep it', danger: true })) {
      try { await voidBill(id); toast('Bill cancelled') } catch (e) { toast(errMsg(e), 'err') }
    }
  }
  return (
    <div className="stack">
      
      <div className="card">
        <div className="row between wrap"><div><h1 className="title" style={{ fontSize: 22 }}>{bill.number}</h1><p className="sub">{c?.name} · {period}</p></div>{bill.status === 'void' ? <span className="badge gray">Cancelled</span> : <span className="badge green">Active</span>}</div>
        <div className="table-wrap" style={{ marginTop: 12 }}><table><thead><tr><th>Item</th><th className="r">Qty</th><th className="r">Rate</th><th className="r">Amount</th></tr></thead><tbody>
          {items.map(i => <tr key={i.id}><td>{i.productName}{i.kind === 'extra' ? ' (extra)' : ''}</td><td className="r">{formatQty(i.qtyMilli, i.unit)}</td><td className="r">{fmt(i.ratePaise)}/{UNITS[i.unit].short}</td><td className="r">{fmt(i.amountPaise)}</td></tr>)}
        </tbody></table></div>
        <div className="kv"><span>Amount before discount</span><span className="num">{fmt(bill.subtotalPaise)}</span></div>
        {bill.discountPaise > 0 && <div className="kv"><span>Discount</span><span className="num">-{fmt(bill.discountPaise)}</span></div>}
        <div className="kv"><span className="total">Bill amount</span><span className="total num">{fmt(bill.totalPaise)}</span></div>
        <div className="grid3" style={{ marginTop: 8 }}>
          <div className="stat good"><div className="k">Delivered days</div><div className="v num">{bill.deliveredDays}</div></div>
          <div className="stat bad"><div className="k">Absent</div><div className="v num">{bill.skippedDays}</div></div>
          <div className="stat"><div className="k">Paused</div><div className="v num">{bill.pausedDays}</div></div>
        </div>
        <div className="kv" style={{ marginTop: 8 }}><span>Amount pending now</span><span className="num" style={{ color: bal > 0 ? 'var(--red)' : 'var(--green)' }}>{fmt(bal)}</span></div>
      </div>
      <div className="row wrap">
        {c && hasPhone(c, 'whatsapp') && <a className="btn green grow" href={messageLink('whatsapp', c, text)} target="_blank" rel="noopener noreferrer"><MessageCircle size={20} />Send on WhatsApp</a>}
        {c && <a className="btn grow" href={`#/payments/${c.id}`}><Wallet size={20} />Add payment</a>}
        {bill.status === 'issued' && <button className="btn danger" onClick={doVoid}><Ban size={20} />Cancel bill</button>}
      </div>
    </div>
  )
}
export type { Bill }

// ---------- Bill tab: every customer's month, like the old app ----------
function BillTab() {
  const { month, search } = useApp()
  const data = useLiveQuery(() => loadMonthly(month), [month], undefined)
  const payments = useLiveQuery(() => db.payments.toArray(), [], [])
  const bills = useLiveQuery(() => db.bills.toArray(), [], [])
  const shop = useLiveQuery(async () => String((await db.settings.get('businessName'))?.value ?? ''), [], '')
  const symbol = useLiveQuery(async () => String((await db.settings.get('currency'))?.value ?? '₹'), [], '₹')
  const qr = useLiveQuery(async () => ((await db.settings.get('upiQr'))?.value as string | undefined) ?? null, [], null)
  const [filter, setFilter] = useState<'All' | PayStatus>('All')
  const [open, setOpen] = useState<number | null>(null)
  const [busy, setBusy] = useState('')
  if (!data) return <Loading />
  const q = search.trim().toLowerCase()
  const rows = data.rows.filter(r => (filter === 'All' || r.status === filter) && (!q || r.customer.name.toLowerCase().includes(q) || r.customer.code.toLowerCase().includes(q)))

  const run = async (key: string, fn: () => Promise<void>) => { if (busy) return; setBusy(key); try { await fn() } catch (e) { toast(errMsg(e, 'Could not make the file. Please try again.'), 'err') } finally { setBusy('') } }
  const allPdf = () => run('all', async () => {
    const r = await exportReportPdf(allBillsReport(data, shop, symbol), data.month + '-01', `Milk_Delivery_Bills_${data.month}.pdf`)
    toast(r === 'downloaded' ? 'PDF downloaded' : 'PDF ready to open or share', 'ok')
  })
  const onePdf = (r: MonthlyRow) => run('pdf' + r.customer.id, async () => {
    const m = buildBillModel(r, month, payments, shop, symbol)
    const res = await exportReportPdf(customerBillReport(m, month), month + '-01', `Milk_Delivery_Bill_${r.customer.name.replace(/[^A-Za-z0-9]+/g, '_')}_${month}.pdf`)
    toast(res === 'downloaded' ? 'PDF downloaded' : 'PDF ready to open or share', 'ok')
  })
  const image = (r: MonthlyRow) => run('img' + r.customer.id, async () => {
    const blob = await renderBillImage(buildBillModel(r, month, payments, shop, symbol), qr)
    if (!blob) throw new Error('no image')
    const res = await saveImageFile(`Milk_Delivery_Bill_${r.customer.name.replace(/[^A-Za-z0-9]+/g, '_')}_${month}.png`, blob)
    toast(res === 'downloaded' ? 'Image downloaded' : 'Bill image ready to share', 'ok')
  })

  return (
    <div>
      <div className="card sumcard">
        <div><div className="k">Monthly Amount</div><div className="v num">{fmt(data.totals.amountPaise)}</div></div>
        <div><div className="k">Collected</div><div className="v num" style={{ color: 'var(--green)' }}>{fmt(data.totals.collectedPaise)}</div></div>
        <div><div className="k">Payment Pending</div><div className="v num" style={{ color: 'var(--red)' }}>{fmt(data.totals.pendingPaise)}</div></div>
        <div className="row wrap" style={{ width: '100%' }}>
          <button className="btn sm grow" onClick={allPdf} disabled={!!busy || data.rows.length === 0}><FileText size={18} />All PDF</button>
          <a className="btn sm grow" href="#/billing/new"><Receipt size={18} />Create Bill</a>
          <a className="btn sm grow" href="#/billing/history"><History size={18} />History</a>
        </div>
      </div>
      <div className="chips" style={{ marginTop: 10 }}>{(['All', 'Paid', 'Part paid', 'Unpaid'] as const).map(k => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{k}</button>)}</div>
      {data.rows.length === 0
        ? <div className="card" style={{ marginTop: 10 }}><Empty icon={<Users />} title="No customers yet" text="Add customers and record deliveries to see their bills." action={<a className="btn primary" href="#/customers/new">Add Customer</a>} /></div>
        : rows.length === 0 ? <div className="card" style={{ marginTop: 10 }}><Empty icon={<Receipt />} title="No bill found" text="Try a different search or filter." /></div>
        : rows.map(r => {
          const c = r.customer; const isOpen = open === c.id
          const model = buildBillModel(r, month, payments, shop, symbol)
          const made = bills.find(b => b.customerId === c.id && b.status === 'issued' && b.kind === 'monthly' && b.fromDate.slice(0, 7) === month)
          return (
            <div className="mcard" key={c.id}>
              <button className="mh" aria-expanded={isOpen} aria-label={`${c.name}, ${r.status}. Show bill`} onClick={() => setOpen(isOpen ? null : c.id!)}>
                <Avatar name={c.name} />
                <div className="grow"><div className="nm">{c.name}</div><div className="sb">{monthLabel(month)}{r.absent > 0 ? ` · Absent ${r.absent}` : ''}</div></div>
                <div className="rt"><PayTag status={r.status} /><b style={{ fontSize: 13.5 }}>{fmt(r.amountPaise)}</b></div>
                {isOpen ? <ChevronUp size={18} color="var(--muted)" /> : <ChevronDown size={18} color="var(--muted)" />}
              </button>
              {isOpen && (
                <div className="mbody">
                  {r.lines.length === 0 ? <p className="sub" style={{ margin: '10px 0' }}>No milk delivered in {monthLabel(month)}.</p> :
                    <div className="table-wrap" style={{ marginTop: 10 }}><table className="lines"><thead><tr><th>Item</th><th className="r">Qty</th><th className="r">Rate</th><th className="r">Amount</th></tr></thead><tbody>
                      {model.lines.map((l, i) => <tr key={i}><td>{l.item}</td><td className="r">{l.qty}</td><td className="r">{l.rate}</td><td className="r">{l.amount}</td></tr>)}
                    </tbody></table></div>}
                  {model.discount && <div className="kv"><span>Discount</span><span className="num">-{model.discount}</span></div>}
                  <div className="kv"><span className="total">Total amount</span><span className="total num">{model.total}</span></div>
                  {model.absentText && <div className="abnote"><UserX size={16} style={{ flexShrink: 0 }} />{model.absentText}</div>}
                  {model.payments.length > 0 && <div style={{ marginTop: 8 }}><div className="lbl">Payments</div>{model.payments.map((p, i) => <div className="kv" key={i}><span className="muted">{p.label}</span><span className="num" style={{ color: 'var(--green)' }}>{p.amount}</span></div>)}</div>}
                  <div className="kv" style={{ borderTop: '1px solid var(--line)' }}><span className="total" style={{ color: r.owed > 0 ? 'var(--red)' : 'var(--green)' }}>Payment Pending</span><span className="total num" style={{ color: r.owed > 0 ? 'var(--red)' : 'var(--green)' }}>{model.pending}</span></div>
                  <div className="actrow">
                    <a className="btn green" href={`#/payments/${c.id}`}><Wallet size={18} />Payment</a>
                    {hasPhone(c) ? <a className="btn" href={messageLink('whatsapp', c, billText(model))} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} />WhatsApp</a> : <button className="btn" disabled><MessageCircle size={18} />No phone number</button>}
                    <button className="btn" onClick={() => onePdf(r)} disabled={!!busy}><FileText size={18} />PDF</button>
                    <button className="btn" onClick={() => image(r)} disabled={!!busy}><ImageIcon size={18} />Image</button>
                    {made ? <a className="btn" href={`#/billing/view/${made.id}`}><Receipt size={18} />Bill {made.number}</a> : <a className="btn primary" href={`#/billing/new/${c.id}`}><Receipt size={18} />Create Bill</a>}
                  </div>
                </div>
              )}
            </div>
          )
        })}
    </div>
  )
}
