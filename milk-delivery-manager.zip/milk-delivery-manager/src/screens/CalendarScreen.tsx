import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { CalendarDays, UserX, Check } from 'lucide-react'
import { db } from '../lib/db'
import { sortCustomers } from '../lib/customers'
import { dayStatuses, dayCounts } from '../lib/absent'
import { dateLabel, monthEnd, monthLabel, monthStart, currentMonth } from '../lib/dates'
import { Field, Loading, Empty, MonthNav } from '../lib/ui'
import MonthCalendar from '../components/MonthCalendar'

export default function CalendarScreen() {
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const [cid, setCid] = useState(0)
  const [month, setMonth] = useState(currentMonth())
  const data = useLiveQuery(async () => {
    if (!cid) return null
    const c = await db.customers.get(cid)
    if (!c) return null
    const [entries, pauses] = await Promise.all([db.entries.where('[customerId+date]').between([cid, monthStart(month)], [cid, monthEnd(month)], true, true).toArray(), db.pauses.where('customerId').equals(cid).toArray()])
    const days = dayStatuses(entries, pauses, c, month)
    return { c, days, counts: dayCounts(days) }
  }, [cid, month], undefined)
  if (!customers) return <Loading />
  const list = sortCustomers(customers)
  const chosen = cid || (list[0]?.id ?? 0)
  if (cid === 0 && chosen) setTimeout(() => setCid(chosen), 0)
  return (
    <div className="stack">
      <div className="card formgrid">
        <h2 className="h2">Customer calendar</h2>
        <Field label="Customer"><select className="in" value={cid} onChange={e => setCid(Number(e.target.value))}>{list.map(c => <option key={c.id} value={c.id}>{c.name} ({c.code})</option>)}</select></Field>
        <MonthNav month={month} onChange={setMonth} max={currentMonth()} />
      </div>
      {customers.length === 0 ? <div className="card"><Empty icon={<CalendarDays />} title="No customers yet" text="Add a customer to see their calendar." /></div>
        : !data ? <Loading /> : (
        <div className="card">
          <div className="statline" style={{ marginTop: 0 }}>
            <span className="badge green"><Check size={13} />Delivered {data.counts.delivered} days</span>
            <span className="badge red"><UserX size={13} />Absent {data.counts.absent} days</span>
            {data.counts.paused > 0 && <span className="badge amber">Paused {data.counts.paused} days</span>}
          </div>
          <MonthCalendar month={month} days={data.days} />
          {data.counts.absentDates.length > 0 && <div className="abnote"><UserX size={16} style={{ flexShrink: 0 }} />Absent on {data.counts.absentDates.map(d => dateLabel(d).slice(0, -5)).join(', ')} {monthLabel(month).slice(-4)}. Not charged.</div>}
        </div>
      )}
    </div>
  )
}
