import { useEffect, useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Plus, Search, Phone, UserX, ChevronLeft, Pause, Play, Pencil, Trash2, Users, Wallet, Receipt } from 'lucide-react'
import { db, balanceOf, isPausedOn, resolveRate, customerBalance, AppError } from '../lib/db'
import { createCustomer, updateCustomer, setCustomerStatus, deleteCustomer, validateCustomer, type CustomerInput } from '../lib/customers'
import { formatQty, parseMoney, parseQty, moneyInput, UNITS } from '../lib/money'
import { currentMonth, dateLabel, daysBetween, monthEnd, monthStart, todayISO } from '../lib/dates'
import { fmt, Field, PageHead, Empty, Loading, Seg, MonthNav, initials, toast, errMsg, confirmDialog, go } from '../lib/ui'
import QuickMessage from '../components/QuickMessage'
import type { Customer } from '../lib/types'

export default function Customers({ route }: { route: string[] }) {
  if (route[1] === 'new') return <CustomerForm />
  if (route[1] && route[2] === 'edit') return <CustomerForm id={Number(route[1])} />
  if (route[1]) return <CustomerDetail id={Number(route[1])} />
  return <CustomerList />
}

type Filter = 'all' | 'active' | 'paused' | 'inactive' | 'pending'

function CustomerList() {
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const bills = useLiveQuery(() => db.bills.toArray(), [], [])
  const payments = useLiveQuery(() => db.payments.toArray(), [], [])
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<Filter>('all')
  const [area, setArea] = useState('')
  const [product, setProduct] = useState(0)
  const pmap = useMemo(() => new Map(products.map(p => [p.id!, p])), [products])
  const areas = useMemo(() => [...new Set((customers ?? []).map(c => c.area).filter(Boolean))].sort(), [customers])
  if (!customers) return <Loading />

  const query = q.trim().toLowerCase()
  const rows = customers.map(c => ({ c, bal: balanceOf(c, bills, payments) })).filter(({ c, bal }) => {
    if (query && !(c.name.toLowerCase().includes(query) || c.mobile.includes(query.replace(/\s/g, '')) || c.code.toLowerCase().includes(query) || c.area.toLowerCase().includes(query))) return false
    if (filter === 'pending' ? bal <= 0 : filter !== 'all' && c.status !== filter) return false
    if (area && c.area !== area) return false
    if (product && c.productId !== product) return false
    return true
  }).sort((a, b) => a.c.name.localeCompare(b.c.name))
  const chips: [Filter, string][] = [['all', 'All'], ['active', 'Active'], ['paused', 'Paused'], ['pending', 'Pending payment'], ['inactive', 'Inactive']]

  return (
    <div className="stack">
      <PageHead title="Customers" sub={`${customers.length} total`} right={<a className="btn primary" href="#/customers/new"><Plus size={20} />Add</a>} />
      <div className="search"><Search /><input className="in" type="search" placeholder="Search name, phone, ID or area" value={q} onChange={e => setQ(e.target.value)} aria-label="Search customers" /></div>
      <div className="chips" style={{ marginTop: 10 }}>{chips.map(([k, l]) => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{l}</button>)}</div>
      <div className="grid2" style={{ marginTop: 10 }}>
        <select className="in" value={area} onChange={e => setArea(e.target.value)} aria-label="Area"><option value="">All areas</option>{areas.map(a => <option key={a}>{a}</option>)}</select>
        <select className="in" value={product} onChange={e => setProduct(Number(e.target.value))} aria-label="Product"><option value={0}>All products</option>{products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
      </div>
      <div className="card" style={{ marginTop: 12 }}>
        {customers.length === 0
          ? <Empty icon={<Users />} title="No customers yet" text="Add your first customer to start daily entries." action={<a className="btn primary" href="#/customers/new"><Plus size={20} />Add customer</a>} />
          : rows.length === 0 ? <Empty icon={<Search />} title="No match" text="Try a different search or clear the filters." />
          : <div className="list">{rows.map(({ c, bal }) => (
            <a className="item" key={c.id} href={`#/customers/${c.id}`}>
              <div className="avatar">{initials(c.name)}</div>
              <div className="grow"><div className="t">{c.name} <span className="muted" style={{ fontWeight: 500 }}>{c.code}</span></div><div className="s">{[c.area, pmap.get(c.productId)?.name, formatQty(c.dailyMl, pmap.get(c.productId)?.unit)].filter(Boolean).join(' · ')}</div></div>
              <div style={{ textAlign: 'right' }}>{c.status !== 'active' && <span className={`badge ${c.status === 'paused' ? 'amber' : 'gray'}`}>{c.status === 'paused' ? 'Paused' : 'Inactive'}</span>}<div className={`num ${bal > 0 ? '' : 'muted'}`} style={{ fontWeight: 700, color: bal > 0 ? 'var(--red)' : undefined }}>{bal !== 0 ? fmt(bal) : 'Clear'}</div></div>
            </a>))}</div>}
      </div>
    </div>
  )
}

function CustomerForm({ id }: { id?: number }) {
  const products = useLiveQuery(() => db.products.filter(p => p.active).toArray(), [], undefined)
  const existing = useLiveQuery(async () => (id ? ((await db.customers.get(id)) ?? null) : null), [id], undefined)
  const rates = useLiveQuery(() => db.rates.toArray(), [], undefined)
  const [f, setF] = useState<null | Record<string, string>>(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  useEffect(() => {
    if (f || !products || !rates || existing === undefined) return
    const defaultProduct = existing?.productId ?? products[0]?.id ?? 0
    const own = existing ? rates.filter(r => r.customerId === existing.id && r.productId === existing.productId).sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom))[0] : undefined
    setF({
      name: existing?.name ?? '', mobile: existing?.mobile ?? '', whatsapp: existing?.whatsapp ?? '', address: existing?.address ?? '', area: existing?.area ?? '',
      productId: String(defaultProduct), qty: existing ? String(existing.dailyMl / 1000) : '1', rate: own ? moneyInput(own.ratePaise) : '', startDate: existing?.startDate ?? todayISO(),
      prefTime: existing?.prefTime ?? 'Morning', notes: existing?.notes ?? '', opening: existing ? moneyInput(existing.openingPaise) : ''
    })
  }, [f, products, rates, existing])
  if (id && existing === null) return <><a className="back" href="#/customers"><ChevronLeft size={20} />Customers</a><Empty icon={<UserX />} title="Customer not found" /></>
  if (!products || !f) return <Loading />
  const set = (k: string, v: string) => setF({ ...f, [k]: v })
  const pid = Number(f.productId)
  const unit = products.find(p => p.id === pid)?.unit ?? 'L'

  const save = async () => {
    setErr('')
    const qty = parseQty(f.qty)
    const opening = f.opening.trim() ? parseMoney(f.opening) : 0
    const rate = f.rate.trim() ? parseMoney(f.rate) : null
    if (!qty) return setErr('Enter a valid daily quantity, for example 1 or 1.5.')
    if (opening === null) return setErr('Opening balance is not a valid amount.')
    if (f.rate.trim() && !rate) return setErr('Customer rate is not a valid amount.')
    const input: CustomerInput = { name: f.name, mobile: f.mobile, whatsapp: f.whatsapp, address: f.address, area: f.area, productId: pid, dailyMl: qty, startDate: f.startDate, prefTime: f.prefTime, notes: f.notes, openingPaise: opening }
    const v = validateCustomer(input)
    if (v.length) return setErr(v[0])
    setBusy(true)
    try {
      if (id) { await updateCustomer(id, input, rate); toast('Customer updated', 'ok'); go(`customers/${id}`) }
      else { const nid = await createCustomer(input, rate); toast('Customer added', 'ok'); go(`customers/${nid}`) }
    } catch (e) { setErr(errMsg(e)) } finally { setBusy(false) }
  }

  return (
    <div className="stack">
      <a className="back" href={id ? `#/customers/${id}` : '#/customers'}><ChevronLeft size={20} />Back</a>
      <PageHead title={id ? 'Edit customer' : 'New customer'} />
      <div className="card formgrid">
        <div className="formgrid two">
          <Field label="Name"><input className="in" value={f.name} onChange={e => set('name', e.target.value)} maxLength={60} autoComplete="off" /></Field>
          <Field label="Mobile number"><input className="in" inputMode="tel" value={f.mobile} onChange={e => set('mobile', e.target.value)} maxLength={16} /></Field>
          <Field label="WhatsApp number" hint="Leave empty to use the mobile number"><input className="in" inputMode="tel" value={f.whatsapp} onChange={e => set('whatsapp', e.target.value)} maxLength={16} /></Field>
          <Field label="Area"><input className="in" value={f.area} onChange={e => set('area', e.target.value)} maxLength={60} /></Field>
        </div>
        <Field label="Address"><input className="in" value={f.address} onChange={e => set('address', e.target.value)} maxLength={200} /></Field>
        <div className="formgrid two">
          <Field label="Product"><select className="in" value={f.productId} onChange={e => set('productId', e.target.value)}>{products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
          <Field label={`Daily quantity (${UNITS[unit].short})`} hint="Example: 1 or 1.5 or 0.5"><input className="in" inputMode="decimal" value={f.qty} onChange={e => set('qty', e.target.value)} /></Field>
          <Field label="Special rate (optional)" hint="Empty = standard product rate"><input className="in" inputMode="decimal" value={f.rate} onChange={e => set('rate', e.target.value)} /></Field>
          <Field label="Start date"><input type="date" className="in" value={f.startDate} onChange={e => set('startDate', e.target.value)} /></Field>
          <Field label="Preferred delivery time"><select className="in" value={f.prefTime} onChange={e => set('prefTime', e.target.value)}>{['Early morning', 'Morning', 'Afternoon', 'Evening'].map(t => <option key={t}>{t}</option>)}</select></Field>
          <Field label="Previous dues (opening balance)" hint="Money this customer already owes you"><input className="in" inputMode="decimal" value={f.opening} onChange={e => set('opening', e.target.value)} /></Field>
        </div>
        <Field label="Notes"><textarea className="in" value={f.notes} onChange={e => set('notes', e.target.value)} maxLength={500} /></Field>
        {err && <div className="notice bad" role="alert">{err}</div>}
        <button className="btn primary block" onClick={save} disabled={busy}>{id ? 'Save changes' : 'Save customer'}</button>
      </div>
    </div>
  )
}

type Tab = 'deliveries' | 'bills' | 'payments' | 'rates' | 'message'

function CustomerDetail({ id }: { id: number }) {
  const c = useLiveQuery(() => db.customers.get(id), [id], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const bills = useLiveQuery(() => db.bills.where('customerId').equals(id).toArray(), [id], [])
  const payments = useLiveQuery(() => db.payments.where('customerId').equals(id).toArray(), [id], [])
  const pauses = useLiveQuery(() => db.pauses.where('customerId').equals(id).toArray(), [id], [])
  const rates = useLiveQuery(() => db.rates.toArray(), [], [])
  const [tab, setTab] = useState<Tab>('deliveries')
  const [month, setMonth] = useState(currentMonth())
  const [allTime, setAllTime] = useState(false)
  const entries = useLiveQuery(() => (allTime
    ? db.entries.where('[customerId+date]').between([id, ''], [id, '\uffff']).toArray()
    : db.entries.where('[customerId+date]').between([id, monthStart(month)], [id, monthEnd(month)], true, true).toArray()), [id, month, allTime], [])
  if (c === undefined && !products.length) return <Loading />
  if (!c) return <><a className="back" href="#/customers"><ChevronLeft size={20} />Customers</a><Empty icon={<UserX />} title="Customer not found" /></>
  const pmap = new Map(products.map(p => [p.id!, p]))
  const unit = pmap.get(c.productId)?.unit ?? 'L'
  const bal = balanceOf(c, bills, payments)
  const inMonth = (d: string) => allTime || d.slice(0, 7) === month
  const delivered = entries.filter(e => e.status === 'delivered')
  const pausedDays = (allTime ? [] : daysBetween(monthStart(month), monthEnd(month))).filter(d => d >= c.startDate && isPausedOn(pauses, id, d)).length
  const totalQty = delivered.reduce((s, e) => s + e.regularMl + e.extraMl, 0)
  const cur = resolveRate(rates, id, c.productId, todayISO())

  const act = async (fn: () => Promise<void>, ok: string) => { try { await fn(); toast(ok, 'ok') } catch (e) { toast(errMsg(e), 'err') } }
  const remove = async () => {
    if (await confirmDialog({ title: `Delete ${c.name}?`, body: 'Only customers with no delivery, bill or payment history can be deleted. This cannot be undone.', confirmLabel: 'Delete', danger: true })) {
      try { await deleteCustomer(id); toast('Customer deleted'); go('customers') } catch (e) { toast(errMsg(e), 'err') }
    }
  }
  const deactivate = async () => { if (await confirmDialog({ title: `Deactivate ${c.name}?`, body: 'Deliveries stop and the customer is hidden from daily entry. All bills, payments and history are kept.', confirmLabel: 'Deactivate', danger: true })) act(() => setCustomerStatus(id, 'inactive'), 'Customer deactivated') }

  return (
    <div className="stack">
      <a className="back" href="#/customers"><ChevronLeft size={20} />Customers</a>
      <div className="card">
        <div className="row"><div className="avatar" style={{ width: 54, height: 54 }}>{initials(c.name)}</div>
          <div className="grow"><h1 className="title" style={{ fontSize: 22, overflowWrap: 'anywhere' }}>{c.name}</h1><div className="sub">{c.code} · {c.area || 'No area'}</div></div>
          <span className={`badge ${c.status === 'active' ? 'green' : c.status === 'paused' ? 'amber' : 'gray'}`}>{c.status === 'active' ? 'Active' : c.status === 'paused' ? 'Paused' : 'Inactive'}</span></div>
        <div className="grid2" style={{ marginTop: 14 }}>
          <div className={`stat ${bal > 0 ? 'bad' : 'good'}`}><div className="k">Balance</div><div className="v num">{fmt(bal)}</div></div>
          <div className="stat"><div className="k">Daily</div><div className="v">{formatQty(c.dailyMl, unit)}</div><div className="k">{pmap.get(c.productId)?.name}{cur ? ` · ${fmt(cur.ratePaise)}/${UNITS[unit].short}` : ''}</div></div>
        </div>
        <div className="row wrap" style={{ marginTop: 12 }}>
          <a className="btn grow" href={`tel:${c.mobile}`}><Phone size={20} />Call</a>
          <a className="btn grow" href={`#/payments/${id}`}><Wallet size={20} />Payment</a>
          <a className="btn grow" href={`#/billing/new/${id}`}><Receipt size={20} />Bill</a>
        </div>
        <div className="row wrap" style={{ marginTop: 10 }}>
          <a className="btn sm" href={`#/customers/${id}/edit`}><Pencil size={18} />Edit</a>
          {c.status === 'active' && <button className="btn sm" onClick={() => act(() => setCustomerStatus(id, 'paused'), 'Delivery paused')}><Pause size={18} />Pause</button>}
          {c.status === 'paused' && <button className="btn sm green" onClick={() => act(() => setCustomerStatus(id, 'active'), 'Delivery resumed')}><Play size={18} />Resume</button>}
          {c.status === 'inactive' ? <button className="btn sm green" onClick={() => act(() => setCustomerStatus(id, 'active'), 'Customer activated')}>Activate</button> : <button className="btn sm danger" onClick={deactivate}>Deactivate</button>}
          <button className="btn sm danger" aria-label="Delete customer" onClick={remove}><Trash2 size={18} /></button>
        </div>
        <div className="sub" style={{ marginTop: 10 }}>{c.mobile}{c.address ? ` · ${c.address}` : ''}{c.prefTime ? ` · ${c.prefTime}` : ''}{c.notes ? ` · ${c.notes}` : ''}</div>
      </div>

      <Seg<Tab> value={tab} onChange={setTab} options={[{ v: 'deliveries', l: 'Deliveries' }, { v: 'bills', l: 'Bills' }, { v: 'payments', l: 'Payments' }, { v: 'rates', l: 'Rates' }, { v: 'message', l: 'Message' }]} />

      {(tab === 'deliveries' || tab === 'bills' || tab === 'payments') && (
        <div className="row wrap"><div className="grow" style={{ minWidth: 200, opacity: allTime ? 0.4 : 1 }}><MonthNav month={month} onChange={m => { setMonth(m); setAllTime(false) }} /></div><button className={`chip ${allTime ? 'on' : ''}`} onClick={() => setAllTime(!allTime)}>All time</button></div>
      )}

      {tab === 'deliveries' && <div className="card">
        <div className="grid3"><div className="stat good"><div className="k">Delivered</div><div className="v num">{delivered.length}</div></div><div className="stat warn"><div className="k">Skipped</div><div className="v num">{entries.length - delivered.length}</div></div><div className="stat"><div className="k">Paused days</div><div className="v num">{allTime ? '-' : pausedDays}</div></div></div>
        <p className="sub" style={{ margin: '10px 0' }}>Total delivered: <b>{formatQty(totalQty, unit)}</b>{pauses.length > 0 && <> · Paused periods: {pauses.map(p => `${dateLabel(p.from)} to ${p.to ? dateLabel(p.to) : 'now'}`).join(', ')}</>}</p>
        {entries.length === 0 ? <Empty icon={<Users />} title="No deliveries in this period" /> :
          <div className="table-wrap"><table><thead><tr><th>Date</th><th>Product</th><th className="r">Regular</th><th className="r">Extra</th><th>Status</th></tr></thead><tbody>
            {[...entries].sort((a, b) => b.date.localeCompare(a.date)).map(e => <tr key={e.id}><td>{dateLabel(e.date)}</td><td>{pmap.get(e.productId)?.name}</td><td className="r">{formatQty(e.regularMl, pmap.get(e.productId)?.unit)}</td><td className="r">{e.extraMl ? formatQty(e.extraMl, pmap.get(e.productId)?.unit) : '-'}</td><td>{e.status === 'delivered' ? <span className="badge green">Delivered</span> : <span className="badge amber">Skipped</span>}{e.billId ? ' ' : ''}{e.billId ? <span className="badge">Billed</span> : null}</td></tr>)}
          </tbody></table></div>}
      </div>}

      {tab === 'bills' && <div className="card">
        {bills.filter(b => inMonth(b.fromDate)).length === 0 ? <Empty icon={<Receipt />} title="No bills in this period" action={<a className="btn primary" href={`#/billing/new/${id}`}>Generate bill</a>} /> :
          <div className="list">{[...bills].filter(b => inMonth(b.fromDate)).sort((a, b) => b.createdAt - a.createdAt).map(b => <a className="item" key={b.id} href={`#/billing/view/${b.id}`}><div className="grow"><div className="t">{b.number} {b.status === 'void' && <span className="badge gray">Void</span>}</div><div className="s">{dateLabel(b.fromDate)}{b.toDate !== b.fromDate ? ` to ${dateLabel(b.toDate)}` : ''} · {b.deliveredDays} days</div></div><div className="total num" style={{ fontSize: 17 }}>{fmt(b.totalPaise)}</div></a>)}</div>}
      </div>}

      {tab === 'payments' && <div className="card">
        {payments.filter(p => inMonth(p.date)).length === 0 ? <Empty icon={<Wallet />} title="No payments in this period" action={<a className="btn primary" href={`#/payments/${id}`}>Record payment</a>} /> :
          <div className="list">{[...payments].filter(p => inMonth(p.date)).sort((a, b) => b.date.localeCompare(a.date)).map(p => <div className="item" key={p.id} style={{ opacity: p.voided ? 0.5 : 1 }}><div className="grow"><div className="t">{dateLabel(p.date)} {p.voided && <span className="badge gray">Cancelled</span>}</div><div className="s">{p.method}{p.reference ? ` · ${p.reference}` : ''}</div></div><div className="total num" style={{ fontSize: 17 }}>{fmt(p.amountPaise)}</div></div>)}</div>}
        <div className="kv" style={{ borderTop: '1px solid var(--line)', marginTop: 8 }}><span>Opening balance</span><span className="num">{fmt(c.openingPaise)}</span></div>
      </div>}

      {tab === 'rates' && <div className="card">
        <h2 className="h2">Rate history</h2>
        {(() => {
          const mine = rates.filter(r => r.customerId === id || (r.customerId === 0 && [...new Set(entries.map(e => e.productId).concat(c.productId))].includes(r.productId)))
          if (!mine.length) return <p className="sub">No rates set yet.</p>
          return <div className="list">{[...mine].sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom)).map(r => <div className="item" key={r.id}><div className="grow"><div className="t num">{pmap.get(r.productId)?.name}: {fmt(r.ratePaise)}{r.extraRatePaise && r.extraRatePaise !== r.ratePaise ? ` · extra ${fmt(r.extraRatePaise)}` : ''}</div><div className="s">From {dateLabel(r.effectiveFrom)} · {r.customerId ? 'special rate for this customer' : 'standard rate'}</div></div></div>)}</div>
        })()}
        <h2 className="h2" style={{ marginTop: 16 }}>Product history</h2>
        <p className="sub">{[...new Set(entries.map(e => pmap.get(e.productId)?.name).filter(Boolean))].join(', ') || pmap.get(c.productId)?.name || '-'}</p>
      </div>}

      {tab === 'message' && <div className="card"><QuickMessage customer={c} /></div>}
    </div>
  )
}
export { customerBalance, AppError }
