import { useEffect, useMemo, useRef, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Search, ChevronLeft, ChevronRight, Check, SkipForward, Minus, Plus, Save, Users, CheckCheck, UserPlus, X, MoreVertical, CalendarCheck, Eye, Pencil, Phone, Undo2, Milk } from 'lucide-react'
import { db, isPausedOn } from '../lib/db'
import { saveEntries, type EntryDraft } from '../lib/entries'
import { formatQty, UNITS, type UnitKey } from '../lib/money'
import { addDays, dateLabel, todayISO } from '../lib/dates'
import { PageHead, Empty, Loading, toast, errMsg, go } from '../lib/ui'
import type { Customer, Entry as EntryRow, Product } from '../lib/types'

type Status = 'delivered' | 'skipped' | 'pending'
interface Draft { regularMl: number; extraMl: number; status: Status }
const lk = (cid: number, pid: number) => `${cid}|${pid}`

// Unsaved changes survive switching screens (but not closing the app), per date.
const keep = new Map<string, { drafts: Map<string, Draft>; added: Map<number, Set<number>> }>()
// The date you were looking at is remembered. If it was "today", it moves to the new today the next day.
let lastPick: { date: string; wasToday: boolean } | null = null
const initialDate = () => (lastPick && !lastPick.wasToday ? lastPick.date : todayISO())

function Stepper({ label, value, unit, step, disabled, name, onChange }: { label: string; value: number; unit: UnitKey; step: number; disabled: boolean; name: string; onChange: (v: number) => void }) {
  return (
    <div className="stp">
      <span className="stp-l">{label}</span>
      <div className="qty">
        <button className="round" aria-label={`Decrease ${label.toLowerCase()} ${name}`} disabled={disabled || value <= 0} onClick={() => onChange(Math.max(0, value - step))}><Minus size={18} /></button>
        <b>{formatQty(value, unit)}</b>
        <button className="round" aria-label={`Increase ${label.toLowerCase()} ${name}`} disabled={disabled} onClick={() => onChange(value + step)}><Plus size={18} /></button>
      </div>
    </div>
  )
}

interface MenuItem { label: string; icon: React.ReactNode; onClick: () => void; disabled?: boolean; danger?: boolean }
function Kebab({ name, items }: { name: string; items: MenuItem[] }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const out = (e: Event) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('mousedown', out); document.addEventListener('touchstart', out); document.addEventListener('keydown', esc)
    return () => { document.removeEventListener('mousedown', out); document.removeEventListener('touchstart', out); document.removeEventListener('keydown', esc) }
  }, [open])
  return (
    <div className="menu-wrap" ref={ref}>
      <button className="kebab" aria-label={`More actions for ${name}`} aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(!open)}><MoreVertical size={22} /></button>
      {open && <div className="menu" role="menu">{items.map(it => <button key={it.label} role="menuitem" className={it.danger ? 'danger' : ''} disabled={it.disabled} onClick={() => { setOpen(false); it.onClick() }}>{it.icon}{it.label}</button>)}</div>}
    </div>
  )
}

export default function Entry() {
  const [date, setDateRaw] = useState(initialDate)
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<'all' | 'pending' | 'delivered' | 'skipped'>('all')
  const [group, setGroup] = useState(0)
  const [adding, setAdding] = useState<number | null>(null)
  const [, force] = useState(0)
  const [saving, setSaving] = useState(false)
  const setDate = (d: string) => { if (!d) return; lastPick = { date: d, wasToday: d === todayISO() }; setDateRaw(d); setAdding(null) }
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const groups = useLiveQuery(() => db.groups.orderBy('name').toArray(), [], [])
  const pauses = useLiveQuery(() => db.pauses.toArray(), [], [])
  const saved = useLiveQuery(() => db.entries.where('date').equals(date).toArray(), [date], undefined)
  const pmap = useMemo(() => new Map<number, Product>(products.map(p => [p.id!, p])), [products])
  const savedMap = useMemo(() => new Map<string, EntryRow>((saved ?? []).map(e => [lk(e.customerId, e.productId), e])), [saved])
  if (!keep.has(date)) keep.set(date, { drafts: new Map(), added: new Map() })
  const { drafts, added } = keep.get(date)!
  const today = todayISO()

  if (!customers || !saved) return <Loading />

  const eligible = customers.filter(c => c.startDate <= date && (c.status !== 'inactive' || saved.some(e => e.customerId === c.id)))
    .sort((a, b) => a.name.localeCompare(b.name))

  const unitOf = (pid: number) => pmap.get(pid)?.unit ?? 'L'
  const linesOf = (c: Customer): number[] => {
    const ids = [c.productId]
    for (const e of saved) if (e.customerId === c.id && !ids.includes(e.productId)) ids.push(e.productId)
    for (const p of added.get(c.id!) ?? []) if (!ids.includes(p)) ids.push(p)
    return ids
  }
  const defaultQty = (c: Customer, pid: number) => pid === c.productId ? c.dailyMl : unitOf(pid) === 'pc' ? 1000 : UNITS[unitOf(pid)].steps[0] * 4
  const current = (c: Customer, pid: number): Draft => {
    const d = drafts.get(lk(c.id!, pid))
    if (d) return d
    const s = savedMap.get(lk(c.id!, pid))
    if (s) return { regularMl: s.regularMl, extraMl: s.extraMl, status: s.status }
    return { regularMl: defaultQty(c, pid), extraMl: 0, status: 'pending' }
  }
  const isDirty = (c: Customer, pid: number) => {
    const d = drafts.get(lk(c.id!, pid))
    if (!d) return false
    const s = savedMap.get(lk(c.id!, pid))
    if (!s) return d.status !== 'pending'
    return d.status !== s.status || d.regularMl !== s.regularMl || d.extraMl !== s.extraMl
  }
  const patch = (c: Customer, pid: number, p: Partial<Draft>) => { drafts.set(lk(c.id!, pid), { ...current(c, pid), ...p }); force(n => n + 1) }
  const custDirty = (c: Customer) => linesOf(c).some(pid => isDirty(c, pid))
  const custStatus = (c: Customer): Status => {
    const st = linesOf(c).map(pid => current(c, pid).status)
    return st.includes('delivered') ? 'delivered' : st.includes('skipped') ? 'skipped' : 'pending'
  }
  const isPaused = (c: Customer) => isPausedOn(pauses, c.id!, date) && !saved.some(e => e.customerId === c.id)
  const gIds = new Set(groups.map(g => g.id))

  const rows = eligible.filter(c => {
    const t = q.trim().toLowerCase()
    if (t && !(c.name.toLowerCase().includes(t) || c.area.toLowerCase().includes(t) || c.code.toLowerCase().includes(t))) return false
    if (group === -1 ? (c.groupId != null && gIds.has(c.groupId)) : group > 0 && c.groupId !== group) return false
    if (filter !== 'all' && custStatus(c) !== filter) return false
    return true
  })
  const live = eligible.filter(c => !isPaused(c))
  const cnt = (s: Status) => live.filter(c => custStatus(c) === s).length
  const litres = live.reduce((sum, c) => sum + linesOf(c).reduce((s2, pid) => { const d = current(c, pid); return s2 + (d.status === 'delivered' && ['L', '500ml'].includes(unitOf(pid)) ? d.regularMl + d.extraMl : 0) }, 0), 0)
  const dirtyLines = eligible.flatMap(c => linesOf(c).filter(pid => isDirty(c, pid)).map(pid => ({ c, pid })))

  const markAll = () => {
    let n = 0
    for (const c of rows.filter(r => !isPaused(r))) {
      if (savedMap.get(lk(c.id!, c.productId))?.billId) continue
      const d = current(c, c.productId)
      if (d.status === 'pending' && d.regularMl + d.extraMl > 0) { drafts.set(lk(c.id!, c.productId), { ...d, status: 'delivered' }); n++ }
    }
    force(x => x + 1); toast(n ? `${n} marked delivered. Press Save all.` : 'Nothing pending to mark.')
  }
  const saveAll = async () => {
    if (saving) return
    setSaving(true)
    try {
      const list: EntryDraft[] = dirtyLines.map(({ c, pid }) => ({ customerId: c.id!, productId: pid, ...current(c, pid) }))
      const r = await saveEntries(date, list)
      for (const { c, pid } of dirtyLines) drafts.delete(lk(c.id!, pid))
      force(x => x + 1)
      toast(`${r.saved} saved${r.locked ? `, ${r.locked} already on a bill (not changed)` : ''}`, 'ok')
    } catch (e) { toast(errMsg(e), 'err') } finally { setSaving(false) }
  }
  const delivered = (c: Customer, pid: number) => {
    const d = current(c, pid)
    if (d.status === 'delivered') return patch(c, pid, { status: 'pending' })
    if (d.regularMl + d.extraMl <= 0) return toast('Add a quantity first.', 'err')
    patch(c, pid, { status: 'delivered' })
  }
  const skip = (c: Customer, pid: number) => patch(c, pid, { status: current(c, pid).status === 'skipped' ? 'pending' : 'skipped' })
  const addLine = (c: Customer, pid: number) => {
    const set = added.get(c.id!) ?? new Set<number>(); set.add(pid); added.set(c.id!, set)
    drafts.set(lk(c.id!, pid), { regularMl: defaultQty(c, pid), extraMl: 0, status: 'pending' })
    setAdding(null); force(n => n + 1)
  }
  const removeLine = (c: Customer, pid: number) => {
    if (savedMap.has(lk(c.id!, pid))) return patch(c, pid, { status: 'pending' }) // saving will remove the stored entry
    added.get(c.id!)?.delete(pid); drafts.delete(lk(c.id!, pid)); force(n => n + 1)
  }
  const clearEntry = (c: Customer) => {
    for (const pid of linesOf(c)) {
      if (savedMap.get(lk(c.id!, pid))?.billId) continue
      if (savedMap.has(lk(c.id!, pid))) patch(c, pid, { status: 'pending' })
      else { drafts.delete(lk(c.id!, pid)); if (pid !== c.productId) added.get(c.id!)?.delete(pid) }
    }
    force(n => n + 1)
  }
  const addExtra = (c: Customer, ml: number) => patch(c, c.productId, { extraMl: current(c, c.productId).extraMl + ml })

  return (
    <div>
      <PageHead title="Daily Entry" right={<a className="btn sm primary" href="#/customers/new"><UserPlus size={20} />Add customer</a>} />
      <div className="entrybar">
        <div className="row">
          <button className="btn sm" aria-label="Previous day" onClick={() => setDate(addDays(date, -1))}><ChevronLeft size={20} /></button>
          <input className="in grow" type="date" value={date} max={today} onChange={e => setDate(e.target.value)} aria-label="Date" />
          <button className="btn sm" aria-label="Next day" disabled={date >= today} onClick={() => setDate(addDays(date, 1))}><ChevronRight size={20} /></button>
          <button className={`btn sm ${date === today ? '' : 'primary'}`} onClick={() => setDate(today)} disabled={date === today} aria-label="Go to today"><CalendarCheck size={20} />Today</button>
        </div>
        <div className="row" style={{ marginTop: 8 }}>
          <div className="search grow"><Search /><input className="in" type="search" placeholder="Search customer" value={q} onChange={e => setQ(e.target.value)} aria-label="Search customer" /></div>
          <button className="btn sm green" onClick={markAll} aria-label="Mark all pending as delivered"><CheckCheck size={20} />All</button>
        </div>
        {groups.length > 0 && <select className="in" style={{ marginTop: 8, minHeight: 44 }} value={group} onChange={e => setGroup(Number(e.target.value))} aria-label="Group"><option value={0}>All groups</option>{groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}<option value={-1}>No group</option></select>}
        <div className="chips" style={{ marginTop: 8 }}>
          {([['all', `All ${live.length}`], ['pending', `Pending ${cnt('pending')}`], ['delivered', `Delivered ${cnt('delivered')}`], ['skipped', `Skipped ${cnt('skipped')}`]] as const).map(([k, l]) => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{l}</button>)}
          <span className="chip" style={{ borderStyle: 'dashed' }}>{formatQty(litres)} total</span>
        </div>
      </div>

      <p className="sub" style={{ margin: '4px 0' }}>{dateLabel(date)}{date === today ? ' (today)' : ''}</p>
      {customers.length === 0 && <div className="card"><Empty icon={<Users />} title="No customers yet" text="Add customers first, then save deliveries here." action={<a className="btn primary" href="#/customers/new">Add customer</a>} /></div>}
      {customers.length > 0 && rows.length === 0 && <div className="card" style={{ marginTop: 10 }}><Empty icon={<Search />} title="No customers to show" text="Change the search, group or filter." /></div>}

      {rows.map(c => {
        const paused = isPaused(c); const dirty = custDirty(c); const st = custStatus(c)
        const lines = linesOf(c); const main = current(c, c.productId); const u = unitOf(c.productId)
        const mainLocked = !!savedMap.get(lk(c.id!, c.productId))?.billId
        const free = products.filter(p => p.active && !lines.includes(p.id!))
        const step = UNITS[u].steps[0]
        const off = mainLocked
        const total = lines.reduce((s, pid) => s + (unitOf(pid) === u ? current(c, pid).regularMl + current(c, pid).extraMl : 0), 0)
        const phone = c.mobile.trim()
        const items: MenuItem[] = [
          { label: `+${formatQty(UNITS[u].steps[0], u)} extra`, icon: <Plus size={18} />, onClick: () => addExtra(c, UNITS[u].steps[0]), disabled: paused || off || main.status === 'skipped' },
          { label: `+${formatQty(UNITS[u].steps[1], u)} extra`, icon: <Plus size={18} />, onClick: () => addExtra(c, UNITS[u].steps[1]), disabled: paused || off || main.status === 'skipped' },
          { label: `+${formatQty(UNITS[u].steps[2] ?? UNITS[u].steps[1] * 2, u)} extra`, icon: <Plus size={18} />, onClick: () => addExtra(c, UNITS[u].steps[2] ?? UNITS[u].steps[1] * 2), disabled: paused || off || main.status === 'skipped' },
          { label: 'Add other milk / product', icon: <Milk size={18} />, onClick: () => setAdding(c.id!), disabled: paused || free.length === 0 },
          { label: 'Reset this entry', icon: <Undo2 size={18} />, onClick: () => clearEntry(c), disabled: paused },
          { label: 'View details', icon: <Eye size={18} />, onClick: () => go(`customers/${c.id}`) },
          { label: 'Edit customer', icon: <Pencil size={18} />, onClick: () => go(`customers/${c.id}/edit`) },
          { label: phone ? 'Call customer' : 'Call (no phone number)', icon: <Phone size={18} />, onClick: () => { location.href = `tel:${phone}` }, disabled: !phone }
        ]
        return (
          <div key={c.id} className={`ecard compact ${paused ? 'paused' : st} ${dirty ? 'dirty' : ''}`}>
            <div className="erow1">
              <div className="grow">
                <div className="ename">{c.name}</div>
                <div className="sub">{[c.area || c.code, paused ? 'Paused' : `Total ${formatQty(total, u)}`].filter(Boolean).join(' · ')}</div>
              </div>
              {paused ? <span className="badge amber">Paused</span> : mainLocked ? <span className="badge">On bill</span> : dirty ? <span className="badge amber">Unsaved</span> : lines.some(pid => savedMap.has(lk(c.id!, pid))) ? <span className="badge green">Saved</span> : null}
              <Kebab name={c.name} items={items} />
            </div>
            {paused
              ? <p className="sub" style={{ marginTop: 4 }}>Delivery is paused and will not be billed.</p>
              : <>
                <div className="erow2">
                  <Stepper label="Regular" value={main.regularMl} unit={u} step={step} name={`for ${c.name}`} disabled={off || main.status === 'skipped'} onChange={v => patch(c, c.productId, { regularMl: v })} />
                  <Stepper label="Extra" value={main.extraMl} unit={u} step={step} name={`for ${c.name}`} disabled={off || main.status === 'skipped'} onChange={v => patch(c, c.productId, { extraMl: v })} />
                </div>
                <div className="erow3">
                  <button className={`btn ${main.status === 'delivered' ? 'green' : ''}`} disabled={off} onClick={() => delivered(c, c.productId)}><Check size={20} />{main.status === 'delivered' ? 'Delivered' : 'Delivered?'}</button>
                  <button className="btn" style={main.status === 'skipped' ? { background: 'var(--amber)', color: '#fff', borderColor: 'var(--amber)' } : undefined} disabled={off} onClick={() => skip(c, c.productId)}><SkipForward size={18} />Skip</button>
                </div>
                {mainLocked && <p className="sub" style={{ marginTop: 6 }}>This day is already on a bill. Cancel the bill to change it.</p>}
                {lines.filter(pid => pid !== c.productId).map(pid => {
                  const d = current(c, pid); const lu = unitOf(pid); const lock = !!savedMap.get(lk(c.id!, pid))?.billId
                  return (
                    <div className="eline" key={pid}>
                      <div className="row between"><b className="ename" style={{ fontSize: 15 }}>{pmap.get(pid)?.name}</b>
                        <div className="row">{lock ? <span className="badge">On bill</span> : isDirty(c, pid) ? <span className="badge amber">Unsaved</span> : savedMap.has(lk(c.id!, pid)) ? <span className="badge green">Saved</span> : null}{!lock && <button className="btn sm ghost" aria-label={`Remove ${pmap.get(pid)?.name} for ${c.name}`} onClick={() => removeLine(c, pid)}><X size={18} /></button>}</div></div>
                      <div className="erow2" style={{ alignItems: 'center' }}>
                        <Stepper label="Quantity" value={d.regularMl} unit={lu} step={UNITS[lu].steps[0]} name={`${pmap.get(pid)?.name} for ${c.name}`} disabled={lock || d.status === 'skipped'} onChange={v => patch(c, pid, { regularMl: v })} />
                        <div className="erow3" style={{ marginTop: 0, alignSelf: 'end' }}>
                          <button className={`btn ${d.status === 'delivered' ? 'green' : ''}`} disabled={lock} onClick={() => delivered(c, pid)} aria-label={`Delivered ${pmap.get(pid)?.name} for ${c.name}`}><Check size={20} /></button>
                          <button className="btn" style={d.status === 'skipped' ? { background: 'var(--amber)', color: '#fff', borderColor: 'var(--amber)' } : undefined} disabled={lock} onClick={() => skip(c, pid)} aria-label={`Skip ${pmap.get(pid)?.name} for ${c.name}`}><SkipForward size={18} /></button>
                        </div>
                      </div>
                    </div>
                  )
                })}
                {adding === c.id && (
                  <div className="row wrap" style={{ marginTop: 10 }}>
                    <select className="in grow" aria-label="Choose product to add" defaultValue="" onChange={e => e.target.value && addLine(c, Number(e.target.value))}><option value="">Choose milk / product</option>{free.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
                    <button className="btn sm" onClick={() => setAdding(null)}>Cancel</button>
                  </div>
                )}
              </>}
          </div>
        )
      })}

      {dirtyLines.length > 0 && (
        <div className="savebar"><div>
          <div className="grow"><b>{dirtyLines.length} unsaved</b><div className="sub">Not stored until you save</div></div>
          <button className="btn primary" style={{ minHeight: 52 }} onClick={saveAll} disabled={saving}><Save size={20} />{saving ? 'Saving...' : 'Save all'}</button>
        </div></div>
      )}
    </div>
  )
}
