import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Search, ChevronLeft, ChevronRight, Check, SkipForward, Minus, Plus, Save, Users, CheckCheck, UserPlus, X } from 'lucide-react'
import { db, isPausedOn } from '../lib/db'
import { saveEntries, type EntryDraft } from '../lib/entries'
import { formatQty, UNITS } from '../lib/money'
import { addDays, dateLabel, todayISO } from '../lib/dates'
import { PageHead, Empty, Loading, toast, errMsg } from '../lib/ui'
import type { Customer, Entry as EntryRow, Product } from '../lib/types'

type Status = 'delivered' | 'skipped' | 'pending'
interface Draft { regularMl: number; extraMl: number; status: Status }
const lk = (cid: number, pid: number) => `${cid}|${pid}`

// Unsaved changes survive switching screens (but not closing the app), per date.
const keep = new Map<string, { drafts: Map<string, Draft>; added: Map<number, Set<number>> }>()

export default function Entry() {
  const [date, setDate] = useState(todayISO())
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<'all' | 'pending' | 'delivered' | 'skipped'>('all')
  const [adding, setAdding] = useState<number | null>(null)
  const [, force] = useState(0)
  const [saving, setSaving] = useState(false)
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const pauses = useLiveQuery(() => db.pauses.toArray(), [], [])
  const saved = useLiveQuery(() => db.entries.where('date').equals(date).toArray(), [date], undefined)
  const pmap = useMemo(() => new Map<number, Product>(products.map(p => [p.id!, p])), [products])
  const savedMap = useMemo(() => new Map<string, EntryRow>((saved ?? []).map(e => [lk(e.customerId, e.productId), e])), [saved])
  if (!keep.has(date)) keep.set(date, { drafts: new Map(), added: new Map() })
  const { drafts, added } = keep.get(date)!

  if (!customers || !saved) return <Loading />

  const eligible = customers.filter(c => c.startDate <= date && (c.status !== 'inactive' || (saved ?? []).some(e => e.customerId === c.id)))
    .sort((a, b) => a.name.localeCompare(b.name))

  const unitOf = (pid: number) => pmap.get(pid)?.unit ?? 'L'
  const linesOf = (c: Customer): number[] => {
    const ids = [c.productId]
    for (const e of saved) if (e.customerId === c.id && !ids.includes(e.productId)) ids.push(e.productId)
    for (const p of added.get(c.id!) ?? []) if (!ids.includes(p)) ids.push(p)
    return ids
  }
  const current = (c: Customer, pid: number): Draft => {
    const d = drafts.get(lk(c.id!, pid))
    if (d) return d
    const s = savedMap.get(lk(c.id!, pid))
    if (s) return { regularMl: s.regularMl, extraMl: s.extraMl, status: s.status }
    return { regularMl: pid === c.productId ? c.dailyMl : UNITS[unitOf(pid)].steps[0] * (unitOf(pid) === 'pc' ? 1 : 4), extraMl: 0, status: 'pending' }
  }
  const isDirty = (c: Customer, pid: number) => {
    const d = drafts.get(lk(c.id!, pid))
    if (!d) return false
    const s = savedMap.get(lk(c.id!, pid))
    if (!s) return d.status !== 'pending'
    return d.status !== s.status || d.regularMl !== s.regularMl || d.extraMl !== s.extraMl
  }
  const patch = (c: Customer, pid: number, p: Partial<Draft>) => { drafts.set(lk(c.id!, pid), { ...current(c, pid), ...p }); force(n => n + 1) }
  const custDirty = (c: Customer) => linesOf(c).some(pid => isDirty(c, pid))
  const custStatus = (c: Customer): Status => {
    const st = linesOf(c).map(pid => current(c, pid).status)
    return st.includes('delivered') ? 'delivered' : st.includes('skipped') ? 'skipped' : 'pending'
  }
  const isPaused = (c: Customer) => (c.status === 'paused' || isPausedOn(pauses, c.id!, date)) && !saved.some(e => e.customerId === c.id)

  const rows = eligible.filter(c => {
    const t = q.trim().toLowerCase()
    if (t && !(c.name.toLowerCase().includes(t) || c.area.toLowerCase().includes(t) || c.code.toLowerCase().includes(t))) return false
    if (filter !== 'all' && custStatus(c) !== filter) return false
    return true
  })
  const live = eligible.filter(c => !isPaused(c))
  const cnt = (s: Status) => live.filter(c => custStatus(c) === s).length
  const litres = live.reduce((sum, c) => sum + linesOf(c).reduce((s2, pid) => { const d = current(c, pid); return s2 + (d.status === 'delivered' && ['L', '500ml'].includes(unitOf(pid)) ? d.regularMl + d.extraMl : 0) }, 0), 0)
  const dirtyLines = eligible.flatMap(c => linesOf(c).filter(pid => isDirty(c, pid)).map(pid => ({ c, pid })))

  const markAll = () => {
    let n = 0
    for (const c of live) {
      if (savedMap.get(lk(c.id!, c.productId))?.billId) continue
      const d = current(c, c.productId)
      if (d.status === 'pending' && d.regularMl + d.extraMl > 0) { drafts.set(lk(c.id!, c.productId), { ...d, status: 'delivered' }); n++ }
    }
    force(x => x + 1); toast(n ? `${n} marked delivered. Press Save all.` : 'Nothing pending to mark.')
  }
  const saveAll = async () => {
    setSaving(true)
    try {
      const list: EntryDraft[] = dirtyLines.map(({ c, pid }) => ({ customerId: c.id!, productId: pid, ...current(c, pid) }))
      const r = await saveEntries(date, list)
      for (const { c, pid } of dirtyLines) drafts.delete(lk(c.id!, pid))
      force(x => x + 1)
      toast(`${r.saved} saved${r.locked ? `, ${r.locked} already billed (locked)` : ''}`, 'ok')
    } catch (e) { toast(errMsg(e), 'err') } finally { setSaving(false) }
  }
  const delivered = (c: Customer, pid: number) => {
    const d = current(c, pid)
    if (d.status === 'delivered') return patch(c, pid, { status: 'pending' })
    if (d.regularMl + d.extraMl <= 0) return toast('Add a quantity first.', 'err')
    patch(c, pid, { status: 'delivered' })
  }
  const skip = (c: Customer, pid: number) => patch(c, pid, { status: current(c, pid).status === 'skipped' ? 'pending' : 'skipped' })
  const addLine = (c: Customer, pid: number) => {
    const set = added.get(c.id!) ?? new Set<number>(); set.add(pid); added.set(c.id!, set)
    const step = UNITS[unitOf(pid)].steps[0]
    drafts.set(lk(c.id!, pid), { regularMl: unitOf(pid) === 'pc' ? 1000 : step * 4, extraMl: 0, status: 'pending' })
    setAdding(null); force(n => n + 1)
  }
  const removeLine = (c: Customer, pid: number) => {
    if (savedMap.has(lk(c.id!, pid))) return patch(c, pid, { status: 'pending' }) // saving will delete the stored entry
    added.get(c.id!)?.delete(pid); drafts.delete(lk(c.id!, pid)); force(n => n + 1)
  }

  const Line = ({ c, pid, off }: { c: Customer; pid: number; off: boolean }) => {
    const d = current(c, pid); const u = unitOf(pid); const step = UNITS[u].steps[0]
    const locked = !!savedMap.get(lk(c.id!, pid))?.billId
    const dis = off || locked; const primary = pid === c.productId
    return (
      <div style={primary ? undefined : { marginTop: 12, paddingTop: 10, borderTop: '1px dashed var(--line)' }}>
        {!primary && <div className="row between"><b>{pmap.get(pid)?.name}</b><div className="row">{locked ? <span className="badge">Billed</span> : isDirty(c, pid) ? <span className="badge amber">Unsaved</span> : savedMap.has(lk(c.id!, pid)) ? <span className="badge green">Saved</span> : null}{!locked && <button className="btn sm ghost" aria-label={`Remove ${pmap.get(pid)?.name}`} onClick={() => removeLine(c, pid)}><X size={18} /></button>}</div></div>}
        <div className="row between wrap" style={{ marginTop: 10 }}>
          <span className="lbl">{primary ? 'Regular' : 'Quantity'}</span>
          <div className="qty"><button className="round" aria-label={`Decrease ${primary ? 'regular' : pmap.get(pid)?.name} for ${c.name}`} disabled={dis || d.status === 'skipped' || d.regularMl <= 0} onClick={() => patch(c, pid, { regularMl: Math.max(0, d.regularMl - step) })}><Minus size={20} /></button><b>{formatQty(d.regularMl, u)}</b><button className="round" aria-label={`Increase ${primary ? 'regular' : pmap.get(pid)?.name} for ${c.name}`} disabled={dis || d.status === 'skipped'} onClick={() => patch(c, pid, { regularMl: d.regularMl + step })}><Plus size={20} /></button></div>
        </div>
        <div className="row between wrap" style={{ marginTop: 8 }}>
          <span className="lbl">Extra</span>
          <div className="qty"><button className="round" aria-label={`Decrease extra ${primary ? '' : pmap.get(pid)?.name + ' '}for ${c.name}`} disabled={dis || d.status === 'skipped' || d.extraMl <= 0} onClick={() => patch(c, pid, { extraMl: Math.max(0, d.extraMl - step) })}><Minus size={20} /></button><b>{formatQty(d.extraMl, u)}</b><button className="round" aria-label={`Increase extra ${primary ? '' : pmap.get(pid)?.name + ' '}for ${c.name}`} disabled={dis || d.status === 'skipped'} onClick={() => patch(c, pid, { extraMl: d.extraMl + step })}><Plus size={20} /></button></div>
        </div>
        <div className="row wrap" style={{ marginTop: 8 }}>{UNITS[u].steps.map(s => <button key={s} className="quick" disabled={dis || d.status === 'skipped'} onClick={() => patch(c, pid, { extraMl: d.extraMl + s })}>+{formatQty(s, u)}</button>)}</div>
        <div className="row between" style={{ marginTop: 10 }}><span className="lbl">Total</span><b className="total num">{d.status === 'skipped' ? 'Skipped' : formatQty(d.regularMl + d.extraMl, u)}</b></div>
        <div className="big-actions">
          <button className={`btn ${d.status === 'delivered' ? 'green' : ''}`} style={{ minHeight: 52 }} disabled={dis} onClick={() => delivered(c, pid)}><Check size={22} />{d.status === 'delivered' ? 'Delivered' : 'Delivered?'}</button>
          <button className="btn" style={{ minHeight: 52, background: d.status === 'skipped' ? 'var(--amber)' : undefined, color: d.status === 'skipped' ? '#fff' : undefined }} disabled={dis} onClick={() => skip(c, pid)}><SkipForward size={20} />Skip</button>
        </div>
        {locked && <p className="sub" style={{ marginTop: 6 }}>Already on a bill. Void the bill to change it.</p>}
      </div>
    )
  }

  return (
    <div>
      <PageHead back={{ to: 'dashboard', label: 'Home' }} title="Daily Entry" right={<a className="btn sm primary" href="#/customers/new"><UserPlus size={20} />Add customer</a>} />
      <div className="entrybar">
        <div className="row">
          <button className="btn sm" aria-label="Previous day" onClick={() => setDate(addDays(date, -1))}><ChevronLeft size={20} /></button>
          <input className="in grow" type="date" value={date} max={todayISO()} onChange={e => e.target.value && setDate(e.target.value)} aria-label="Date" />
          <button className="btn sm" aria-label="Next day" disabled={date >= todayISO()} onClick={() => setDate(addDays(date, 1))}><ChevronRight size={20} /></button>
        </div>
        <div className="row" style={{ marginTop: 8 }}>
          <div className="search grow"><Search /><input className="in" type="search" placeholder="Search customer" value={q} onChange={e => setQ(e.target.value)} aria-label="Search customer" /></div>
          <button className="btn sm green" onClick={markAll} aria-label="Mark all pending as delivered"><CheckCheck size={20} />All</button>
        </div>
        <div className="chips" style={{ marginTop: 8 }}>
          {([['all', `All ${live.length}`], ['pending', `Pending ${cnt('pending')}`], ['delivered', `Delivered ${cnt('delivered')}`], ['skipped', `Skipped ${cnt('skipped')}`]] as const).map(([k, l]) => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{l}</button>)}
          <span className="chip" style={{ borderStyle: 'dashed' }}>{formatQty(litres)} total</span>
        </div>
      </div>

      <p className="sub">{dateLabel(date)}{date === todayISO() ? ' (today)' : ''}</p>
      {customers.length === 0 && <div className="card"><Empty icon={<Users />} title="No customers yet" text="Add customers first, then record deliveries here." action={<a className="btn primary" href="#/customers/new">Add customer</a>} /></div>}
      {customers.length > 0 && rows.length === 0 && <div className="card" style={{ marginTop: 10 }}><Empty icon={<Search />} title="No customers to show" text="Change the search or filter." /></div>}

      {rows.map(c => {
        const paused = isPaused(c); const dirty = custDirty(c); const st = custStatus(c)
        const lines = linesOf(c)
        const free = products.filter(p => p.active && !lines.includes(p.id!))
        return (
          <div key={c.id} className={`ecard ${paused ? 'paused' : st} ${dirty ? 'dirty' : ''}`}>
            <div className="row between">
              <div className="grow"><div className="t" style={{ fontWeight: 800, fontSize: 17, overflowWrap: 'anywhere' }}>{c.name}</div><div className="sub">{[c.area || c.code, pmap.get(c.productId)?.name].filter(Boolean).join(' · ')}</div></div>
              {paused ? <span className="badge amber">Paused</span> : dirty ? <span className="badge amber">Unsaved</span> : lines.some(pid => savedMap.has(lk(c.id!, pid))) ? <span className="badge green">Saved</span> : <span className="badge gray">Not entered</span>}
            </div>
            {paused ? <p className="sub" style={{ marginTop: 6 }}>Delivery is paused. It is not billed. Resume from the customer page.</p> : <>
              {lines.map(pid => <Line key={pid} c={c} pid={pid} off={false} />)}
              {adding === c.id
                ? <div style={{ marginTop: 12 }} className="row wrap">
                    <select className="in grow" aria-label="Choose product to add" defaultValue="" onChange={e => e.target.value && addLine(c, Number(e.target.value))}><option value="">Choose milk / product</option>{free.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
                    <button className="btn sm" onClick={() => setAdding(null)}>Cancel</button>
                  </div>
                : <button className="btn block" style={{ marginTop: 12 }} disabled={free.length === 0} onClick={() => setAdding(c.id!)}><Plus size={20} />Add other milk / product</button>}
            </>}
          </div>
        )
      })}

      {dirtyLines.length > 0 && (
        <div className="savebar"><div>
          <div className="grow"><b>{dirtyLines.length} unsaved</b><div className="sub">Not stored until you save</div></div>
          <button className="btn primary" style={{ minHeight: 52 }} onClick={saveAll} disabled={saving}><Save size={20} />{saving ? 'Saving...' : 'Save all'}</button>
        </div></div>
      )}
    </div>
  )
}
