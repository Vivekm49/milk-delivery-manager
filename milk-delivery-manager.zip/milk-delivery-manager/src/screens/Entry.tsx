import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Search, ChevronLeft, ChevronRight, Check, SkipForward, Minus, Plus, Save, Users, CheckCheck } from 'lucide-react'
import { db, isPausedOn } from '../lib/db'
import { saveEntries, type EntryDraft } from '../lib/entries'
import { formatQty, UNITS } from '../lib/money'
import { addDays, dateLabel, todayISO } from '../lib/dates'
import { PageHead, Empty, Loading, toast, errMsg } from '../lib/ui'
import type { Customer, Entry as EntryRow, Product } from '../lib/types'

type Status = 'delivered' | 'skipped' | 'pending'
interface Draft { regularMl: number; extraMl: number; status: Status }

// Unsaved changes survive switching screens (but not closing the app), per date.
const keep = new Map<string, Map<number, Draft>>()

export default function Entry() {
  const [date, setDate] = useState(todayISO())
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<'all' | 'pending' | 'delivered' | 'skipped'>('all')
  const [, force] = useState(0)
  const [saving, setSaving] = useState(false)
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const pauses = useLiveQuery(() => db.pauses.toArray(), [], [])
  const saved = useLiveQuery(() => db.entries.where('date').equals(date).toArray(), [date], undefined)
  const pmap = useMemo(() => new Map<number, Product>(products.map(p => [p.id!, p])), [products])
  const savedMap = useMemo(() => new Map<number, EntryRow>((saved ?? []).map(e => [e.customerId, e])), [saved])
  if (!keep.has(date)) keep.set(date, new Map())
  const drafts = keep.get(date)!

  if (!customers || !saved) return <Loading />

  const eligible = customers.filter(c => c.startDate <= date && (c.status !== 'inactive' || savedMap.has(c.id!)))
    .sort((a, b) => a.name.localeCompare(b.name))

  const current = (c: Customer): Draft => {
    const d = drafts.get(c.id!)
    if (d) return d
    const s = savedMap.get(c.id!)
    if (s) return { regularMl: s.regularMl, extraMl: s.extraMl, status: s.status }
    return { regularMl: c.dailyMl, extraMl: 0, status: 'pending' }
  }
  const isDirty = (c: Customer) => {
    const d = drafts.get(c.id!)
    if (!d) return false
    const s = savedMap.get(c.id!)
    if (!s) return d.status !== 'pending'
    return d.status !== s.status || d.regularMl !== s.regularMl || d.extraMl !== s.extraMl
  }
  const patch = (c: Customer, p: Partial<Draft>) => { drafts.set(c.id!, { ...current(c), ...p }); force(n => n + 1) }
  const unitOf = (c: Customer) => pmap.get(c.productId)?.unit ?? 'L'

  const stateOf = (c: Customer) => {
    const paused = c.status === 'paused' || isPausedOn(pauses, c.id!, date)
    const locked = !!savedMap.get(c.id!)?.billId
    return { paused: paused && !savedMap.has(c.id!), locked }
  }
  const rows = eligible.filter(c => {
    const t = q.trim().toLowerCase()
    if (t && !(c.name.toLowerCase().includes(t) || c.area.toLowerCase().includes(t) || c.code.toLowerCase().includes(t))) return false
    if (filter !== 'all' && current(c).status !== filter) return false
    return true
  })
  const dirtyList = eligible.filter(isDirty)
  const live = eligible.filter(c => !stateOf(c).paused)
  const cnt = (s: Status) => live.filter(c => current(c).status === s).length
  const litres = live.filter(c => current(c).status === 'delivered' && ['L', '500ml'].includes(unitOf(c))).reduce((s, c) => s + current(c).regularMl + current(c).extraMl, 0)

  const markAll = () => {
    let n = 0
    for (const c of live) { const st = stateOf(c); if (st.locked) continue; const d = current(c); if (d.status === 'pending' && d.regularMl + d.extraMl > 0) { drafts.set(c.id!, { ...d, status: 'delivered' }); n++ } }
    force(x => x + 1); toast(n ? `${n} marked delivered. Press Save all.` : 'Nothing pending to mark.')
  }
  const saveAll = async () => {
    setSaving(true)
    try {
      const list: EntryDraft[] = dirtyList.map(c => ({ customerId: c.id!, productId: c.productId, ...current(c) }))
      const r = await saveEntries(date, list)
      for (const c of dirtyList) drafts.delete(c.id!)
      force(x => x + 1)
      toast(`${r.saved} saved${r.locked ? `, ${r.locked} already billed (locked)` : ''}`, 'ok')
    } catch (e) { toast(errMsg(e), 'err') } finally { setSaving(false) }
  }
  const delivered = (c: Customer) => {
    const d = current(c)
    if (d.status === 'delivered') return patch(c, { status: 'pending' })
    if (d.regularMl + d.extraMl <= 0) return toast('Add a quantity first.', 'err')
    patch(c, { status: 'delivered' })
  }
  const skip = (c: Customer) => patch(c, { status: current(c).status === 'skipped' ? 'pending' : 'skipped' })

  return (
    <div>
      <PageHead title="Daily Entry" />
      <div className="entrybar">
        <div className="row">
          <button className="btn sm" aria-label="Previous day" onClick={() => setDate(addDays(date, -1))}><ChevronLeft size={20} /></button>
          <input className="in grow" type="date" value={date} max={todayISO()} onChange={e => e.target.value && setDate(e.target.value)} aria-label="Date" />
          <button className="btn sm" aria-label="Next day" disabled={date >= todayISO()} onClick={() => setDate(addDays(date, 1))}><ChevronRight size={20} /></button>
        </div>
        <div className="row" style={{ marginTop: 8 }}>
          <div className="search grow"><Search /><input className="in" type="search" placeholder="Search customer" value={q} onChange={e => setQ(e.target.value)} aria-label="Search customer" /></div>
          <button className="btn sm green" onClick={markAll} aria-label="Mark all pending as delivered"><CheckCheck size={20} />All</button>
        </div>
        <div className="chips" style={{ marginTop: 8 }}>
          {([['all', `All ${live.length}`], ['pending', `Pending ${cnt('pending')}`], ['delivered', `Delivered ${cnt('delivered')}`], ['skipped', `Skipped ${cnt('skipped')}`]] as const).map(([k, l]) => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{l}</button>)}
          <span className="chip" style={{ borderStyle: 'dashed' }}>{formatQty(litres)} total</span>
        </div>
      </div>

      <p className="sub">{dateLabel(date)}{date === todayISO() ? ' (today)' : ''}</p>
      {customers.length === 0 && <div className="card"><Empty icon={<Users />} title="No customers yet" text="Add customers first, then record deliveries here." action={<a className="btn primary" href="#/customers/new">Add customer</a>} /></div>}
      {customers.length > 0 && rows.length === 0 && <div className="card" style={{ marginTop: 10 }}><Empty icon={<Search />} title="No customers to show" text="Change the search or filter." /></div>}

      {rows.map(c => {
        const d = current(c); const { paused, locked } = stateOf(c); const u = unitOf(c); const step = UNITS[u].steps[0]; const dirty = isDirty(c)
        const off = paused || locked
        return (
          <div key={c.id} className={`ecard ${paused ? 'paused' : d.status} ${dirty ? 'dirty' : ''} ${locked ? 'locked' : ''}`}>
            <div className="row between">
              <div className="grow"><div className="t" style={{ fontWeight: 800, fontSize: 17, overflowWrap: 'anywhere' }}>{c.name}</div><div className="sub">{c.area || c.code}</div></div>
              {paused ? <span className="badge amber">Paused</span> : locked ? <span className="badge">Billed</span> : dirty ? <span className="badge amber">Unsaved</span> : savedMap.has(c.id!) ? <span className="badge green">Saved</span> : <span className="badge gray">Not entered</span>}
            </div>
            {!paused && <>
              <div className="row between wrap" style={{ marginTop: 10 }}>
                <span className="lbl">Regular</span>
                <div className="qty"><button className="round" aria-label={`Decrease regular for ${c.name}`} disabled={off || d.status === 'skipped' || d.regularMl <= 0} onClick={() => patch(c, { regularMl: Math.max(0, d.regularMl - step) })}><Minus size={20} /></button><b>{formatQty(d.regularMl, u)}</b><button className="round" aria-label={`Increase regular for ${c.name}`} disabled={off || d.status === 'skipped'} onClick={() => patch(c, { regularMl: d.regularMl + step })}><Plus size={20} /></button></div>
              </div>
              <div className="row between wrap" style={{ marginTop: 8 }}>
                <span className="lbl">Extra</span>
                <div className="qty"><button className="round" aria-label={`Decrease extra for ${c.name}`} disabled={off || d.status === 'skipped' || d.extraMl <= 0} onClick={() => patch(c, { extraMl: Math.max(0, d.extraMl - step) })}><Minus size={20} /></button><b>{formatQty(d.extraMl, u)}</b><button className="round" aria-label={`Increase extra for ${c.name}`} disabled={off || d.status === 'skipped'} onClick={() => patch(c, { extraMl: d.extraMl + step })}><Plus size={20} /></button></div>
              </div>
              <div className="row wrap" style={{ marginTop: 8 }}>{UNITS[u].steps.map(s => <button key={s} className="quick" disabled={off || d.status === 'skipped'} onClick={() => patch(c, { extraMl: d.extraMl + s })}>+{formatQty(s, u)}</button>)}</div>
              <div className="row between" style={{ marginTop: 10 }}><span className="lbl">Total</span><b className="total num">{d.status === 'skipped' ? 'Skipped' : formatQty(d.regularMl + d.extraMl, u)}</b></div>
              <div className="big-actions">
                <button className={`btn ${d.status === 'delivered' ? 'green' : ''}`} style={{ minHeight: 52 }} disabled={off} onClick={() => delivered(c)}><Check size={22} />{d.status === 'delivered' ? 'Delivered' : 'Delivered?'}</button>
                <button className="btn" style={{ minHeight: 52, background: d.status === 'skipped' ? 'var(--amber)' : undefined, color: d.status === 'skipped' ? '#fff' : undefined }} disabled={off} onClick={() => skip(c)}><SkipForward size={20} />Skip</button>
              </div>
            </>}
            {paused && <p className="sub" style={{ marginTop: 6 }}>Delivery is paused. It is not billed. Resume from the customer page.</p>}
            {locked && <p className="sub" style={{ marginTop: 6 }}>This day is already on a bill. Void the bill to change it.</p>}
          </div>
        )
      })}

      {dirtyList.length > 0 && (
        <div className="savebar"><div>
          <div className="grow"><b>{dirtyList.length} unsaved</b><div className="sub">Not stored until you save</div></div>
          <button className="btn primary" style={{ minHeight: 52 }} onClick={saveAll} disabled={saving}><Save size={20} />{saving ? 'Saving...' : 'Save all'}</button>
        </div></div>
      )}
    </div>
  )
}
