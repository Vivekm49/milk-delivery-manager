import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { ChevronLeft, ChevronRight, Check, Minus, Plus, Users, CheckCheck, X, Eye, Pencil, Phone, Undo2, UserX, MessageCircle, Save, CalendarPlus, Trash2, Milk } from 'lucide-react'
import { db, isPausedOn, resolveRate } from '../lib/db'
import { saveEntries, type EntryDraft } from '../lib/entries'
import { sortCustomers } from '../lib/customers'
import { formatQty, amountFor, UNITS, type UnitKey } from '../lib/money'
import { addDays, dateLabel, todayISO } from '../lib/dates'
import { useApp } from '../lib/appctx'
import { phoneDigits } from '../lib/money'
import { fmt, Empty, Loading, toast, errMsg, go } from '../lib/ui'
import { Avatar, Kebab, type MenuItem } from '../components/Tags'
import type { Customer, Entry as EntryRow, Product } from '../lib/types'

type Status = 'delivered' | 'skipped' | 'pending'
interface Draft { regularMl: number; extraMl: number; status: Status }
const lk = (cid: number, pid: number) => `${cid}|${pid}`

// Unsaved changes survive switching screens (but not closing the app), per date.
const keep = new Map<string, { drafts: Map<string, Draft>; added: Map<number, Set<number>> }>()
// The date you were looking at is remembered. If it was "today", it moves to the new today the next day.
let lastPick: { date: string; wasToday: boolean } | null = null
const initialDate = () => (lastPick && !lastPick.wasToday ? lastPick.date : todayISO())

export default function Entry() {
  const [date, setDateRaw] = useState(initialDate)
  const { search } = useApp()
  const [openExtra, setOpenExtra] = useState<Set<number>>(new Set())
  const [filter, setFilter] = useState<'all' | 'pending' | 'delivered' | 'skipped'>('all')
  const [group, setGroup] = useState(0)
  const [adding, setAdding] = useState<number | null>(null)
  const [, force] = useState(0)
  const [saving, setSaving] = useState(false)
  const setDate = (d: string) => { if (!d) return; lastPick = { date: d, wasToday: d === todayISO() }; setDateRaw(d); setAdding(null) }
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const groups = useLiveQuery(() => db.groups.orderBy('name').toArray(), [], [])
  const pauses = useLiveQuery(() => db.pauses.toArray(), [], [])
  const rates = useLiveQuery(() => db.rates.toArray(), [], [])
  const saved = useLiveQuery(() => db.entries.where('date').equals(date).toArray(), [date], undefined)
  const pmap = useMemo(() => new Map<number, Product>(products.map(p => [p.id!, p])), [products])
  const savedMap = useMemo(() => new Map<string, EntryRow>((saved ?? []).map(e => [lk(e.customerId, e.productId), e])), [saved])
  if (!keep.has(date)) keep.set(date, { drafts: new Map(), added: new Map() })
  const { drafts, added } = keep.get(date)!
  const today = todayISO()

  if (!customers || !saved) return <Loading />

  const eligible = sortCustomers(customers.filter(c => c.startDate <= date && (c.status !== 'inactive' || saved.some(e => e.customerId === c.id))))

  const unitOf = (pid: number) => pmap.get(pid)?.unit ?? 'L'
  const linesOf = (c: Customer): number[] => {
    const ids = [c.productId]
    for (const e of saved) if (e.customerId === c.id && !ids.includes(e.productId)) ids.push(e.productId)
    for (const p of added.get(c.id!) ?? []) if (!ids.includes(p)) ids.push(p)
    return ids
  }
  const defaultQty = (c: Customer, pid: number) => pid === c.productId ? c.dailyMl : unitOf(pid) === 'pc' ? 1000 : UNITS[unitOf(pid)].steps[0] * 4
  const current = (c: Customer, pid: number): Draft => {
    const d = drafts.get(lk(c.id!, pid))
    if (d) return d
    const s = savedMap.get(lk(c.id!, pid))
    if (s) return { regularMl: s.regularMl, extraMl: s.extraMl, status: s.status }
    return { regularMl: defaultQty(c, pid), extraMl: 0, status: 'pending' }
  }
  const isDirty = (c: Customer, pid: number) => {
    const d = drafts.get(lk(c.id!, pid))
    if (!d) return false
    const s = savedMap.get(lk(c.id!, pid))
    if (!s) return d.status !== 'pending'
    return d.status !== s.status || d.regularMl !== s.regularMl || d.extraMl !== s.extraMl
  }
  const patch = (c: Customer, pid: number, p: Partial<Draft>) => { drafts.set(lk(c.id!, pid), { ...current(c, pid), ...p }); force(n => n + 1) }
  const custDirty = (c: Customer) => linesOf(c).some(pid => isDirty(c, pid))
  const custStatus = (c: Customer): Status => {
    const st = linesOf(c).map(pid => current(c, pid).status)
    return st.includes('delivered') ? 'delivered' : st.includes('skipped') ? 'skipped' : 'pending'
  }
  const isPaused = (c: Customer) => isPausedOn(pauses, c.id!, date) && !saved.some(e => e.customerId === c.id)
  const gIds = new Set(groups.map(g => g.id))

  const rows = eligible.filter(c => {
    const t = search.trim().toLowerCase()
    if (t && !(c.name.toLowerCase().includes(t) || c.area.toLowerCase().includes(t) || c.code.toLowerCase().includes(t))) return false
    if (group === -1 ? (c.groupId != null && gIds.has(c.groupId)) : group > 0 && c.groupId !== group) return false
    if (filter !== 'all' && custStatus(c) !== filter) return false
    return true
  })
  const live = eligible.filter(c => !isPaused(c))
  const cnt = (s: Status) => live.filter(c => custStatus(c) === s).length
  const litres = live.reduce((sum, c) => sum + linesOf(c).reduce((s2, pid) => { const d = current(c, pid); return s2 + (d.status === 'delivered' && ['L', '500ml'].includes(unitOf(pid)) ? d.regularMl + d.extraMl : 0) }, 0), 0)
  const dirtyLines = eligible.flatMap(c => linesOf(c).filter(pid => isDirty(c, pid)).map(pid => ({ c, pid })))

  const markAll = () => {
    let n = 0
    for (const c of rows.filter(r => !isPaused(r))) {
      if (savedMap.get(lk(c.id!, c.productId))?.billId) continue
      const d = current(c, c.productId)
      if (d.status === 'pending' && d.regularMl + d.extraMl > 0) { drafts.set(lk(c.id!, c.productId), { ...d, status: 'delivered' }); n++ }
    }
    force(x => x + 1); toast(n ? `${n} marked delivered. Press Save all.` : 'Nothing pending to mark.')
  }
  const saveAll = async () => {
    if (saving) return
    setSaving(true)
    try {
      const list: EntryDraft[] = dirtyLines.map(({ c, pid }) => ({ customerId: c.id!, productId: pid, ...current(c, pid) }))
      const r = await saveEntries(date, list)
      for (const { c, pid } of dirtyLines) drafts.delete(lk(c.id!, pid))
      force(x => x + 1)
      toast(`${r.saved} saved${r.locked ? `, ${r.locked} already on a bill (not changed)` : ''}`, 'ok')
    } catch (e) { toast(errMsg(e), 'err') } finally { setSaving(false) }
  }
  const delivered = (c: Customer, pid: number) => {
    const d = current(c, pid)
    if (d.status === 'delivered') return patch(c, pid, { status: 'pending' })
    if (d.regularMl + d.extraMl <= 0) return toast('Add a quantity first.', 'err')
    patch(c, pid, { status: 'delivered' })
  }
  const skip = (c: Customer, pid: number) => patch(c, pid, { status: current(c, pid).status === 'skipped' ? 'pending' : 'skipped' })
  const addLine = (c: Customer, pid: number) => {
    const set = added.get(c.id!) ?? new Set<number>(); set.add(pid); added.set(c.id!, set)
    drafts.set(lk(c.id!, pid), { regularMl: defaultQty(c, pid), extraMl: 0, status: 'pending' })
    setAdding(null); force(n => n + 1)
  }
  const removeLine = (c: Customer, pid: number) => {
    if (savedMap.has(lk(c.id!, pid))) return patch(c, pid, { status: 'pending' }) // saving will remove the stored entry
    added.get(c.id!)?.delete(pid); drafts.delete(lk(c.id!, pid)); force(n => n + 1)
  }
  const clearEntry = (c: Customer) => {
    for (const pid of linesOf(c)) {
      if (savedMap.get(lk(c.id!, pid))?.billId) continue
      if (savedMap.has(lk(c.id!, pid))) patch(c, pid, { status: 'pending' })
      else { drafts.delete(lk(c.id!, pid)); if (pid !== c.productId) added.get(c.id!)?.delete(pid) }
    }
    force(n => n + 1)
  }
  const addExtra = (c: Customer, ml: number) => patch(c, c.productId, { extraMl: current(c, c.productId).extraMl + ml })


  const cardMode = (c: Customer): 'pending' | 'done' | 'absent' => {
    const st = linesOf(c).map(pid => current(c, pid).status)
    if (st.every(x => x === 'skipped')) return 'absent'
    if (st.every(x => x === 'delivered')) return 'done'
    return 'pending'
  }
  const saveCard = async (c: Customer) => {
    if (saving) return
    const list: EntryDraft[] = []
    for (const pid of linesOf(c)) {
      const d = current(c, pid)
      if (savedMap.get(lk(c.id!, pid))?.billId) continue
      if (d.status === 'pending') { if (d.regularMl + d.extraMl > 0 && !(added.get(c.id!)?.has(pid) && !savedMap.has(lk(c.id!, pid)) && !drafts.has(lk(c.id!, pid)))) list.push({ customerId: c.id!, productId: pid, ...d, status: 'delivered' }) }
      else if (isDirty(c, pid)) list.push({ customerId: c.id!, productId: pid, ...d })
    }
    if (!list.length) return toast('Add a quantity first.', 'err')
    setSaving(true)
    try {
      await saveEntries(date, list)
      for (const l of list) drafts.delete(lk(l.customerId, l.productId))
      force(x => x + 1); toast(`${c.name} saved`, 'ok')
    } catch (e) { toast(errMsg(e), 'err') } finally { setSaving(false) }
  }
  const absentCard = (c: Customer) => { for (const pid of linesOf(c)) if (!savedMap.get(lk(c.id!, pid))?.billId) patch(c, pid, { status: 'skipped' }) }
  const editCard = (c: Customer) => { for (const pid of linesOf(c)) if (!savedMap.get(lk(c.id!, pid))?.billId) patch(c, pid, { status: 'pending' }) }
  const lineAmount = (c: Customer, pid: number, d: Draft) => {
    const r = resolveRate(rates, c.id!, pid, date)
    if (!r) return null
    const m = UNITS[unitOf(pid)].milliPerUnit
    return amountFor(d.regularMl, r.ratePaise, m) + amountFor(d.extraMl, r.extraRatePaise, m)
  }
  const rateTag = (c: Customer, pid: number) => { const r = resolveRate(rates, c.id!, pid, date); return r ? `${fmt(r.ratePaise)}/${UNITS[unitOf(pid)].short}` : 'No rate' }
  const toggleExtra = (id: number) => setOpenExtra(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })
  const chipsCount = [['all', `All ${live.length}`], ['pending', `Pending ${cnt('pending')}`], ['delivered', `Done ${cnt('delivered')}`], ['skipped', `Absent ${cnt('skipped')}`]] as const

  // A plain function (not a component), so the card keeps its DOM nodes between renders and taps are never lost.
  const renderRow = (c: Customer, pid: number, mode: 'pending' | 'done' | 'absent') => {
    const d = current(c, pid); const u = unitOf(pid); const step = UNITS[u].steps[0]; const primary = pid === c.productId
    const locked = !!savedMap.get(lk(c.id!, pid))?.billId
    const showExtra = mode === 'pending' && (d.extraMl > 0 || openExtra.has(c.id!) && primary)
    const nm = pmap.get(pid)?.name ?? ''
    return (
      <div className="er" key={pid}>
        <div className="mn">{nm}<br /><small>{rateTag(c, pid)}</small></div>
        {mode === 'pending' && <div className="stepper">
          <button aria-label={`Decrease ${primary ? 'regular' : nm} for ${c.name}`} disabled={locked || d.regularMl <= 0} onClick={() => patch(c, pid, { regularMl: Math.max(0, d.regularMl - step) })}><Minus size={18} /></button>
          <b>{formatQty(d.regularMl, u)}</b>
          <button aria-label={`Increase ${primary ? 'regular' : nm} for ${c.name}`} disabled={locked} onClick={() => patch(c, pid, { regularMl: d.regularMl + step })}><Plus size={18} /></button>
        </div>}
        {mode === 'pending' && !primary && !locked && <button className="kebab" aria-label={`Remove ${nm} for ${c.name}`} onClick={() => removeLine(c, pid)}><X size={18} /></button>}
        {mode === 'done' && <><b className="res blue" style={{ marginLeft: 'auto' }}>{formatQty(d.regularMl + d.extraMl, u)}</b><b className="res" style={{ marginLeft: 0 }}>{lineAmount(c, pid, d) === null ? '' : fmt(lineAmount(c, pid, d)!)}</b>{locked && <span className="badge">Bill made</span>}</>}
        {mode === 'absent' && <span className="na">Not delivered</span>}
        {showExtra && (
          <div className="xtra">
            <span className="lbl">Extra</span>
            <div className="stepper">
              <button aria-label={`Decrease extra ${primary ? '' : nm + ' '}for ${c.name}`} disabled={locked || d.extraMl <= 0} onClick={() => patch(c, pid, { extraMl: Math.max(0, d.extraMl - step) })}><Minus size={18} /></button>
              <b>{formatQty(d.extraMl, u)}</b>
              <button aria-label={`Increase extra ${primary ? '' : nm + ' '}for ${c.name}`} disabled={locked} onClick={() => patch(c, pid, { extraMl: d.extraMl + step })}><Plus size={18} /></button>
            </div>
            {UNITS[u].steps.map(st => <button key={st} className="quick" disabled={locked} onClick={() => patch(c, pid, { extraMl: d.extraMl + st })}>+{formatQty(st, u)}</button>)}
          </div>
        )}
      </div>
    )
  }

  return (
    <div>
      <div className="dbar">
        <button className="arrow" aria-label="Previous day" onClick={() => setDate(addDays(date, -1))}><ChevronLeft size={22} /></button>
        <input type="date" value={date} max={today} onChange={e => setDate(e.target.value)} aria-label="Date" />
        <button className="arrow" aria-label="Next day" disabled={date >= today} onClick={() => setDate(addDays(date, 1))}><ChevronRight size={22} /></button>
        <button className="today" onClick={() => setDate(today)} disabled={date === today} aria-label="Go to today">Today</button>
      </div>
      <p className="sub" style={{ margin: '8px 2px 0' }}>{dateLabel(date)}{date === today ? ' (today)' : ''}</p>
      <div className="chips" style={{ marginTop: 8 }}>
        {chipsCount.map(([k, l]) => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{l}</button>)}
        <span className="chip" style={{ borderStyle: 'dashed' }}>{formatQty(litres)} total</span>
        <button className="chip" onClick={markAll} aria-label="Mark all pending as delivered" style={{ borderColor: 'var(--green)', color: 'var(--green)' }}><CheckCheck size={16} style={{ verticalAlign: -3 }} /> Mark all done</button>
      </div>
      {groups.length > 0 && (
        <div className="chips" style={{ marginTop: 6 }}>
          <button className={`chip ${group === 0 ? 'on' : ''}`} onClick={() => setGroup(0)}>All groups</button>
          {groups.map(g => <button key={g.id} className={`chip ${group === g.id ? 'on' : ''}`} onClick={() => setGroup(g.id!)}>{g.name}</button>)}
          <button className={`chip ${group === -1 ? 'on' : ''}`} onClick={() => setGroup(-1)}>No group</button>
        </div>
      )}

      {customers.length === 0 && <div className="card" style={{ marginTop: 10 }}><Empty icon={<Users />} title="No customers yet" text="Add customers first, then record deliveries here." action={<a className="btn primary" href="#/customers/new">Add customer</a>} /></div>}
      {customers.length > 0 && rows.length === 0 && <div className="card" style={{ marginTop: 10 }}><Empty icon={<Users />} title="No customers to show" text="Change the search or filter." /></div>}

      {rows.map(c => {
        const paused = isPaused(c); const dirty = custDirty(c); const mode = cardMode(c)
        const lines = linesOf(c); const free = products.filter(p => p.active && !lines.includes(p.id!))
        const phone = !!c.mobile.trim()
        const items: MenuItem[] = [
          { label: 'Extra milk', icon: <Milk size={18} />, disabled: paused || mode !== 'pending', onClick: () => toggleExtra(c.id!) },
          { label: 'Add other milk / product', icon: <CalendarPlus size={18} />, disabled: paused || free.length === 0, onClick: () => setAdding(c.id!) },
          { label: 'View details', icon: <Eye size={18} />, onClick: () => go(`customers/${c.id}`) },
          { label: 'Edit customer', icon: <Pencil size={18} />, onClick: () => go(`customers/${c.id}/edit`) },
          { label: phone ? 'Call' : 'Call (no phone number)', icon: <Phone size={18} />, disabled: !phone, onClick: () => { location.href = `tel:${c.mobile}` } },
          { label: phone ? 'WhatsApp' : 'WhatsApp (no phone number)', icon: <MessageCircle size={18} />, disabled: !phone, onClick: () => window.open(`https://wa.me/${phoneDigits(c.whatsapp || c.mobile)}`, '_blank', 'noopener') },
          { label: 'Clear entry', icon: <Trash2 size={18} />, danger: true, disabled: paused, onClick: () => clearEntry(c) }
        ]
        return (
          <div key={c.id} className={`ec ${paused ? 'paused' : mode} ${dirty ? 'dirty' : ''}`}>
            <div className="ec-h">
              <Avatar name={c.name} size={38} />
              <div className="ec-n"><b>{c.name}</b><small>{[c.area || c.code, pmap.get(c.productId)?.name].filter(Boolean).join(' · ')}</small></div>
              <div className="ec-act">
                {paused ? <span className="badge amber">Paused</span> : mode === 'done' ? <>
                  <span className="badge green"><Check size={13} />Done</span>
                  <button className="ib-btn edit" aria-label={`Edit entry of ${c.name}`} disabled={lines.every(pid => savedMap.get(lk(c.id!, pid))?.billId)} onClick={() => editCard(c)}><Pencil size={17} /></button>
                </> : mode === 'absent' ? <>
                  <span className="badge red"><UserX size={13} />Absent</span>
                  <button className="ib-btn undo" aria-label={`Undo absent of ${c.name}`} disabled={lines.every(pid => savedMap.get(lk(c.id!, pid))?.billId)} onClick={() => editCard(c)}><Undo2 size={16} />Undo</button>
                </> : null}
                <Kebab name={c.name} items={items} />
              </div>
            </div>
            {!paused && mode === 'pending' && (
              <div className="ec-bar">
                <button className="ib-btn plus" aria-label={`Add other milk for ${c.name}`} disabled={free.length === 0} onClick={() => setAdding(adding === c.id ? null : c.id!)}><Plus size={20} /></button>
                <button className="ib-btn plus wide" aria-label={`Extra milk for ${c.name}`} aria-pressed={openExtra.has(c.id!) || current(c, c.productId).extraMl > 0} onClick={() => toggleExtra(c.id!)}>Extra</button>
                <button className="ib-btn abs" aria-label={`Mark ${c.name} absent`} onClick={() => absentCard(c)}><UserX size={17} />Absent</button>
                <button className="ib-btn save" aria-label={`Save ${c.name}`} onClick={() => saveCard(c)}><Check size={17} />Save</button>
              </div>
            )}
            {paused ? <p className="sub" style={{ padding: '8px 12px 12px' }}>Delivery is paused, so nothing is charged. Resume it from the customer page.</p> : <>
              {adding === c.id && (
                <div className="er"><select className="in grow" aria-label="Choose product to add" defaultValue="" onChange={e => e.target.value && addLine(c, Number(e.target.value))}><option value="">Choose milk / product</option>{free.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select><button className="btn sm" onClick={() => setAdding(null)}>Cancel</button></div>
              )}
              {lines.map(pid => renderRow(c, pid, mode))}
            </>}
          </div>
        )
      })}

      {dirtyLines.length > 0 && (
        <div className="savebar"><div>
          <div className="grow"><b>{dirtyLines.length} unsaved</b><div className="sub">Not stored until you save</div></div>
          <button className="btn primary" style={{ minHeight: 52 }} onClick={saveAll} disabled={saving}><Save size={20} />{saving ? 'Saving...' : 'Save all'}</button>
        </div></div>
      )}
    </div>
  )
}
