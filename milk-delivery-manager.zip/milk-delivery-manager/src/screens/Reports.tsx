import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { FileDown, BarChart3 } from 'lucide-react'
import { db, getSettings, resolveRate } from '../lib/db'
import { loadMonthly } from '../lib/monthly'
import { loadProfit } from '../lib/profit'
import { allBillsReport } from '../lib/billPdf'
import { useApp } from '../lib/appctx'
import { UserX, TrendingUp, TrendingDown } from 'lucide-react'
import { buildLines, discountsInMonth } from '../lib/billing'
import { amountFor, formatQty, UNITS } from '../lib/money'
import { currentMonth, dateLabel, monthEnd, monthLabel, monthStart, todayISO } from '../lib/dates'
import { exportReportPdf, pdfMoney, type PdfReport } from '../lib/pdf'
import { fmt, Seg, Empty, Loading, toast, errMsg, Field } from '../lib/ui'

type Tab = 'daily' | 'monthly' | 'customer'

export default function Reports() {
  const [tab, setTab] = useState<Tab>('daily')
  return <div className="stack"><Seg<Tab> value={tab} onChange={setTab} options={[{ v: 'daily', l: 'Daily' }, { v: 'monthly', l: 'Monthly' }, { v: 'customer', l: 'Customers' }]} />{tab === 'daily' ? <Daily /> : tab === 'monthly' ? <Monthly /> : <CustomerReport />}</div>
}

/** Builds the PDF from the same numbers shown on screen. Repeated taps are ignored while a file is being made. */
function usePdfExport() {
  const [busy, setBusy] = useState(false)
  const run = async (build: (money: (p: number) => string, st: Awaited<ReturnType<typeof getSettings>>) => Omit<PdfReport, 'business' | 'generated' | 'currency'>) => {
    if (busy) return
    setBusy(true)
    try {
      const st = await getSettings()
      const report = build(p => pdfMoney(p, st.currency), st)
      const r = await exportReportPdf({ ...report, business: st.businessName, currency: st.currency, generated: dateLabel(todayISO()) }, todayISO())
      toast(r === 'downloaded' ? 'PDF report downloaded' : 'PDF report is ready to open or share', 'ok')
    } catch (e) { toast(errMsg(e, 'Could not create the PDF report. Please try again.'), 'err') } finally { setBusy(false) }
  }
  return { busy, run }
}
const PdfButton = ({ busy, onClick }: { busy: boolean; onClick: () => void }) => <button className="btn primary block" style={{ marginTop: 12 }} disabled={busy} onClick={onClick}><FileDown size={20} />{busy ? 'Making PDF...' : 'Download PDF report'}</button>

function Daily() {
  const [date, setDate] = useState(todayISO())
  const pdf = usePdfExport()
  const data = useLiveQuery(async () => {
    const [entries, customers, products, rates, payments] = await Promise.all([db.entries.where('date').equals(date).toArray(), db.customers.toArray(), db.products.toArray(), db.rates.toArray(), db.payments.where('date').equals(date).toArray()])
    const pmap = new Map(products.map(p => [p.id!, p]))
    const del = entries.filter(e => e.status === 'delivered')
    const lit = (e: { productId: number }) => ['L', '500ml'].includes(pmap.get(e.productId)?.unit ?? '')
    const lines = buildLines(del, rates, pmap).lines
    return { entries, customers, pmap, rates, del, litres: del.filter(lit).reduce((s, e) => s + e.regularMl + e.extraMl, 0), extra: del.filter(lit).reduce((s, e) => s + e.extraMl, 0), expected: lines.reduce((s, l) => s + l.amountPaise, 0), paid: payments.filter(p => !p.voided).reduce((s, p) => s + p.amountPaise, 0), skipped: new Set(entries.filter(e => e.status === 'skipped' && !del.some(o => o.customerId === e.customerId)).map(e => e.customerId)).size }
  }, [date], undefined)
  if (!data) return <Loading />
  const cname = new Map(data.customers.map(c => [c.id!, c.name]))
  const sorted = [...data.entries].sort((a, b) => (cname.get(a.customerId) ?? '').localeCompare(cname.get(b.customerId) ?? ''))
  const rowFor = (e: (typeof sorted)[number]) => {
    const u = data.pmap.get(e.productId)?.unit
    const r = resolveRate(data.rates, e.customerId, e.productId, e.date)
    const milli = UNITS[u ?? 'L'].milliPerUnit
    const amount = e.status === 'delivered' && r ? amountFor(e.regularMl, r.ratePaise, milli) + amountFor(e.extraMl, r.extraRatePaise, milli) : 0
    return { e, u, r, amount }
  }
  const exportPdf = () => pdf.run(money => ({
    type: 'Daily', title: 'Daily Report', period: dateLabel(date), emptyText: `No deliveries were recorded on ${dateLabel(date)}.`,
    summary: [{ label: 'Total Quantity', value: formatQty(data.litres) }, { label: 'Deliveries', value: String(new Set(data.del.map(e => e.customerId)).size) }, { label: 'Extra Milk', value: formatQty(data.extra) }, { label: 'Amount to Collect', value: money(data.expected) }, { label: 'Payments Received', value: money(data.paid) }, { label: 'Absent', value: String(data.skipped) }],
    columns: [{ header: 'Customer', weight: 4 }, { header: 'Product', weight: 2.4 }, { header: 'Regular', align: 'right', weight: 1.5 }, { header: 'Extra', align: 'right', weight: 1.5 }, { header: 'Total', align: 'right', weight: 1.5 }, { header: 'Rate', align: 'right', weight: 1.9 }, { header: 'Amount', align: 'right', weight: 2.4 }, { header: 'Status', weight: 1.8 }],
    rows: sorted.map(rowFor).map(({ e, u, r, amount }) => [cname.get(e.customerId) ?? 'Customer', data.pmap.get(e.productId)?.name ?? '', formatQty(e.regularMl, u), e.extraMl ? formatQty(e.extraMl, u) : '-', e.status === 'delivered' ? formatQty(e.regularMl + e.extraMl, u) : '-', r ? money(r.ratePaise) : '-', e.status === 'delivered' ? money(amount) : '-', e.status === 'delivered' ? 'Delivered' : 'Skipped']),
    totals: ['Total', '', '', '', formatQty(data.litres), '', money(data.expected), ''],
    note: 'Amounts use the rates that were active on this day. Absent days are not charged.'
  }))
  return (
    <div className="stack">
      <Field label="Date"><input type="date" className="in" value={date} onChange={e => e.target.value && setDate(e.target.value)} /></Field>
      <div className="grid4">
        <div className="stat"><div className="k">Total Quantity</div><div className="v num">{formatQty(data.litres)}</div></div>
        <div className="stat good"><div className="k">Deliveries</div><div className="v num">{new Set(data.del.map(e => e.customerId)).size}</div></div>
        <div className="stat"><div className="k">Extra Milk</div><div className="v num">{formatQty(data.extra)}</div></div>
        <div className="stat bad"><div className="k">Absent</div><div className="v num">{data.skipped}</div></div>
        <div className="stat"><div className="k">Amount to Collect</div><div className="v num">{fmt(data.expected)}</div></div>
        <div className="stat good"><div className="k">Payments Received</div><div className="v num">{fmt(data.paid)}</div></div>
      </div>
      <div className="card">
        {data.entries.length === 0 ? <Empty icon={<BarChart3 />} title="No entries on this day" text={`Nothing was recorded for ${dateLabel(date)}.`} /> : <>
          <div className="table-wrap"><table><thead><tr><th>Customer</th><th>Product</th><th className="r">Regular</th><th className="r">Extra</th><th>Status</th></tr></thead><tbody>{sorted.map(e => <tr key={e.id}><td>{cname.get(e.customerId)}</td><td>{data.pmap.get(e.productId)?.name}</td><td className="r">{formatQty(e.regularMl, data.pmap.get(e.productId)?.unit)}</td><td className="r">{e.extraMl ? formatQty(e.extraMl, data.pmap.get(e.productId)?.unit) : '-'}</td><td>{e.status === 'delivered' ? 'Delivered' : 'Skipped'}</td></tr>)}</tbody></table></div></>}
        <PdfButton busy={pdf.busy} onClick={exportPdf} />
      </div>
    </div>
  )
}

function Monthly() {
  const { month } = useApp()
  const pdf = usePdfExport()
  const data = useLiveQuery(async () => ({ m: await loadMonthly(month), p: await loadProfit(month) }), [month], undefined)
  if (!data) return <Loading />
  const { m, p } = data
  const t = m.totals
  const hasSales = p.rows.length > 0
  const allBuy = hasSales && p.missingBuy.length === 0
  const perUnit = (r: (typeof p.rows)[number]) => (r.perUnit === null ? '-' : fmt(r.perUnit) + '/' + UNITS[r.unit].short)
  const exportPdf = () => pdf.run(money => ({
    type: 'Monthly', title: 'Monthly Report', period: monthLabel(month), emptyText: `No deliveries were recorded in ${monthLabel(month)}.`,
    summary: [{ label: 'Total Quantity', value: t.quantity }, { label: 'Monthly Amount', value: money(t.amountPaise) }, { label: 'Payments Received', value: money(t.collectedPaise) }, { label: 'Payment Pending (all customers)', value: money(t.pendingPaise) }, { label: 'Absent days', value: `${t.absentDays} (${t.absentCustomers} customers)` }, ...(allBuy ? [{ label: p.net >= 0 ? 'Net Profit' : 'Net Loss', value: money(Math.abs(p.net)) }] : [])],
    columns: [{ header: 'Product', weight: 3 }, { header: 'Total Quantity', align: 'right', weight: 2 }, { header: 'Amount', align: 'right', weight: 2.2 }, ...(allBuy ? [{ header: 'Cost', align: 'right' as const, weight: 2.2 }, { header: 'Profit', align: 'right' as const, weight: 2.2 }] : [])],
    rows: p.rows.map(r => [r.name, formatQty(r.qtyMilli, r.unit), money(r.revenue), ...(allBuy ? [money(r.cost), money(r.profit)] : [])]),
    totals: ['Total', '', money(p.revenue), ...(allBuy ? [money(p.cost), money(p.revenue - p.cost)] : [])],
    note: [p.discounts ? `Discounts of ${money(p.discounts)} given on bills are subtracted from the Monthly Amount.` : '', !allBuy && hasSales ? 'Profit is not shown because some milk has no buy rate.' : ''].filter(Boolean).join(' ') || undefined
  }))
  return (
    <div className="stack">
      <div className="grid4">
        <div className="stat"><div className="k">Total Quantity</div><div className="v num">{t.quantity}</div></div>
        <div className="stat"><div className="k">Monthly Amount</div><div className="v num">{fmt(t.amountPaise)}</div></div>
        <div className="stat good"><div className="k">Payments Received</div><div className="v num">{fmt(t.collectedPaise)}</div></div>
        <div className="stat bad"><div className="k">Payment Pending</div><div className="v num">{fmt(t.pendingPaise)}</div></div>
      </div>
      {hasSales && (
        <div className={`profit ${allBuy && p.net < 0 ? 'loss' : ''}`}>
          {allBuy && p.net < 0 ? <TrendingDown size={26} /> : <TrendingUp size={26} />}
          <div><b>{allBuy ? (p.net >= 0 ? 'Net Profit' : 'Net Loss') : 'Profit not known yet'}</b><div className="sub" style={{ color: 'inherit', opacity: .8 }}>{allBuy ? `Cost ${fmt(p.cost)}` : `Set the buy rate for ${p.missingBuy.join(', ')} in Product Rates`}</div></div>
          {allBuy && <span className="big num">{fmt(Math.abs(p.net))}</span>}
        </div>
      )}
      <div className="card">
        <h2 className="h2">Milk-wise ({monthLabel(month)})</h2>
        {!hasSales ? <Empty icon={<BarChart3 />} title="No sales this month" text="Delivered entries will show here." /> :
          <div className="table-wrap" style={{ marginTop: 8 }}><table><thead><tr><th>Milk</th><th className="r">Quantity</th><th className="r">Sold</th><th className="r">Profit</th></tr></thead><tbody>
            {p.rows.map(r => <tr key={r.productId}><td>{r.name}<div className="sub" style={{ fontSize: 11.5 }}>{r.hasBuy ? `${perUnit(r)} profit` : <span className="badge amber">No buy rate</span>}</div></td><td className="r">{formatQty(r.qtyMilli, r.unit)}</td><td className="r">{fmt(r.revenue)}</td><td className="r" style={{ fontWeight: 800, color: !r.hasBuy ? undefined : r.profit >= 0 ? 'var(--green)' : 'var(--red)' }}>{r.hasBuy ? fmt(r.profit) : '-'}</td></tr>)}
          </tbody></table></div>}
        <PdfButton busy={pdf.busy} onClick={exportPdf} />
      </div>
      <div className={`card ${t.absentDays ? '' : ''}`}>
        <div className="row"><span className="ib red" style={{ width: 40, height: 40, borderRadius: 12, display: 'grid', placeItems: 'center' }}><UserX size={20} /></span><div><div className="h2">Absent days this month: {t.absentDays}</div><div className="sub">{t.absentCustomers} customer{t.absentCustomers === 1 ? '' : 's'} · not charged</div></div></div>
        {m.rows.filter(r => r.absent > 0).sort((a, b) => b.absent - a.absent).slice(0, 8).map(r => <div className="kv" key={r.customer.id}><span>{r.customer.name}</span><span className="num" style={{ color: 'var(--red)' }}>{r.absent} day{r.absent === 1 ? '' : 's'}</span></div>)}
      </div>
    </div>
  )
}

function CustomerReport() {
  const { month } = useApp()
  const pdf = usePdfExport()
  const data = useLiveQuery(() => loadMonthly(month), [month], undefined)
  if (!data) return <Loading />
  const rows = data.rows.filter(r => r.amountPaise > 0 || r.paidThisMonth > 0 || r.owed !== 0 || r.absent > 0)
  const exportPdf = () => pdf.run((_money, st) => ({ ...allBillsReport(data, st.businessName, st.currency), type: 'Customer' as const, title: 'Customer Report' }))
  return (
    <div className="stack">
      <div className="card">
        {rows.length === 0 ? <Empty icon={<BarChart3 />} title="No customer activity" text="No deliveries, payments or pending amounts for this month." /> : <>
          <div className="table-wrap"><table><thead><tr><th>Customer</th><th className="r">Total Quantity</th><th className="r">Absent</th><th className="r">Monthly Amount</th><th className="r">Paid</th><th className="r">Payment Pending</th></tr></thead><tbody>
            {rows.map(r => <tr key={r.customer.id}><td><a href={`#/customers/${r.customer.id}`}>{r.customer.name}</a></td><td className="r">{r.qtyText}</td><td className="r" style={{ color: r.absent ? 'var(--red)' : undefined }}>{r.absent}</td><td className="r">{fmt(r.amountPaise)}</td><td className="r">{fmt(r.paidThisMonth)}</td><td className="r" style={{ color: r.owed > 0 ? 'var(--red)' : undefined, fontWeight: 700 }}>{fmt(Math.max(0, r.owed))}</td></tr>)}
          </tbody></table></div>
          <PdfButton busy={pdf.busy} onClick={exportPdf} />
        </>}
      </div>
    </div>
  )
}
