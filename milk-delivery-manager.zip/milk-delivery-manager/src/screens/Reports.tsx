import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Download, BarChart3 } from 'lucide-react'
import { db, balanceOf, getSettings } from '../lib/db'
import { buildLines } from '../lib/billing'
import { formatQty, UNITS } from '../lib/money'
import { addDays, currentMonth, dateLabel, monthEnd, monthLabel, monthStart, todayISO } from '../lib/dates'
import { saveTextFile, toCSV } from '../lib/files'
import { fmt, PageHead, Seg, MonthNav, Empty, Loading, toast, errMsg, Field } from '../lib/ui'

type Tab = 'daily' | 'monthly' | 'customer'

export default function Reports() {
  const [tab, setTab] = useState<Tab>('daily')
  return <div className="stack"><PageHead title="Reports" /><Seg<Tab> value={tab} onChange={setTab} options={[{ v: 'daily', l: 'Daily' }, { v: 'monthly', l: 'Monthly' }, { v: 'customer', l: 'Customer' }]} />{tab === 'daily' ? <Daily /> : tab === 'monthly' ? <Monthly /> : <CustomerReport />}</div>
}

async function exportCsv(name: string, rows: (string | number)[][]) {
  try { const r = await saveTextFile(name, toCSV(rows), 'text/csv'); toast(r === 'downloaded' ? 'CSV downloaded' : 'CSV ready to save or share', 'ok') } catch (e) { toast(errMsg(e, 'Could not export the file.'), 'err') }
}
const rupees = (p: number) => (p / 100).toFixed(2)

function Daily() {
  const [date, setDate] = useState(todayISO())
  const data = useLiveQuery(async () => {
    const [entries, customers, products, rates, payments] = await Promise.all([db.entries.where('date').equals(date).toArray(), db.customers.toArray(), db.products.toArray(), db.rates.toArray(), db.payments.where('date').equals(date).toArray()])
    const pmap = new Map(products.map(p => [p.id!, p]))
    const del = entries.filter(e => e.status === 'delivered')
    const lit = (e: { productId: number }) => ['L', '500ml'].includes(pmap.get(e.productId)?.unit ?? '')
    const lines = buildLines(del, rates, pmap).lines
    return { entries, customers, pmap, del, rates, litres: del.filter(lit).reduce((s, e) => s + e.regularMl + e.extraMl, 0), extra: del.filter(lit).reduce((s, e) => s + e.extraMl, 0), expected: lines.reduce((s, l) => s + l.amountPaise, 0), paid: payments.filter(p => !p.voided).reduce((s, p) => s + p.amountPaise, 0), skipped: entries.filter(e => e.status === 'skipped').length }
  }, [date], undefined)
  if (!data) return <Loading />
  const cname = new Map(data.customers.map(c => [c.id!, c.name]))
  const rows = [['Customer', 'Product', 'Regular', 'Extra', 'Status'], ...data.entries.map(e => [cname.get(e.customerId) ?? '', data.pmap.get(e.productId)?.name ?? '', formatQty(e.regularMl, data.pmap.get(e.productId)?.unit), formatQty(e.extraMl, data.pmap.get(e.productId)?.unit), e.status])]
  return (
    <div className="stack">
      <Field label="Date"><input type="date" className="in" value={date} onChange={e => e.target.value && setDate(e.target.value)} /></Field>
      <div className="grid4">
        <div className="stat"><div className="k">Total litres</div><div className="v num">{formatQty(data.litres)}</div></div>
        <div className="stat good"><div className="k">Deliveries</div><div className="v num">{data.del.length}</div></div>
        <div className="stat"><div className="k">Extra milk</div><div className="v num">{formatQty(data.extra)}</div></div>
        <div className="stat warn"><div className="k">Skipped</div><div className="v num">{data.skipped}</div></div>
        <div className="stat"><div className="k">Expected collection</div><div className="v num">{fmt(data.expected)}</div></div>
        <div className="stat good"><div className="k">Payments received</div><div className="v num">{fmt(data.paid)}</div></div>
      </div>
      <div className="card">
        {data.entries.length === 0 ? <Empty icon={<BarChart3 />} title="No entries on this day" text={`Nothing was recorded for ${dateLabel(date)}.`} /> : <>
          <div className="table-wrap"><table><thead><tr>{rows[0].map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{rows.slice(1).map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody></table></div>
          <button className="btn block" style={{ marginTop: 10 }} onClick={() => exportCsv(`daily-${date}.csv`, rows)}><Download size={20} />Export CSV</button></>}
      </div>
    </div>
  )
}

function Monthly() {
  const [month, setMonth] = useState(currentMonth())
  const data = useLiveQuery(async () => {
    const [entries, products, rates, payments, customers, bills] = await Promise.all([db.entries.where('date').between(monthStart(month), monthEnd(month), true, true).toArray(), db.products.toArray(), db.rates.toArray(), db.payments.toArray(), db.customers.toArray(), db.bills.toArray()])
    const pmap = new Map(products.map(p => [p.id!, p]))
    const del = entries.filter(e => e.status === 'delivered')
    const lines = buildLines(del, rates, pmap).lines
    const byProduct = new Map<number, { qty: number; amount: number }>()
    for (const l of lines) { const x = byProduct.get(l.productId) ?? { qty: 0, amount: 0 }; x.qty += l.qtyMilli; x.amount += l.amountPaise; byProduct.set(l.productId, x) }
    const paid = payments.filter(p => !p.voided && p.date.slice(0, 7) === month).reduce((s, p) => s + p.amountPaise, 0)
    const outstanding = customers.reduce((s, c) => s + Math.max(0, balanceOf(c, bills, payments)), 0)
    return { pmap, byProduct, sales: lines.reduce((s, l) => s + l.amountPaise, 0), paid, outstanding, active: customers.filter(c => c.status === 'active').length, delivered: del.length, litres: del.filter(e => ['L', '500ml'].includes(pmap.get(e.productId)?.unit ?? '')).reduce((s, e) => s + e.regularMl + e.extraMl, 0) }
  }, [month], undefined)
  if (!data) return <Loading />
  const rows: (string | number)[][] = [['Product', 'Quantity', 'Amount'], ...[...data.byProduct].map(([id, v]) => [data.pmap.get(id)?.name ?? '', formatQty(v.qty, data.pmap.get(id)?.unit), rupees(v.amount)]), ['Total sales', '', rupees(data.sales)], ['Payments received', '', rupees(data.paid)], ['Outstanding (all time)', '', rupees(data.outstanding)]]
  return (
    <div className="stack">
      <MonthNav month={month} onChange={setMonth} />
      <div className="grid4">
        <div className="stat"><div className="k">Total quantity (litres)</div><div className="v num">{formatQty(data.litres)}</div></div>
        <div className="stat"><div className="k">Total sales</div><div className="v num">{fmt(data.sales)}</div></div>
        <div className="stat good"><div className="k">Payments</div><div className="v num">{fmt(data.paid)}</div></div>
        <div className="stat bad"><div className="k">Outstanding</div><div className="v num">{fmt(data.outstanding)}</div></div>
        <div className="stat"><div className="k">Active customers</div><div className="v num">{data.active}</div></div>
        <div className="stat"><div className="k">Delivered entries</div><div className="v num">{data.delivered}</div></div>
      </div>
      <div className="card">
        <h2 className="h2">Product-wise ({monthLabel(month)})</h2>
        {data.byProduct.size === 0 ? <Empty icon={<BarChart3 />} title="No sales this month" text="Delivered entries will show here." /> : <>
          <div className="table-wrap" style={{ marginTop: 8 }}><table><thead><tr><th>Product</th><th className="r">Quantity</th><th className="r">Sales</th></tr></thead><tbody>{[...data.byProduct].map(([id, v]) => <tr key={id}><td>{data.pmap.get(id)?.name}</td><td className="r">{formatQty(v.qty, data.pmap.get(id)?.unit)}</td><td className="r">{fmt(v.amount)}</td></tr>)}</tbody></table></div>
          <button className="btn block" style={{ marginTop: 10 }} onClick={() => exportCsv(`monthly-${month}.csv`, rows)}><Download size={20} />Export CSV</button></>}
      </div>
    </div>
  )
}

function CustomerReport() {
  const [month, setMonth] = useState(currentMonth())
  const data = useLiveQuery(async () => {
    const [customers, entries, products, rates, bills, payments] = await Promise.all([db.customers.toArray(), db.entries.where('date').between(monthStart(month), monthEnd(month), true, true).toArray(), db.products.toArray(), db.rates.toArray(), db.bills.toArray(), db.payments.toArray()])
    const pmap = new Map(products.map(p => [p.id!, p]))
    const rows = customers.map(c => {
      const mine = entries.filter(e => e.customerId === c.id && e.status === 'delivered')
      const lines = buildLines(mine, rates, pmap).lines
      return { c, qty: mine.reduce((s, e) => s + e.regularMl + e.extraMl, 0), unit: pmap.get(c.productId)?.unit ?? 'L', bill: lines.reduce((s, l) => s + l.amountPaise, 0), paid: payments.filter(p => p.customerId === c.id && !p.voided && p.date.slice(0, 7) === month).reduce((s, p) => s + p.amountPaise, 0), bal: balanceOf(c, bills, payments) }
    }).filter(r => r.qty > 0 || r.paid > 0 || r.bal !== 0).sort((a, b) => a.c.name.localeCompare(b.c.name))
    return rows
  }, [month], undefined)
  if (!data) return <Loading />
  const csv: (string | number)[][] = [['Customer', 'Quantity', 'Monthly bill', 'Paid this month', 'Balance'], ...data.map(r => [r.c.name, formatQty(r.qty, r.unit), rupees(r.bill), rupees(r.paid), rupees(r.bal)])]
  return (
    <div className="stack">
      <MonthNav month={month} onChange={setMonth} />
      <div className="card">
        {data.length === 0 ? <Empty icon={<BarChart3 />} title="No customer activity" text="No deliveries, payments or balances for this month." /> : <>
          <div className="table-wrap"><table><thead><tr><th>Customer</th><th className="r">Quantity</th><th className="r">Bill</th><th className="r">Paid</th><th className="r">Balance</th></tr></thead><tbody>{data.map(r => <tr key={r.c.id}><td><a href={`#/customers/${r.c.id}`}>{r.c.name}</a></td><td className="r">{formatQty(r.qty, r.unit)}</td><td className="r">{fmt(r.bill)}</td><td className="r">{fmt(r.paid)}</td><td className="r" style={{ color: r.bal > 0 ? 'var(--red)' : undefined, fontWeight: 700 }}>{fmt(r.bal)}</td></tr>)}</tbody></table></div>
          <button className="btn block" style={{ marginTop: 10 }} onClick={() => exportCsv(`customers-${month}.csv`, csv)}><Download size={20} />Export CSV</button></>}
      </div>
    </div>
  )
}
export { addDays, getSettings, UNITS }
