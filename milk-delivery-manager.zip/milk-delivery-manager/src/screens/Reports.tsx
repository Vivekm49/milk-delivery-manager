import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { FileDown, BarChart3 } from 'lucide-react'
import { db, balanceOf, getSettings, resolveRate } from '../lib/db'
import { buildLines, discountsInMonth } from '../lib/billing'
import { amountFor, formatQty, UNITS } from '../lib/money'
import { currentMonth, dateLabel, monthEnd, monthLabel, monthStart, todayISO } from '../lib/dates'
import { exportReportPdf, pdfMoney, type PdfReport } from '../lib/pdf'
import { fmt, PageHead, Seg, MonthNav, Empty, Loading, toast, errMsg, Field } from '../lib/ui'

type Tab = 'daily' | 'monthly' | 'customer'

export default function Reports() {
  const [tab, setTab] = useState<Tab>('daily')
  return <div className="stack"><PageHead title="Reports" /><Seg<Tab> value={tab} onChange={setTab} options={[{ v: 'daily', l: 'Daily' }, { v: 'monthly', l: 'Monthly' }, { v: 'customer', l: 'Customers' }]} />{tab === 'daily' ? <Daily /> : tab === 'monthly' ? <Monthly /> : <CustomerReport />}</div>
}

/** Builds the PDF from the same numbers shown on screen. Repeated taps are ignored while a file is being made. */
function usePdfExport() {
  const [busy, setBusy] = useState(false)
  const run = async (build: (money: (p: number) => string) => Omit<PdfReport, 'business' | 'generated' | 'currency'>) => {
    if (busy) return
    setBusy(true)
    try {
      const st = await getSettings()
      const report = build(p => pdfMoney(p, st.currency))
      const r = await exportReportPdf({ ...report, business: st.businessName, currency: st.currency, generated: dateLabel(todayISO()) }, todayISO())
      toast(r === 'downloaded' ? 'PDF report downloaded' : 'PDF report is ready to open or share', 'ok')
    } catch (e) { toast(errMsg(e, 'Could not create the PDF report. Please try again.'), 'err') } finally { setBusy(false) }
  }
  return { busy, run }
}
const PdfButton = ({ busy, onClick }: { busy: boolean; onClick: () => void }) => <button className="btn primary block" style={{ marginTop: 12 }} disabled={busy} onClick={onClick}><FileDown size={20} />{busy ? 'Making PDF...' : 'Download PDF report'}</button>

function Daily() {
  const [date, setDate] = useState(todayISO())
  const pdf = usePdfExport()
  const data = useLiveQuery(async () => {
    const [entries, customers, products, rates, payments] = await Promise.all([db.entries.where('date').equals(date).toArray(), db.customers.toArray(), db.products.toArray(), db.rates.toArray(), db.payments.where('date').equals(date).toArray()])
    const pmap = new Map(products.map(p => [p.id!, p]))
    const del = entries.filter(e => e.status === 'delivered')
    const lit = (e: { productId: number }) => ['L', '500ml'].includes(pmap.get(e.productId)?.unit ?? '')
    const lines = buildLines(del, rates, pmap).lines
    return { entries, customers, pmap, rates, del, litres: del.filter(lit).reduce((s, e) => s + e.regularMl + e.extraMl, 0), extra: del.filter(lit).reduce((s, e) => s + e.extraMl, 0), expected: lines.reduce((s, l) => s + l.amountPaise, 0), paid: payments.filter(p => !p.voided).reduce((s, p) => s + p.amountPaise, 0), skipped: new Set(entries.filter(e => e.status === 'skipped' && !del.some(o => o.customerId === e.customerId)).map(e => e.customerId)).size }
  }, [date], undefined)
  if (!data) return <Loading />
  const cname = new Map(data.customers.map(c => [c.id!, c.name]))
  const sorted = [...data.entries].sort((a, b) => (cname.get(a.customerId) ?? '').localeCompare(cname.get(b.customerId) ?? ''))
  const rowFor = (e: (typeof sorted)[number]) => {
    const u = data.pmap.get(e.productId)?.unit
    const r = resolveRate(data.rates, e.customerId, e.productId, e.date)
    const milli = UNITS[u ?? 'L'].milliPerUnit
    const amount = e.status === 'delivered' && r ? amountFor(e.regularMl, r.ratePaise, milli) + amountFor(e.extraMl, r.extraRatePaise, milli) : 0
    return { e, u, r, amount }
  }
  const exportPdf = () => pdf.run(money => ({
    type: 'Daily', title: 'Daily Report', period: dateLabel(date), emptyText: `No deliveries were recorded on ${dateLabel(date)}.`,
    summary: [{ label: 'Total Quantity', value: formatQty(data.litres) }, { label: 'Deliveries', value: String(new Set(data.del.map(e => e.customerId)).size) }, { label: 'Extra Milk', value: formatQty(data.extra) }, { label: 'Amount to Collect', value: money(data.expected) }, { label: 'Payments Received', value: money(data.paid) }, { label: 'Skipped', value: String(data.skipped) }],
    columns: [{ header: 'Customer', weight: 4 }, { header: 'Product', weight: 2.4 }, { header: 'Regular', align: 'right', weight: 1.5 }, { header: 'Extra', align: 'right', weight: 1.5 }, { header: 'Total', align: 'right', weight: 1.5 }, { header: 'Rate', align: 'right', weight: 1.9 }, { header: 'Amount', align: 'right', weight: 2.4 }, { header: 'Status', weight: 1.8 }],
    rows: sorted.map(rowFor).map(({ e, u, r, amount }) => [cname.get(e.customerId) ?? 'Customer', data.pmap.get(e.productId)?.name ?? '', formatQty(e.regularMl, u), e.extraMl ? formatQty(e.extraMl, u) : '-', e.status === 'delivered' ? formatQty(e.regularMl + e.extraMl, u) : '-', r ? money(r.ratePaise) : '-', e.status === 'delivered' ? money(amount) : '-', e.status === 'delivered' ? 'Delivered' : 'Skipped']),
    totals: ['Total', '', '', '', formatQty(data.litres), '', money(data.expected), ''],
    note: 'Amounts use the rates that were active on this day. Skipped deliveries are not charged.'
  }))
  return (
    <div className="stack">
      <Field label="Date"><input type="date" className="in" value={date} onChange={e => e.target.value && setDate(e.target.value)} /></Field>
      <div className="grid4">
        <div className="stat"><div className="k">Total Quantity</div><div className="v num">{formatQty(data.litres)}</div></div>
        <div className="stat good"><div className="k">Deliveries</div><div className="v num">{new Set(data.del.map(e => e.customerId)).size}</div></div>
        <div className="stat"><div className="k">Extra Milk</div><div className="v num">{formatQty(data.extra)}</div></div>
        <div className="stat warn"><div className="k">Skipped</div><div className="v num">{data.skipped}</div></div>
        <div className="stat"><div className="k">Amount to Collect</div><div className="v num">{fmt(data.expected)}</div></div>
        <div className="stat good"><div className="k">Payments Received</div><div className="v num">{fmt(data.paid)}</div></div>
      </div>
      <div className="card">
        {data.entries.length === 0 ? <Empty icon={<BarChart3 />} title="No entries on this day" text={`Nothing was recorded for ${dateLabel(date)}.`} /> : <>
          <div className="table-wrap"><table><thead><tr><th>Customer</th><th>Product</th><th className="r">Regular</th><th className="r">Extra</th><th>Status</th></tr></thead><tbody>{sorted.map(e => <tr key={e.id}><td>{cname.get(e.customerId)}</td><td>{data.pmap.get(e.productId)?.name}</td><td className="r">{formatQty(e.regularMl, data.pmap.get(e.productId)?.unit)}</td><td className="r">{e.extraMl ? formatQty(e.extraMl, data.pmap.get(e.productId)?.unit) : '-'}</td><td>{e.status === 'delivered' ? 'Delivered' : 'Skipped'}</td></tr>)}</tbody></table></div></>}
        <PdfButton busy={pdf.busy} onClick={exportPdf} />
      </div>
    </div>
  )
}

function Monthly() {
  const [month, setMonth] = useState(currentMonth())
  const pdf = usePdfExport()
  const data = useLiveQuery(async () => {
    const [entries, products, rates, payments, customers, bills] = await Promise.all([db.entries.where('date').between(monthStart(month), monthEnd(month), true, true).toArray(), db.products.toArray(), db.rates.toArray(), db.payments.toArray(), db.customers.toArray(), db.bills.toArray()])
    const pmap = new Map(products.map(p => [p.id!, p]))
    const del = entries.filter(e => e.status === 'delivered')
    const lines = buildLines(del, rates, pmap).lines
    const byProduct = new Map<number, { qty: number; amount: number }>()
    for (const l of lines) { const x = byProduct.get(l.productId) ?? { qty: 0, amount: 0 }; x.qty += l.qtyMilli; x.amount += l.amountPaise; byProduct.set(l.productId, x) }
    const discounts = discountsInMonth(bills, month)
    const paid = payments.filter(p => !p.voided && p.date.slice(0, 7) === month).reduce((s, p) => s + p.amountPaise, 0)
    const pending = customers.reduce((s, c) => s + Math.max(0, balanceOf(c, bills, payments)), 0)
    const gross = lines.reduce((s, l) => s + l.amountPaise, 0)
    return { pmap, byProduct, gross, discounts, sales: Math.max(0, gross - discounts), paid, pending, active: customers.filter(c => c.status === 'active').length, delivered: new Set(del.map(e => `${e.customerId}|${e.date}`)).size, litres: del.filter(e => ['L', '500ml'].includes(pmap.get(e.productId)?.unit ?? '')).reduce((s, e) => s + e.regularMl + e.extraMl, 0) }
  }, [month], undefined)
  if (!data) return <Loading />
  const exportPdf = () => pdf.run(money => ({
    type: 'Monthly', title: 'Monthly Report', period: monthLabel(month), emptyText: `No deliveries were recorded in ${monthLabel(month)}.`,
    summary: [{ label: 'Total Quantity', value: formatQty(data.litres) }, { label: 'Monthly Amount', value: money(data.sales) }, { label: 'Payments Received', value: money(data.paid) }, { label: 'Payment Pending (all customers)', value: money(data.pending) }, { label: 'Active Customers', value: String(data.active) }, { label: 'Delivery Days', value: String(data.delivered) }],
    columns: [{ header: 'Product', weight: 4 }, { header: 'Total Quantity', align: 'right', weight: 2.5 }, { header: 'Amount', align: 'right', weight: 2.5 }],
    rows: [...data.byProduct].map(([id, v]) => [data.pmap.get(id)?.name ?? '', formatQty(v.qty, data.pmap.get(id)?.unit), money(v.amount)]),
    totals: ['Monthly Amount' + (data.discounts ? ' (after discounts)' : ''), '', money(data.sales)],
    note: data.discounts ? `Discounts of ${money(data.discounts)} given on bills this month are already subtracted from Total Sales.` : undefined
  }))
  return (
    <div className="stack">
      <MonthNav month={month} onChange={setMonth} />
      <div className="grid4">
        <div className="stat"><div className="k">Total Quantity</div><div className="v num">{formatQty(data.litres)}</div></div>
        <div className="stat"><div className="k">Monthly Amount</div><div className="v num">{fmt(data.sales)}</div></div>
        <div className="stat good"><div className="k">Payments Received</div><div className="v num">{fmt(data.paid)}</div></div>
        <div className="stat bad"><div className="k">Payment Pending</div><div className="v num">{fmt(data.pending)}</div></div>
        <div className="stat"><div className="k">Active Customers</div><div className="v num">{data.active}</div></div>
        <div className="stat"><div className="k">Delivery Days</div><div className="v num">{data.delivered}</div></div>
      </div>
      <div className="card">
        <h2 className="h2">Product-wise ({monthLabel(month)})</h2>
        {data.byProduct.size === 0 ? <Empty icon={<BarChart3 />} title="No sales this month" text="Delivered entries will show here." /> :
          <div className="table-wrap" style={{ marginTop: 8 }}><table><thead><tr><th>Product</th><th className="r">Total Quantity</th><th className="r">Amount</th></tr></thead><tbody>{[...data.byProduct].map(([id, v]) => <tr key={id}><td>{data.pmap.get(id)?.name}</td><td className="r">{formatQty(v.qty, data.pmap.get(id)?.unit)}</td><td className="r">{fmt(v.amount)}</td></tr>)}</tbody></table></div>}
        <PdfButton busy={pdf.busy} onClick={exportPdf} />
      </div>
    </div>
  )
}

function CustomerReport() {
  const [month, setMonth] = useState(currentMonth())
  const pdf = usePdfExport()
  const data = useLiveQuery(async () => {
    const [customers, entries, products, rates, bills, payments] = await Promise.all([db.customers.toArray(), db.entries.where('date').between(monthStart(month), monthEnd(month), true, true).toArray(), db.products.toArray(), db.rates.toArray(), db.bills.toArray(), db.payments.toArray()])
    const pmap = new Map(products.map(p => [p.id!, p]))
    return customers.map(c => {
      const mine = entries.filter(e => e.customerId === c.id && e.status === 'delivered')
      const lines = buildLines(mine, rates, pmap).lines
      const gross = lines.reduce((s, l) => s + l.amountPaise, 0)
      return { c, qty: mine.reduce((s, e) => s + e.regularMl + e.extraMl, 0), unit: pmap.get(c.productId)?.unit ?? 'L', bill: Math.max(0, gross - discountsInMonth(bills, month, c.id)), paid: payments.filter(p => p.customerId === c.id && !p.voided && p.date.slice(0, 7) === month).reduce((s, p) => s + p.amountPaise, 0), bal: balanceOf(c, bills, payments) }
    }).filter(r => r.qty > 0 || r.paid > 0 || r.bal !== 0).sort((a, b) => a.c.name.localeCompare(b.c.name))
  }, [month], undefined)
  if (!data) return <Loading />
  const sum = (f: (r: NonNullable<typeof data>[number]) => number) => data.reduce((s, r) => s + f(r), 0)
  const exportPdf = () => pdf.run(money => ({
    type: 'Customer', title: 'Customer Report', period: monthLabel(month), emptyText: `No customer activity in ${monthLabel(month)}.`,
    summary: [{ label: 'Customers', value: String(data.length) }, { label: 'Monthly Amount', value: money(sum(r => r.bill)) }, { label: 'Paid This Month', value: money(sum(r => r.paid)) }, { label: 'Payment Pending', value: money(sum(r => Math.max(0, r.bal))) }],
    columns: [{ header: 'Customer', weight: 3.4 }, { header: 'Total Quantity', align: 'right', weight: 2 }, { header: 'Monthly Amount', align: 'right', weight: 2.3 }, { header: 'Paid This Month', align: 'right', weight: 2.3 }, { header: 'Amount Pending', align: 'right', weight: 2.3 }, { header: 'Status', weight: 2 }],
    rows: data.map(r => [r.c.name, formatQty(r.qty, r.unit), money(r.bill), money(r.paid), money(r.bal), r.bal > 0 ? 'Payment Pending' : r.bal < 0 ? 'Paid in advance' : 'Paid']),
    totals: ['Total', '', money(sum(r => r.bill)), money(sum(r => r.paid)), money(sum(r => r.bal)), ''],
    note: 'Amount Pending is the full amount the customer still owes, including earlier months.'
  }))
  return (
    <div className="stack">
      <MonthNav month={month} onChange={setMonth} />
      <div className="card">
        {data.length === 0 ? <Empty icon={<BarChart3 />} title="No customer activity" text="No deliveries, payments or pending amounts for this month." /> :
          <div className="table-wrap"><table><thead><tr><th>Customer</th><th className="r">Total Quantity</th><th className="r">Monthly Amount</th><th className="r">Paid</th><th className="r">Amount Pending</th></tr></thead><tbody>{data.map(r => <tr key={r.c.id}><td><a href={`#/customers/${r.c.id}`}>{r.c.name}</a></td><td className="r">{formatQty(r.qty, r.unit)}</td><td className="r">{fmt(r.bill)}</td><td className="r">{fmt(r.paid)}</td><td className="r" style={{ color: r.bal > 0 ? 'var(--red)' : undefined, fontWeight: 700 }}>{fmt(r.bal)}</td></tr>)}</tbody></table></div>}
        <PdfButton busy={pdf.busy} onClick={exportPdf} />
      </div>
    </div>
  )
}
