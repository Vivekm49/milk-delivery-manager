import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Phone, MessageCircle, Wallet, CircleCheck } from 'lucide-react'
import { db } from '../lib/db'
import { loadOwed, payStatus } from '../lib/owed'
import { buildContext, renderTemplate, messageLink, logOpened, hasPhone } from '../lib/messages'
import { currentMonth } from '../lib/dates'
import { useApp } from '../lib/appctx'
import { fmt, Loading, Empty, toast, errMsg } from '../lib/ui'
import { Avatar, PayTag } from '../components/Tags'
import type { Customer } from '../lib/types'

/** Everyone who still owes money, biggest amount first, with one-tap reminders. */
export default function PaymentPending() {
  const { search } = useApp()
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const owed = useLiveQuery(() => loadOwed(), [], undefined)
  const paid = useLiveQuery(async () => {
    const m = currentMonth(); const out = new Map<number, number>()
    for (const p of await db.payments.toArray()) if (!p.voided && p.date.slice(0, 7) === m) out.set(p.customerId, (out.get(p.customerId) ?? 0) + p.amountPaise)
    return out
  }, [], new Map<number, number>())
  const [busy, setBusy] = useState(0)
  if (!customers || !owed) return <Loading />
  const q = search.trim().toLowerCase()
  const list = customers.map(c => ({ c, o: owed.get(c.id!) ?? 0 })).filter(x => x.o > 0 && (!q || x.c.name.toLowerCase().includes(q) || x.c.area.toLowerCase().includes(q))).sort((a, b) => b.o - a.o)
  const total = list.reduce((s, x) => s + x.o, 0)

  const remind = async (c: Customer) => {
    if (busy) return
    setBusy(c.id!)
    try {
      const tpl = await db.templates.where('key').equals('reminder').first()
      const ctx = await buildContext(c, currentMonth())
      const text = renderTemplate(tpl?.body ?? 'Hello {Customer Name}, your pending amount is ₹{Balance}. Thank you.', ctx)
      await logOpened(c.id!, 'whatsapp', text)
      window.open(messageLink('whatsapp', c, text), '_blank', 'noopener')
    } catch (e) { toast(errMsg(e), 'err') } finally { setBusy(0) }
  }

  return (
    <div>
      <div className="card sumcard"><div><div className="k">Total Payment Pending</div><div className="v num" style={{ color: 'var(--red)' }}>{fmt(total)}</div></div><div><div className="k">Customers</div><div className="v num">{list.length}</div></div></div>
      {list.length === 0
        ? <div className="card" style={{ marginTop: 10 }}><Empty icon={<CircleCheck />} title={customers.length === 0 ? 'No customers yet' : q ? 'No customer found' : 'Nothing is pending'} text={customers.length === 0 ? 'Add a customer to start.' : q ? 'Try a different name.' : 'Every customer has paid up.'} /></div>
        : list.map(({ c, o }) => (
          <div className="mcard" key={c.id} style={{ padding: 12 }}>
            <div className="row">
              <Avatar name={c.name} />
              <div className="grow"><div className="nm" style={{ fontWeight: 700 }}>{c.name}</div><div className="sub">{c.area || c.code}</div></div>
              <div style={{ textAlign: 'right' }}><PayTag status={payStatus(o, paid.get(c.id!) ?? 0)} /><div className="amt red" style={{ marginTop: 4 }}>{fmt(o)}</div></div>
            </div>
            <div className="actrow">
              {c.mobile.trim() ? <a className="btn" href={`tel:${c.mobile}`}><Phone size={18} />Call</a> : <button className="btn" disabled><Phone size={18} />No phone number</button>}
              <button className="btn green" disabled={!hasPhone(c, 'whatsapp') || busy === c.id} onClick={() => remind(c)}><MessageCircle size={18} />Send reminder</button>
              <a className="btn primary" href={`#/payments/${c.id}`}><Wallet size={18} />Payment</a>
            </div>
          </div>
        ))}
      <p className="sub" style={{ marginTop: 10 }}>The reminder opens WhatsApp with your Payment reminder template. You press send there.</p>
    </div>
  )
}
