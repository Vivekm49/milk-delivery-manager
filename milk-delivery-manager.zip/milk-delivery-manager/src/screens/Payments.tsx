import { useState, useMemo } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Wallet, Ban } from 'lucide-react'
import { db, balanceOf } from '../lib/db'
import { recordPayment, voidPayment } from '../lib/billing'
import { parseMoney, moneyInput } from '../lib/money'
import { dateLabel, todayISO } from '../lib/dates'
import { Field, PageHead, Empty, fmt, toast, errMsg, Loading, confirmDialog } from '../lib/ui'
import type { PayMethod } from '../lib/types'

const METHODS: PayMethod[] = ['Cash', 'UPI', 'Bank Transfer', 'Other']

export default function Payments({ preselect }: { preselect?: number }) {
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const bills = useLiveQuery(() => db.bills.toArray(), [], [])
  const payments = useLiveQuery(() => db.payments.toArray(), [], [])
  const [cid, setCid] = useState<number>(preselect ?? 0)
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState(todayISO())
  const [method, setMethod] = useState<PayMethod>('Cash')
  const [ref, setRef] = useState('')
  const [note, setNote] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [q, setQ] = useState('')
  const cmap = useMemo(() => new Map((customers ?? []).map(c => [c.id!, c])), [customers])
  if (!customers) return <Loading />
  const sel = cmap.get(cid)
  const bal = sel ? balanceOf(sel, bills, payments) : 0

  const save = async () => {
    setErr('')
    const p = parseMoney(amount)
    if (!cid) return setErr('Choose a customer.')
    if (!p || p <= 0) return setErr('Enter a payment amount greater than zero, for example 2000.')
    if (p > Math.max(bal, 0) && !(await confirmDialog({ title: 'Payment is more than the balance', body: `Balance is ${fmt(bal)} and you are recording ${fmt(p)}. The extra will show as advance (credit) for this customer.`, confirmLabel: 'Record anyway' }))) return
    setBusy(true)
    try {
      await recordPayment({ customerId: cid, amountPaise: p, date, method, reference: ref, note })
      toast(`Payment of ${fmt(p)} recorded`, 'ok'); setAmount(''); setRef(''); setNote('')
    } catch (e) { setErr(errMsg(e)) } finally { setBusy(false) }
  }
  const remove = async (id: number) => {
    if (await confirmDialog({ title: 'Cancel this payment?', body: 'The payment stays in history marked as cancelled, and the customer balance goes back up.', confirmLabel: 'Cancel payment', danger: true })) { await voidPayment(id); toast('Payment cancelled') }
  }
  const list = [...payments].filter(p => !q.trim() || (cmap.get(p.customerId)?.name ?? '').toLowerCase().includes(q.trim().toLowerCase())).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt).slice(0, 100)

  return (
    <div className="stack">
      <PageHead back={{ to: 'more', label: 'More' }} title="Payments" />
      <div className="card formgrid">
        <Field label="Customer"><select className="in" value={cid} onChange={e => setCid(Number(e.target.value))}><option value={0}>Choose customer</option>{customers.filter(c => c.status !== 'inactive' || balanceOf(c, bills, payments) !== 0).sort((a, b) => a.name.localeCompare(b.name)).map(c => <option key={c.id} value={c.id}>{c.name} ({c.code})</option>)}</select></Field>
        {sel && <div className="notice">Balance now: <b className="num">{fmt(bal)}</b>{bal > 0 && <> · <button className="btn sm ghost" style={{ minHeight: 32, padding: 0 }} onClick={() => setAmount(moneyInput(bal))}>Fill full amount</button></>}</div>}
        <div className="formgrid two">
          <Field label="Amount"><input className="in" inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value)} placeholder="2000" /></Field>
          <Field label="Payment date"><input type="date" className="in" value={date} max={todayISO()} onChange={e => setDate(e.target.value)} /></Field>
        </div>
        <Field label="Method"><div className="seg">{METHODS.map(m => <button key={m} className={method === m ? 'on' : ''} onClick={() => setMethod(m)}>{m}</button>)}</div></Field>
        <div className="formgrid two">
          <Field label="Reference number (optional)"><input className="in" value={ref} onChange={e => setRef(e.target.value)} maxLength={60} /></Field>
          <Field label="Notes (optional)"><input className="in" value={note} onChange={e => setNote(e.target.value)} maxLength={200} /></Field>
        </div>
        {err && <div className="notice bad" role="alert">{err}</div>}
        <button className="btn green block" onClick={save} disabled={busy}><Wallet size={20} />Record payment</button>
      </div>

      <div className="card">
        <div className="row between wrap"><h2 className="h2">Payment history</h2><input className="in" style={{ maxWidth: 220 }} placeholder="Search customer" value={q} onChange={e => setQ(e.target.value)} /></div>
        {list.length === 0 ? <Empty icon={<Wallet />} title="No payments yet" text="Recorded payments will appear here." /> :
          <div className="list">{list.map(p => (
            <div className="item" key={p.id} style={{ opacity: p.voided ? 0.55 : 1 }}>
              <div className="grow"><div className="t">{cmap.get(p.customerId)?.name ?? 'Customer'} {p.voided && <span className="badge gray">Cancelled</span>}</div><div className="s">{dateLabel(p.date)} · {p.method}{p.reference ? ` · Ref ${p.reference}` : ''}{p.note ? ` · ${p.note}` : ''}</div></div>
              <div className="total num" style={{ fontSize: 17, textDecoration: p.voided ? 'line-through' : 'none' }}>{fmt(p.amountPaise)}</div>
              {!p.voided && <button className="btn sm ghost" aria-label="Cancel payment" onClick={() => remove(p.id!)}><Ban size={18} /></button>}
            </div>))}</div>}
      </div>
    </div>
  )
}
