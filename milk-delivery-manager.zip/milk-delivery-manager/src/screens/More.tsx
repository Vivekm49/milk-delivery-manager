import { Wallet, Clock, MessageSquare, BarChart3, CalendarDays, Package, FolderCog, Settings as Cog, ChevronRight } from 'lucide-react'

const items = [
  { to: 'payments', label: 'Payments', sub: 'Record and see payments', icon: Wallet, c: 'blue' },
  { to: 'pending', label: 'Payment Pending', sub: 'Who owes how much, send a reminder', icon: Clock, c: 'amber' },
  { to: 'messages', label: 'Messages', sub: 'Templates, WhatsApp and SMS', icon: MessageSquare, c: 'green' },
  { to: 'reports', label: 'Reports', sub: 'Daily, monthly, profit and loss, PDF', icon: BarChart3, c: 'purple' },
  { to: 'calendar', label: 'Calendar', sub: 'Delivery and Absent days of a customer', icon: CalendarDays, c: 'teal' },
  { to: 'products', label: 'Product Rates', sub: 'Milk types, sell and buy rates', icon: Package, c: 'blue' },
  { to: 'customers/groups', label: 'Groups', sub: 'Morning, Evening and more', icon: FolderCog, c: 'amber' },
  { to: 'settings', label: 'Settings & Backup', sub: 'Shop details, theme, UPI QR, backup', icon: Cog, c: 'blue' }
]
export default function More() {
  return <div className="card mlist">{items.map(i => <a key={i.to} href={`#/${i.to}`}><span className={`ib ${i.c}`}><i.icon size={22} /></span><div className="grow"><div className="t">{i.label}</div><div className="s">{i.sub}</div></div><ChevronRight size={20} color="var(--muted)" /></a>)}</div>
}
