import { Wallet, MessageSquare, BarChart3, Package, Settings as Cog, ChevronRight } from 'lucide-react'
import { PageHead } from '../lib/ui'

const items = [
  { to: 'payments', label: 'Payments', sub: 'Record and review payments', icon: Wallet },
  { to: 'messages', label: 'Messages', sub: 'Templates and WhatsApp / SMS', icon: MessageSquare },
  { to: 'reports', label: 'Reports', sub: 'Daily, monthly and customer reports', icon: BarChart3 },
  { to: 'products', label: 'Products & Rates', sub: 'Milk types, units and price history', icon: Package },
  { to: 'settings', label: 'Settings', sub: 'Business, theme, backup and data', icon: Cog }
]
export default function More() {
  return <><PageHead title="More" /><div className="card list">{items.map(i => <a key={i.to} className="item" href={`#/${i.to}`}><div className="avatar"><i.icon size={22} /></div><div className="grow"><div className="t">{i.label}</div><div className="s">{i.sub}</div></div><ChevronRight size={20} className="muted" /></a>)}</div></>
}
