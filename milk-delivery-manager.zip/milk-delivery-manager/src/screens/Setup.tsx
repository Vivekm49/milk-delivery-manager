import { useState } from 'react'
import { db, saveSettings, addRate } from '../lib/db'
import { createCustomer } from '../lib/customers'
import { parseMoney, parseQty, UNITS, moneyInput } from '../lib/money'
import { todayISO } from '../lib/dates'
import { Field, errMsg, toast, setCurrency } from '../lib/ui'
import { useLiveQuery } from 'dexie-react-hooks'
import { isValidPhone } from '../lib/money'

export default function Setup() {
  const [step, setStep] = useState(0)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const [f, setF] = useState({ business: '', owner: '', mobile: '', address: '', currency: '₹', productId: 0, rate: '', extra: '' })
  const [c, setC] = useState({ name: '', mobile: '', area: '', qty: '1' })
  const [err, setErr] = useState('')
  const set = (k: string, v: string | number) => setF(p => ({ ...p, [k]: v }))
  const pid = f.productId || products[0]?.id || 0

  const next1 = () => {
    if (f.business.trim().length < 2) return setErr('Enter your business name.')
    if (f.mobile && !isValidPhone(f.mobile)) return setErr('Enter a valid 10-digit mobile number or leave it empty.')
    if (!f.currency.trim() || f.currency.length > 4) return setErr('Enter a currency symbol such as ₹.')
    setErr(''); setStep(1)
  }
  const next2 = () => {
    const r = parseMoney(f.rate)
    if (!r || r <= 0) return setErr('Enter the rate per unit, for example 60.')
    if (f.extra.trim() && !parseMoney(f.extra)) return setErr('Extra milk rate is not valid.')
    setErr(''); setStep(2)
  }
  const finish = async (withCustomer: boolean) => {
    try {
      const rate = parseMoney(f.rate)!
      await addRate(pid, 0, rate, f.extra.trim() ? parseMoney(f.extra) : null, '2000-01-01')
      if (withCustomer) {
        const q = parseQty(c.qty)
        if (!q) return setErr('Enter a valid daily quantity.')
        await createCustomer({ name: c.name, mobile: c.mobile, whatsapp: '', address: '', area: c.area, productId: pid, dailyMl: q, startDate: todayISO(), prefTime: 'Morning', notes: '', openingPaise: 0 })
      }
      await saveSettings({ businessName: f.business.trim(), ownerName: f.owner.trim(), mobile: f.mobile.trim(), address: f.address.trim(), currency: f.currency.trim(), defaultProductId: pid, setupDone: true })
      setCurrency(f.currency.trim())
      location.hash = '#/dashboard'
    } catch (e) { setErr(errMsg(e)); toast(errMsg(e), 'err') }
  }
  const unit = products.find(p => p.id === pid)?.unit ?? 'L'

  return (
    <div className="setup stack">
      <h1 className="title">Welcome</h1>
      <p className="sub">Set up Milk Delivery Manager in three short steps. Everything is stored on this phone.</p>
      <div className="steps">{[0, 1, 2].map(i => <i key={i} className={i <= step ? 'on' : ''} />)}</div>
      {step === 0 && <div className="card formgrid">
        <Field label="Business name"><input className="in" value={f.business} onChange={e => set('business', e.target.value)} maxLength={60} autoFocus /></Field>
        <Field label="Owner name"><input className="in" value={f.owner} onChange={e => set('owner', e.target.value)} maxLength={60} /></Field>
        <Field label="Mobile number"><input className="in" inputMode="tel" value={f.mobile} onChange={e => set('mobile', e.target.value)} maxLength={16} /></Field>
        <Field label="Address"><input className="in" value={f.address} onChange={e => set('address', e.target.value)} maxLength={200} /></Field>
        <Field label="Currency symbol"><input className="in" value={f.currency} onChange={e => set('currency', e.target.value)} maxLength={4} /></Field>
        {err && <div className="notice bad" role="alert">{err}</div>}
        <button className="btn primary block" onClick={next1}>Continue</button>
      </div>}
      {step === 1 && <div className="card formgrid">
        <Field label="Main product"><select className="in" value={pid} onChange={e => set('productId', Number(e.target.value))}>{products.filter(p => p.active).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
        <Field label={`Rate per ${UNITS[unit].short}`} hint="Other products can get their rates later in Products & Rates."><input className="in" inputMode="decimal" value={f.rate} onChange={e => set('rate', e.target.value)} placeholder="60" /></Field>
        <Field label={`Extra milk rate per ${UNITS[unit].short} (optional)`} hint={`Leave empty to charge the same rate. Example: ${moneyInput(6500)}`}><input className="in" inputMode="decimal" value={f.extra} onChange={e => set('extra', e.target.value)} /></Field>
        {err && <div className="notice bad" role="alert">{err}</div>}
        <div className="row"><button className="btn grow" onClick={() => { setErr(''); setStep(0) }}>Back</button><button className="btn primary grow" onClick={next2}>Continue</button></div>
      </div>}
      {step === 2 && <div className="card formgrid">
        <p className="h2">Add your first customer</p>
        <Field label="Name"><input className="in" value={c.name} onChange={e => setC({ ...c, name: e.target.value })} maxLength={60} /></Field>
        <Field label="Mobile number"><input className="in" inputMode="tel" value={c.mobile} onChange={e => setC({ ...c, mobile: e.target.value })} maxLength={16} /></Field>
        <Field label="Area"><input className="in" value={c.area} onChange={e => setC({ ...c, area: e.target.value })} maxLength={60} /></Field>
        <Field label={`Daily quantity (${UNITS[unit].short})`}><input className="in" inputMode="decimal" value={c.qty} onChange={e => setC({ ...c, qty: e.target.value })} /></Field>
        {err && <div className="notice bad" role="alert">{err}</div>}
        <button className="btn green block" onClick={() => finish(true)}>Save customer and start</button>
        <button className="btn block" onClick={() => finish(false)}>Skip for now</button>
        <button className="btn ghost block" onClick={() => { setErr(''); setStep(1) }}>Back</button>
      </div>}
    </div>
  )
}
