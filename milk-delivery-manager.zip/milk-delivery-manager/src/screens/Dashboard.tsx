import { useLiveQuery } from 'dexie-react-hooks'
import { UserPlus, ClipboardCheck, Receipt, Wallet, Send, Users } from 'lucide-react'
import { db, getSettings, balanceOf, isPausedOn } from '../lib/db'
import { buildLines } from '../lib/billing'
import { formatQty } from '../lib/money'
import { dateLabel, monthEnd, monthLabel, monthStart, todayISO } from '../lib/dates'
import { fmt, Loading, Empty } from '../lib/ui'

export async function loadDashboard(today = todayISO()) {
  const month = today.slice(0, 7)
  const [customers, products, rates, pauses, bills, payments, settings] = await Promise.all([
    db.customers.toArray(), db.products.toArray(), db.rates.toArray(), db.pauses.toArray(), db.bills.toArray(), db.payments.toArray(), getSettings()
  ])
  const todayEntries = await db.entries.where('date').equals(today).toArray()
  const monthEntries = await db.entries.where('date').between(monthStart(month), monthEnd(month), true, true).toArray()
  const pmap = new Map(products.map(p => [p.id!, p]))
  const isLitre = (pid: number) => { const u = pmap.get(pid)?.unit; return u === 'L' || u === '500ml' }
  const delivered = todayEntries.filter(e => e.status === 'delivered')
  const expected = customers.filter(c => c.status === 'active' && c.startDate <= today && !isPausedOn(pauses, c.id!, today))
  const todayLitres = delivered.filter(e => isLitre(e.productId)).reduce((s, e) => s + e.regularMl + e.extraMl, 0)
  const extraLitres = delivered.filter(e => isLitre(e.productId)).reduce((s, e) => s + e.extraMl, 0)
  const exp = buildLines(delivered, rates, pmap).lines.reduce((s, l) => s + l.amountPaise, 0)
  const sales = buildLines(monthEntries, rates, pmap).lines.reduce((s, l) => s + l.amountPaise, 0)
  const pending = customers.reduce((s, c) => s + Math.max(0, balanceOf(c, bills, payments)), 0)
  const todayPaid = payments.filter(p => !p.voided && p.date === today).reduce((s, p) => s + p.amountPaise, 0)
  const cname = new Map(customers.map(c => [c.id!, c.name]))
  const activity: { t: number; text: string; kind: string }[] = []
  for (const p of payments.filter(p => !p.voided)) activity.push({ t: p.createdAt, kind: 'pay', text: `${cname.get(p.customerId) ?? 'Customer'} paid ${fmt(p.amountPaise)} (${p.method})` })
  for (const b of bills.filter(b => b.status === 'issued')) activity.push({ t: b.createdAt, kind: 'bill', text: `Bill ${b.number} for ${cname.get(b.customerId) ?? 'Customer'}: ${fmt(b.totalPaise)}` })
  for (const c of customers) activity.push({ t: c.createdAt, kind: 'cust', text: `New customer ${c.name}` })
  const recentEntries = [...todayEntries].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 4)
  for (const e of recentEntries) activity.push({ t: e.updatedAt, kind: 'del', text: `${cname.get(e.customerId) ?? 'Customer'}: ${e.status === 'skipped' ? 'skipped' : 'delivered ' + formatQty(e.regularMl + e.extraMl, pmap.get(e.productId)?.unit)}` })
  activity.sort((a, b) => b.t - a.t)
  return {
    today, month, name: settings.businessName, todayLitres, extraLitres, deliveredCount: new Set(delivered.map(e => e.customerId)).size, expectedCount: expected.length,
    skipped: new Set(todayEntries.filter(e => e.status === 'skipped' && !delivered.some(o => o.customerId === e.customerId)).map(e => e.customerId)).size, active: customers.filter(c => c.status === 'active').length, totalCustomers: customers.length,
    exp, todayPaid, pending, sales, activity: activity.slice(0, 8)
  }
}

export default function Dashboard() {
  const d = useLiveQuery(() => loadDashboard(), [], undefined)
  const backupAge = useLiveQuery(async () => {
    const v = (await db.settings.get('lastBackup'))?.value as string | undefined
    return v ? Math.floor((Date.now() - new Date(v).getTime()) / 86400000) : null
  }, [], undefined)
  if (!d) return <Loading />
  const pct = d.expectedCount ? Math.min(100, Math.round((d.deliveredCount / d.expectedCount) * 100)) : 0
  const litres = d.todayLitres / 1000
  return (
    <div className="stack">
      <div><h1 className="title">{d.name || 'Dashboard'}</h1><p className="sub">{dateLabel(d.today)}</p></div>
      {d.totalCustomers > 0 && backupAge !== undefined && (backupAge === null || backupAge > 7) && <a className="notice warn" href="#/settings" style={{ display: 'block', textDecoration: 'none', color: 'inherit' }}>{backupAge === null ? 'No backup yet.' : `Last backup was ${backupAge} days ago.`} Your data is only on this phone. Tap to create a backup.</a>}
      <div className="hero" style={{ marginTop: 12 }}>
        <div className="sub" style={{ color: 'rgba(255,255,255,.85)' }}>Today's milk</div>
        <div className="big num">{Number.isInteger(litres) ? litres : litres.toFixed(2).replace(/0$/, '')}<small>L</small></div>
        <div className="bar" aria-hidden><i style={{ width: `${pct}%` }} /></div>
        <div className="row between wrap" style={{ fontWeight: 600 }}><span>{d.deliveredCount} of {d.expectedCount} deliveries done</span><span>Extra {formatQty(d.extraLitres) === '0 ml' ? 'none' : formatQty(d.extraLitres)}</span></div>
      </div>

      <div className="grid2 stack-none" style={{ marginTop: 12 }}>
        <a className="btn primary" href="#/entry"><ClipboardCheck size={20} />Today's Entry</a>
        <a className="btn" href="#/customers/new"><UserPlus size={20} />Add Customer</a>
        <a className="btn" href="#/billing/new"><Receipt size={20} />Generate Bill</a>
        <a className="btn" href="#/payments"><Wallet size={20} />Add Payment</a>
        <a className="btn" href="#/messages" style={{ gridColumn: '1 / -1' }}><Send size={20} />Send Messages</a>
      </div>

      <div className="grid4" style={{ marginTop: 12 }}>
        <div className="stat"><div className="k">Active customers</div><div className="v num">{d.active}</div></div>
        <div className="stat warn"><div className="k">Skipped today</div><div className="v num">{d.skipped}</div></div>
        <div className="stat"><div className="k">Expected collection today</div><div className="v num">{fmt(d.exp)}</div></div>
        <div className="stat good"><div className="k">Payments received today</div><div className="v num">{fmt(d.todayPaid)}</div></div>
        <div className="stat bad"><div className="k">Pending payments</div><div className="v num">{fmt(d.pending)}</div></div>
        <div className="stat"><div className="k">Sales in {monthLabel(d.month)}</div><div className="v num">{fmt(d.sales)}</div></div>
      </div>

      <div className="card" style={{ marginTop: 12 }}>
        <h2 className="h2">Recent activity</h2>
        {d.activity.length === 0
          ? <Empty icon={<Users />} title="Nothing here yet" text="Add a customer and record today's deliveries to see activity." action={<a className="btn primary" href="#/customers/new">Add Customer</a>} />
          : <div className="list">{d.activity.map((a, i) => <div className="item" key={i}><div className="grow"><div className="t" style={{ fontWeight: 600 }}>{a.text}</div><div className="s">{new Date(a.t).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</div></div></div>)}</div>}
      </div>
    </div>
  )
}
