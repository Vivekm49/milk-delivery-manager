import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { UserPlus, ClipboardCheck, Receipt, Wallet, Send, Users, Milk, Truck, UserX, IndianRupee, Clock } from 'lucide-react'
import { db } from '../lib/db'
import { loadToday } from '../lib/today'
import { loadMonthly } from '../lib/monthly'
import { formatQty } from '../lib/money'
import { monthLabel } from '../lib/dates'
import { useApp } from '../lib/appctx'
import { fmt, Loading, Empty } from '../lib/ui'
import { PayTag, Avatar } from '../components/Tags'

export default function Dashboard() {
  const { month, search } = useApp()
  const d = useLiveQuery(async () => ({ t: await loadToday(), m: await loadMonthly(month) }), [month], undefined)
  const products = useLiveQuery(() => db.products.toArray(), [], [])
  const groups = useLiveQuery(() => db.groups.toArray(), [], [])
  const backupAge = useLiveQuery(async () => {
    const v = (await db.settings.get('lastBackup'))?.value as string | undefined
    return v ? Math.floor((Date.now() - new Date(v).getTime()) / 86400000) : null
  }, [], undefined)
  const [group, setGroup] = useState<number | 'all'>('all')
  const pmap = useMemo(() => new Map(products.map(p => [p.id!, p])), [products])
  const gname = useMemo(() => new Map(groups.map(g => [g.id!, g.name])), [groups])
  if (!d) return <Loading />
  const { t, m } = d
  const litres = t.litresMilli
  const q = search.trim().toLowerCase()
  const rows = m.rows.filter(r => {
    const c = r.customer
    if (group !== 'all' && (c.groupId ?? null) !== group) return false
    return !q || c.name.toLowerCase().includes(q) || c.area.toLowerCase().includes(q) || c.code.toLowerCase().includes(q) || c.mobile.includes(q)
  })
  const shown = rows.slice(0, 12)

  return (
    <div>
      {t.totalCustomers > 0 && backupAge !== undefined && (backupAge === null || backupAge > 7) && (
        <a className="notice warn" href="#/settings" style={{ display: 'block', textDecoration: 'none', color: 'inherit', marginBottom: 10 }}>{backupAge === null ? 'No backup yet.' : `Last backup was ${backupAge} days ago.`} Your data is only on this phone. Tap to create a backup.</a>
      )}
      <div className="tiles">
        <div className="tile"><span className="ib blue"><Milk size={22} /></span><div><div className="v num">{litres === 0 ? '0 L' : formatQty(litres)}</div><div className="k">Today's milk</div></div></div>
        <div className="tile"><span className="ib green"><Truck size={22} /></span><div><div className="v num">{t.delivered} of {t.expected}</div><div className="k">Deliveries today</div></div></div>
        <div className="tile"><span className="ib red"><UserX size={22} /></span><div><div className="v num">{t.absent}</div><div className="k">Absent today</div></div></div>
        <div className="tile"><span className="ib purple"><Users size={22} /></span><div><div className="v num">{t.active}</div><div className="k">Active customers</div></div></div>
        <div className="tile"><span className="ib teal"><IndianRupee size={22} /></span><div><div className="v num">{fmt(m.totals.amountPaise)}</div><div className="k">Monthly Amount ({monthLabel(month).slice(0, 3)})</div></div></div>
        <div className="tile"><span className="ib amber"><Clock size={22} /></span><div><div className="v num" style={{ color: m.totals.pendingPaise > 0 ? 'var(--red)' : undefined }}>{fmt(m.totals.pendingPaise)}</div><div className="k">Payment Pending</div></div></div>
      </div>

      <div className="qa">
        <a href="#/customers/new"><span className="ib blue"><UserPlus size={22} /></span>Add Customer</a>
        <a href="#/entry"><span className="ib green"><ClipboardCheck size={22} /></span>Today's Entry</a>
        <a href="#/billing/new"><span className="ib purple"><Receipt size={22} /></span>Create Bill</a>
        <a href="#/payments"><span className="ib amber"><Wallet size={22} /></span>Add Payment</a>
        <a href="#/messages"><span className="ib teal"><Send size={22} /></span>Send Messages</a>
      </div>

      <div className="sect"><h2 className="h2">Customers</h2><a href="#/customers">See all</a></div>
      {groups.length > 0 && (
        <div className="chips" style={{ marginBottom: 4 }}>
          <button className={`chip ${group === 'all' ? 'on' : ''}`} onClick={() => setGroup('all')}>All {m.rows.length}</button>
          {groups.map(g => <button key={g.id} className={`chip ${group === g.id ? 'on' : ''}`} onClick={() => setGroup(g.id!)}>{g.name} {m.rows.filter(r => r.customer.groupId === g.id).length}</button>)}
        </div>
      )}
      {m.rows.length === 0
        ? <div className="card"><Empty icon={<Users />} title="No customers yet" text="Add your first customer to start daily entries." action={<a className="btn primary" href="#/customers/new">Add Customer</a>} /></div>
        : shown.length === 0 ? <div className="card"><Empty icon={<Users />} title="No customer found" text="Try a different name or group." /></div>
        : shown.map(r => {
          const c = r.customer; const p = pmap.get(c.productId)
          return (
            <a className="crow" key={c.id} href={`#/customers/${c.id}`}>
              <Avatar name={c.name} />
              <div className="grow"><div className="nm">{c.name}</div><div className="sb"><span>{p?.name} {formatQty(c.dailyMl, p?.unit)}</span>{c.groupId && gname.get(c.groupId) ? <span className="badge blue" style={{ fontSize: 10.5 }}>{gname.get(c.groupId)}</span> : null}</div></div>
              <div className="rt"><PayTag status={r.status} /><span className={`amt ${r.owed > 0 ? (r.status === 'Unpaid' ? 'red' : 'amber') : 'muted'}`}>{r.owed > 0 ? fmt(r.owed) : r.owed < 0 ? `Advance ${fmt(-r.owed)}` : 'Nothing pending'}</span></div>
            </a>
          )
        })}
      {rows.length > shown.length && <p className="sub" style={{ textAlign: 'center', marginTop: 10 }}><a href="#/customers" style={{ color: 'var(--blue)', fontWeight: 700 }}>See all {rows.length} customers</a></p>}
    </div>
  )
}
