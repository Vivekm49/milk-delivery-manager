import { useEffect, useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Plus, Pencil, Trash2, RotateCcw, MessageCircle, Smartphone, SkipForward, Square, Play, Save } from 'lucide-react'
import { db, balanceOf, resetDefaultTemplates, getSetting } from '../lib/db'
import { buildContext, renderTemplate, messageLink, logOpened, findUnknownTags, hasPhone, PLACEHOLDERS, MONEY_TAGS, type Channel } from '../lib/messages'
import { currentMonth } from '../lib/dates'
import { isValidPhone } from '../lib/money'
import { PageHead, Seg, Field, Empty, Loading, MonthNav, toast, errMsg, confirmDialog, initials, getCurrency } from '../lib/ui'
import type { Template, Customer } from '../lib/types'

type Tab = 'bulk' | 'templates'

export default function Messages() {
  const [tab, setTab] = useState<Tab>('bulk')
  return <div className="stack"><PageHead title="Messages" sub="Opens WhatsApp or SMS with the message filled in. You press send." /><Seg<Tab> value={tab} onChange={setTab} options={[{ v: 'bulk', l: 'Send messages' }, { v: 'templates', l: 'Templates' }]} />{tab === 'templates' ? <Templates /> : <Bulk />}</div>
}

function Templates() {
  const templates = useLiveQuery(() => db.templates.toArray(), [], undefined)
  const customers = useLiveQuery(() => db.customers.toArray(), [], [])
  const [edit, setEdit] = useState<Template | null>(null)
  const [preview, setPreview] = useState('')
  const [err, setErr] = useState('')
  const [saving, setSaving] = useState(false)
  const sample = customers.find(c => c.status === 'active') ?? customers[0]
  useEffect(() => {
    if (!edit) return setPreview('')
    if (!sample) return setPreview('Add a customer to see a personalised preview.')
    buildContext(sample, currentMonth()).then(ctx => setPreview(renderTemplate(edit.body, ctx))).catch(() => setPreview(edit.body))
  }, [edit?.body, sample?.id])
  if (!templates) return <Loading />

  const save = async () => {
    if (!edit || saving) return
    const name = edit.name.trim(), body = edit.body.trim()
    if (!name || name.length > 40) return setErr('Enter a template name.')
    if (body.length < 5 || body.length > 600) return setErr('Message must be 5 to 600 characters.')
    setSaving(true)
    try {
      if (edit.id) await db.templates.update(edit.id, { name, body })
      else await db.templates.add({ key: 'custom-' + Date.now(), name, body, builtin: false })
      toast('Template saved', 'ok'); setEdit(null); setErr('')
    } catch (e) { setErr(errMsg(e)) } finally { setSaving(false) }
  }
  const insert = (p: string) => edit && setEdit({ ...edit, body: `${edit.body}${edit.body && !/\s$/.test(edit.body) ? ' ' : ''}${MONEY_TAGS.has(p) ? getCurrency() : ''}{${p}}` })
  const del = async (t: Template) => { if (await confirmDialog({ title: `Delete "${t.name}"?`, body: 'This template will be removed.', confirmLabel: 'Delete', danger: true })) { await db.templates.delete(t.id!); toast('Template deleted') } }
  const reset = async () => { if (await confirmDialog({ title: 'Reset default templates?', body: 'The three built-in templates return to their original text. Your custom templates stay.', confirmLabel: 'Reset' })) { await resetDefaultTemplates(); toast('Defaults restored', 'ok') } }

  return (
    <div className="stack">
      <div className="row wrap"><button className="btn primary" onClick={() => setEdit({ key: '', name: '', body: '', builtin: false })}><Plus size={20} />New template</button><button className="btn" onClick={reset}><RotateCcw size={20} />Reset defaults</button></div>
      {edit && <div className="card formgrid">
        <h2 className="h2">{edit.id ? 'Edit message template' : 'New message template'}</h2>
        <Field label="Name"><input className="in" value={edit.name} maxLength={40} onChange={e => setEdit({ ...edit, name: e.target.value })} /></Field>
        <Field label="Message"><textarea className="in" value={edit.body} maxLength={600} onChange={e => setEdit({ ...edit, body: e.target.value })} /></Field>
        <div><div className="lbl" style={{ marginBottom: 6 }}>Tap to insert</div><div className="chips" style={{ flexWrap: 'wrap', overflow: 'visible' }}>{PLACEHOLDERS.map(p => <button key={p} className="chip" onClick={() => insert(p)}>{`{${p}}`}</button>)}</div></div>
        <div><div className="lbl" style={{ marginBottom: 6 }}>Preview{sample ? ` (${sample.name})` : ''}</div><div className="preview">{preview}</div></div>
        {findUnknownTags(edit.body).length > 0 && <div className="notice warn">These tags are not recognised and will be left out of the message: {findUnknownTags(edit.body).join(' ')}</div>}
        {err && <div className="notice bad" role="alert">{err}</div>}
        <div className="row"><button className="btn grow" onClick={() => { setEdit(null); setErr('') }}>Cancel</button><button className="btn primary grow" onClick={save} disabled={saving}><Save size={20} />Save</button></div>
      </div>}
      {templates.map(t => <div className="card" key={t.id}><div className="row between wrap"><div className="grow"><div className="h2">{t.name} {t.builtin && <span className="badge">Default</span>}</div></div><div className="row"><button className="btn sm" onClick={() => setEdit(t)}><Pencil size={18} />Edit</button>{!t.builtin && <button className="btn sm danger" aria-label={`Delete ${t.name}`} onClick={() => del(t)}><Trash2 size={18} /></button>}</div></div><p className="sub" style={{ marginTop: 6, color: 'var(--ink)' }}>{t.body}</p></div>)}
    </div>
  )
}

interface Queue { ids: number[]; idx: number; channel: Channel; templateId: number; month: string; running: boolean }

function Bulk() {
  const customers = useLiveQuery(() => db.customers.toArray(), [], undefined)
  const templates = useLiveQuery(() => db.templates.toArray(), [], [])
  const bills = useLiveQuery(() => db.bills.toArray(), [], [])
  const payments = useLiveQuery(() => db.payments.toArray(), [], [])
  const [sel, setSel] = useState<Set<number>>(new Set())
  const [filter, setFilter] = useState<'all' | 'pending' | 'active'>('pending')
  const [q, setQ] = useState('')
  const [tid, setTid] = useState(0)
  const [channel, setChannel] = useState<Channel>('whatsapp')
  const [month, setMonth] = useState(currentMonth())
  const [queue, setQueue] = useState<Queue | null>(null)
  const [loaded, setLoaded] = useState(false)
  const [text, setText] = useState('')
  const [pvId, setPvId] = useState(0)

  useEffect(() => { getSetting<Queue | null>('bulkQueue', null).then(v => { if (v && v.idx < v.ids.length) setQueue({ ...v, running: false }); setLoaded(true) }) }, [])
  useEffect(() => { if (!tid && templates.length) setTid(templates[0].id!) }, [templates, tid])
  const persist = async (qd: Queue | null) => { setQueue(qd); if (qd) await db.settings.put({ key: 'bulkQueue', value: qd }); else await db.settings.delete('bulkQueue') }
  const cmap = useMemo(() => new Map((customers ?? []).map(c => [c.id!, c])), [customers])
  const tpl = templates.find(t => t.id === (queue?.templateId ?? tid))
  const currentId = queue ? queue.ids[queue.idx] : pvId
  const current = cmap.get(currentId)

  useEffect(() => {
    if (!tpl || !current) return setText('')
    buildContext(current, queue?.month ?? month).then(ctx => setText(renderTemplate(tpl.body, ctx))).catch(() => setText(tpl.body))
  }, [tpl?.id, tpl?.body, current?.id, month, queue?.month, queue?.idx])

  if (!customers || !loaded) return <Loading />
  const eligible = customers.filter(c => {
    if (c.status === 'inactive' && filter !== 'pending') return false
    if (filter === 'pending' && balanceOf(c, bills, payments) <= 0) return false
    if (filter === 'active' && c.status !== 'active') return false
    const t = q.trim().toLowerCase()
    return !t || c.name.toLowerCase().includes(t) || c.area.toLowerCase().includes(t)
  }).sort((a, b) => a.name.localeCompare(b.name))
  const toggle = (id: number) => { const n = new Set(sel); n.has(id) ? n.delete(id) : n.add(id); setSel(n) }
  const bad = (c: Customer) => !hasPhone(c, channel) || !isValidPhone(channel === 'whatsapp' ? c.whatsapp || c.mobile : c.mobile)

  const start = async () => {
    const ids = eligible.filter(c => sel.has(c.id!) && !bad(c)).map(c => c.id!)
    if (!ids.length) return toast('Select at least one customer who has a phone number.', 'err')
    await persist({ ids, idx: 0, channel, templateId: tid, month, running: true })
  }
  const advance = async () => {
    if (!queue) return
    const next = queue.idx + 1
    if (next >= queue.ids.length) { await persist(null); toast('All customers done', 'ok') } else await persist({ ...queue, idx: next, running: true })
  }
  const opened = () => { if (queue && current) logOpened(current.id!, queue.channel, text).catch(() => {}) }
  const copy = async () => { try { await navigator.clipboard.writeText(text); toast('Message copied', 'ok') } catch { toast('Could not copy.', 'err') } }

  if (queue && current) {
    return (
      <div className="stack">
        <div className="card">
          <div className="row between"><b>Customer {queue.idx + 1} of {queue.ids.length}</b><span className="badge">{queue.channel === 'whatsapp' ? 'WhatsApp' : 'SMS'}</span></div>
          <div className="bar" style={{ background: 'var(--line)' }}><i style={{ width: `${(queue.idx / queue.ids.length) * 100}%`, background: 'var(--green)' }} /></div>
          <div className="row" style={{ marginTop: 6 }}><div className="avatar">{initials(current.name)}</div><div className="grow"><div className="t" style={{ fontWeight: 800 }}>{current.name}</div><div className="s">{queue.channel === 'whatsapp' ? current.whatsapp || current.mobile : current.mobile}</div></div></div>
          <div className="preview" style={{ marginTop: 12 }}>{text}</div>
          <div className="stack" style={{ marginTop: 12 }}>
            {queue.running ? <>
              <a className={`btn block ${queue.channel === 'whatsapp' ? 'green' : 'primary'}`} href={messageLink(queue.channel, current, text)} target={queue.channel === 'whatsapp' ? '_blank' : undefined} rel="noopener noreferrer" onClick={opened}>{queue.channel === 'whatsapp' ? <MessageCircle size={20} /> : <Smartphone size={20} />}Open {queue.channel === 'whatsapp' ? 'WhatsApp' : 'SMS'}</a>
              <p className="sub">Press send inside the app, come back here and tap Next.</p>
              <div className="row"><button className="btn grow primary" onClick={advance}>Next customer</button><button className="btn grow" onClick={advance}><SkipForward size={20} />Skip</button></div>
              <div className="row"><button className="btn grow" onClick={copy}>Copy message</button><button className="btn grow danger" onClick={() => persist({ ...queue, running: false })}><Square size={20} />Stop</button></div>
            </> : <>
              <p className="sub">Paused. {queue.ids.length - queue.idx} customer(s) left.</p>
              <button className="btn primary block" onClick={() => persist({ ...queue, running: true })}><Play size={20} />Resume</button>
              <button className="btn danger block" onClick={() => persist(null)}>Cancel remaining</button>
            </>}
          </div>
        </div>
        <p className="sub">Opening an app does not mean the message was delivered. Check in WhatsApp or SMS.</p>
      </div>
    )
  }

  return (
    <div className="stack">
      <div className="card formgrid">
        <Field label="Template"><select className="in" value={tid} onChange={e => setTid(Number(e.target.value))}>{templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>
        <Seg<Channel> value={channel} onChange={setChannel} options={[{ v: 'whatsapp', l: 'WhatsApp' }, { v: 'sms', l: 'SMS' }]} />
        <MonthNav month={month} onChange={setMonth} />
      </div>
      <div className="card">
        <div className="chips">{([['pending', 'Payment pending'], ['active', 'Active'], ['all', 'Everyone']] as const).map(([k, l]) => <button key={k} className={`chip ${filter === k ? 'on' : ''}`} onClick={() => setFilter(k)}>{l}</button>)}</div>
        <input className="in" style={{ marginTop: 10 }} placeholder="Search name or area" value={q} onChange={e => setQ(e.target.value)} aria-label="Search customers" />
        <div className="row between" style={{ margin: '10px 0' }}><b>{sel.size} selected</b><div className="row"><button className="btn sm" onClick={() => setSel(new Set(eligible.filter(c => !bad(c)).map(c => c.id!)))}>Select all</button><button className="btn sm ghost" onClick={() => setSel(new Set())}>Clear</button></div></div>
        {eligible.length === 0 ? <Empty icon={<MessageCircle />} title="No customers match" text={filter === 'pending' ? 'Nobody has a payment pending right now.' : 'Add customers first.'} /> :
          <div className="list">{eligible.map(c => <label className="item" key={c.id} style={{ cursor: 'pointer' }}><input type="checkbox" style={{ width: 24, height: 24, flexShrink: 0 }} checked={sel.has(c.id!)} disabled={bad(c)} onChange={() => toggle(c.id!)} /><div className="grow"><div className="t">{c.name}</div><div className="s">{!hasPhone(c, channel) ? 'No phone number' : bad(c) ? 'Number is not valid' : c.mobile}</div></div><button className="btn sm ghost" onClick={e => { e.preventDefault(); setPvId(c.id!) }}>Preview</button></label>)}</div>}
      </div>
      {current && !queue && <div className="card"><div className="lbl" style={{ marginBottom: 6 }}>Preview for {current.name}</div><div className="preview">{text}</div></div>}
      <button className="btn primary block" onClick={start} disabled={!sel.size}>Start sending ({sel.size})</button>
    </div>
  )
}
