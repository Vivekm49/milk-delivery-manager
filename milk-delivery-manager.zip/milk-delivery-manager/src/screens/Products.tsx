import { useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Plus, Package, Pencil, History } from 'lucide-react'
import { db, addRate, resolveRate, AppError } from '../lib/db'
import { UNITS, parseMoney, moneyInput, type UnitKey } from '../lib/money'
import { dateLabel, isValidISO, todayISO } from '../lib/dates'
import { Field, PageHead, Empty, fmt, toast, errMsg, Loading, confirmDialog } from '../lib/ui'
import type { Product } from '../lib/types'

export default function Products() {
  const products = useLiveQuery(() => db.products.toArray(), [], undefined)
  const rates = useLiveQuery(() => db.rates.toArray(), [], [])
  const [edit, setEdit] = useState<Partial<Product> | null>(null)
  const [rateFor, setRateFor] = useState<Product | null>(null)
  if (!products) return <Loading />

  return (
    <div className="stack">
      <PageHead title="Products & Rates" sub="Changing a rate never changes old bills." right={<button className="btn primary" onClick={() => setEdit({ name: '', unit: 'L', active: true })}><Plus size={20} />Add product</button>} />
      {edit && <ProductForm p={edit} onClose={() => setEdit(null)} />}
      {rateFor && <RateForm product={rateFor} onClose={() => setRateFor(null)} />}
      {products.length === 0 && <Empty icon={<Package />} title="No products yet" text="Add the milk or dairy products you deliver." />}
      {products.map(p => {
        const cur = resolveRate(rates, 0, p.id!, todayISO())
        return (
          <div className="card" key={p.id} style={{ opacity: p.active ? 1 : 0.65 }}>
            <div className="row between wrap">
              <div className="grow"><div className="h2">{p.name}</div><div className="sub">{UNITS[p.unit].label}{!p.active && ' · Inactive'}</div></div>
              <div style={{ textAlign: 'right' }}>{cur ? <><div className="total num">{fmt(cur.ratePaise)}</div><div className="sub">per {UNITS[p.unit].short}{cur.extraRatePaise !== cur.ratePaise ? ` · extra ${fmt(cur.extraRatePaise)}` : ''}</div></> : <span className="badge amber">No rate set</span>}</div>
            </div>
            <div className="row wrap" style={{ marginTop: 12 }}>
              <button className="btn sm primary" onClick={() => setRateFor(p)}><History size={18} />Rates</button>
              <button className="btn sm" onClick={() => setEdit(p)}><Pencil size={18} />Edit</button>
            </div>
          </div>
        )
      })}
    </div>
  )
}

function ProductForm({ p, onClose }: { p: Partial<Product>; onClose: () => void }) {
  const [name, setName] = useState(p.name ?? '')
  const [unit, setUnit] = useState<UnitKey>(p.unit ?? 'L')
  const [active, setActive] = useState(p.active ?? true)
  const [err, setErr] = useState('')
  const save = async () => {
    try {
      const n = name.trim()
      if (n.length < 2 || n.length > 40) throw new AppError('Enter a product name (2 to 40 characters).')
      const dup = await db.products.filter(x => x.name.toLowerCase() === n.toLowerCase() && x.id !== p.id).first()
      if (dup) throw new AppError('A product with this name already exists.')
      if (p.id) {
        if (unit !== p.unit && (await db.entries.where('productId').equals(p.id).count()) > 0) throw new AppError('The unit cannot change after deliveries are recorded for this product.')
        if (!active && p.active) {
          const users = await db.customers.where('productId').equals(p.id).filter(c => c.status !== 'inactive').count()
          if (users > 0) throw new AppError(`${users} active customer(s) still use this product. Change their product first.`)
        }
        await db.products.update(p.id, { name: n, unit, active })
      } else await db.products.add({ name: n, unit, active, createdAt: Date.now() })
      toast('Product saved', 'ok'); onClose()
    } catch (e) { setErr(errMsg(e)) }
  }
  return (
    <div className="card formgrid">
      <h2 className="h2">{p.id ? 'Edit product' : 'New product'}</h2>
      <Field label="Product name"><input className="in" value={name} onChange={e => setName(e.target.value)} maxLength={40} autoFocus /></Field>
      <Field label="Unit"><select className="in" value={unit} onChange={e => setUnit(e.target.value as UnitKey)}>{Object.entries(UNITS).map(([k, u]) => <option key={k} value={k}>{u.label}</option>)}</select></Field>
      <label className="row" style={{ minHeight: 44 }}><input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} style={{ width: 22, height: 22 }} />Active (can be assigned to customers)</label>
      {err && <div className="notice bad" role="alert">{err}</div>}
      <div className="row"><button className="btn grow" onClick={onClose}>Cancel</button><button className="btn primary grow" onClick={save}>Save product</button></div>
    </div>
  )
}

function RateForm({ product, onClose }: { product: Product; onClose: () => void }) {
  const rates = useLiveQuery(() => db.rates.where('productId').equals(product.id!).toArray(), [product.id], [])
  const customers = useLiveQuery(() => db.customers.toArray(), [], [])
  const cur = resolveRate(rates, 0, product.id!, todayISO())
  const [rate, setRate] = useState(cur ? moneyInput(cur.ratePaise) : '')
  const [extra, setExtra] = useState(cur && cur.extraRatePaise !== cur.ratePaise ? moneyInput(cur.extraRatePaise) : '')
  const [from, setFrom] = useState(todayISO())
  const [err, setErr] = useState('')
  const save = async () => {
    try {
      const r = parseMoney(rate)
      if (!r) throw new AppError('Enter a valid rate, for example 60 or 62.50.')
      if (extra.trim() && !parseMoney(extra)) throw new AppError('Extra milk rate is not valid.')
      if (!isValidISO(from)) throw new AppError('Choose a valid date.')
      if (from < todayISO() && !(await confirmDialog({ title: 'Back-dated rate', body: 'This rate will apply to deliveries from that date that are not billed yet. Issued bills will not change.', confirmLabel: 'Apply rate' }))) return
      await addRate(product.id!, 0, r, extra.trim() ? parseMoney(extra) : null, from)
      toast('Rate saved', 'ok'); setErr('')
    } catch (e) { setErr(errMsg(e)) }
  }
  const sorted = [...rates].sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom) || (b.id ?? 0) - (a.id ?? 0))
  const cname = new Map(customers.map(c => [c.id!, c.name]))
  return (
    <div className="card formgrid">
      <div className="row between"><h2 className="h2">{product.name} rates</h2><button className="btn sm ghost" onClick={onClose}>Close</button></div>
      <div className="formgrid two">
        <Field label={`Rate per ${UNITS[product.unit].short}`}><input className="in" inputMode="decimal" value={rate} onChange={e => setRate(e.target.value)} /></Field>
        <Field label="Extra rate (optional)" hint="Empty = same as rate"><input className="in" inputMode="decimal" value={extra} onChange={e => setExtra(e.target.value)} /></Field>
        <Field label="Applies from"><input type="date" className="in" value={from} onChange={e => setFrom(e.target.value)} /></Field>
      </div>
      {err && <div className="notice bad" role="alert">{err}</div>}
      <button className="btn primary" onClick={save}>Save new rate</button>
      <h3 className="h2" style={{ marginTop: 6 }}>Rate history</h3>
      {sorted.length === 0 ? <p className="sub">No rates yet.</p> : <div className="list">{sorted.map(r => <div className="item" key={r.id}><div className="grow"><div className="t num">{fmt(r.ratePaise)}{r.extraRatePaise && r.extraRatePaise !== r.ratePaise ? ` · extra ${fmt(r.extraRatePaise)}` : ''}</div><div className="s">From {dateLabel(r.effectiveFrom)}{r.customerId ? ` · only ${cname.get(r.customerId) ?? 'a customer'}` : ' · all customers'}</div></div></div>)}</div>}
    </div>
  )
}
