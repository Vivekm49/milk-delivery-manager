import { useEffect, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Capacitor } from '@capacitor/core'
import { ChevronLeft, LayoutDashboard, Users, ClipboardCheck, Receipt, Wallet, MessageSquare, BarChart3, Package, Settings as Cog, MoreHorizontal } from 'lucide-react'
import { db, ensureSeed, getSettings, type AppSettings } from './lib/db'
import { ConfirmHost, ToastHost, useRoute, setCurrency, Loading, useOnline } from './lib/ui'
import Dashboard from './screens/Dashboard'
import Customers from './screens/Customers'
import Entry from './screens/Entry'
import Billing from './screens/Billing'
import Payments from './screens/Payments'
import Messages from './screens/Messages'
import Reports from './screens/Reports'
import Products from './screens/Products'
import Settings from './screens/Settings'
import Setup from './screens/Setup'
import More from './screens/More'

const NAV = [
  { to: 'dashboard', label: 'Home', icon: LayoutDashboard },
  { to: 'entry', label: 'Daily Entry', icon: ClipboardCheck },
  { to: 'customers', label: 'Customers', icon: Users },
  { to: 'billing', label: 'Billing', icon: Receipt },
  { to: 'payments', label: 'Payments', icon: Wallet, desktopOnly: true },
  { to: 'messages', label: 'Messages', icon: MessageSquare, desktopOnly: true },
  { to: 'reports', label: 'Reports', icon: BarChart3, desktopOnly: true },
  { to: 'products', label: 'Products & Rates', icon: Package, desktopOnly: true },
  { to: 'settings', label: 'Settings', icon: Cog, desktopOnly: true }
]

function applyTheme(t: AppSettings['theme']) {
  const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches)
  document.documentElement.dataset.theme = dark ? 'dark' : 'light'
  document.querySelector('meta[name=theme-color]')?.setAttribute('content', dark ? '#0a1420' : '#1f6feb')
}

function goBack() {
  const page = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/')[0]
  if (page === 'dashboard') return
  if (history.length > 1) history.back()
  else location.hash = '#/dashboard'
}

export default function App() {
  const [ready, setReady] = useState(false)
  const [fail, setFail] = useState<string | null>(null)
  const settings = useLiveQuery(() => getSettings(), [], undefined)
  const route = useRoute()
  const online = useOnline()

  useEffect(() => { ensureSeed().then(() => setReady(true)).catch(e => { console.error(e); setFail('The on-phone database could not be opened. Close other copies of the app and reload. If this continues, your browser may be blocking storage (private mode).') }) }, [])
  useEffect(() => { if (settings) { applyTheme(settings.theme); setCurrency(settings.currency) } }, [settings])
  useEffect(() => {
    const m = matchMedia('(prefers-color-scheme: dark)')
    const h = () => settings?.theme === 'system' && applyTheme('system')
    m.addEventListener('change', h); return () => m.removeEventListener('change', h)
  }, [settings?.theme])

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return
    let remove: (() => void) | undefined
    import('@capacitor/app').then(({ App: CapApp }) => {
      CapApp.addListener('backButton', () => {
        const page = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/')[0]
        if (page === 'dashboard') CapApp.exitApp()
        else goBack()
      }).then(h => { remove = () => h.remove() })
    }).catch(() => {})
    return () => remove?.()
  }, [])

  if (fail) return <div className="setup"><div className="notice bad">{fail}</div></div>
  if (!ready || !settings) return <Loading />
  if (!settings.setupDone) return <><Setup /><ToastHost /></>

  const page = route[0]
  const screen = (() => {
    switch (page) {
      case 'customers': return <Customers route={route} />
      case 'entry': return <Entry />
      case 'billing': return <Billing route={route} />
      case 'payments': return <Payments preselect={Number(route[1]) || undefined} key={route[1]} />
      case 'messages': return <Messages />
      case 'reports': return <Reports />
      case 'products': return <Products />
      case 'settings': return <Settings />
      case 'more': return <More />
      default: return <Dashboard />
    }
  })()
  const mobileNav = [NAV[0], NAV[1], NAV[2], NAV[3], { to: 'more', label: 'More', icon: MoreHorizontal }]
  const inMore = ['payments', 'messages', 'reports', 'products', 'settings', 'more'].includes(page)

  return (
    <div className="shell">
      <nav className="side" aria-label="Main">
        <div className="brand"><img src="icon.svg" alt="" />Milk Delivery Manager</div>
        {NAV.map(n => <a key={n.to} href={`#/${n.to}`} className={page === n.to ? 'on' : ''}><n.icon size={20} />{n.label}</a>)}
      </nav>
      <main className="main">
        {!online && <div className="offline">You are offline. Everything still works; your data is stored on this phone.</div>}
        {page !== 'dashboard' && route.length === 1 && <button className="back" style={{ background: 'none', border: 0, padding: 0 }} onClick={goBack}><ChevronLeft size={20} />Back</button>}
        {screen}
      </main>
      <nav className="bottom" aria-label="Main">
        {mobileNav.map(n => <a key={n.to} href={`#/${n.to}`} className={(n.to === 'more' ? inMore : page === n.to) ? 'on' : ''}><n.icon />{n.label}</a>)}
      </nav>
      <ToastHost /><ConfirmHost />
    </div>
  )
}
export { db }
