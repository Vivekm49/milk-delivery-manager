import { useEffect, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Capacitor } from '@capacitor/core'
import { RefreshCw, House, Users, ClipboardCheck, CalendarDays, Receipt, Wallet, Clock, MessageSquare, BarChart3, Package, Settings as Cog, Ellipsis, Milk } from 'lucide-react'
import { db, ensureSeed, getSettings, type AppSettings } from './lib/db'
import { ConfirmHost, ToastHost, useRoute, setCurrency, Loading, useOnline, toast } from './lib/ui'
import { usePullToRefresh, PullIndicator } from './components/PullToRefresh'
import Dashboard from './screens/Dashboard'
import Customers from './screens/Customers'
import Entry from './screens/Entry'
import Billing from './screens/Billing'
import Payments from './screens/Payments'
import Messages from './screens/Messages'
import Reports from './screens/Reports'
import Products from './screens/Products'
import Settings from './screens/Settings'
import Setup from './screens/Setup'
import Monthly from './screens/Monthly'
import PaymentPending from './screens/PaymentPending'
import CalendarScreen from './screens/CalendarScreen'
import Header from './components/Header'
import { AppCtx, headerMeta } from './lib/appctx'
import { currentMonth } from './lib/dates'
import More from './screens/More'

const NAV = [
  { to: 'dashboard', label: 'Home', icon: House },
  { to: 'customers', label: 'Customers', icon: Users },
  { to: 'entry', label: 'Entry', icon: ClipboardCheck },
  { to: 'monthly', label: 'Monthly', icon: CalendarDays },
  { to: 'billing', label: 'Bill', icon: Receipt }
]
const MORE_PAGES = [
  { to: 'payments', label: 'Payments', icon: Wallet },
  { to: 'pending', label: 'Payment Pending', icon: Clock },
  { to: 'messages', label: 'Messages', icon: MessageSquare },
  { to: 'reports', label: 'Reports', icon: BarChart3 },
  { to: 'calendar', label: 'Calendar', icon: CalendarDays },
  { to: 'products', label: 'Product Rates', icon: Package },
  { to: 'settings', label: 'Settings & Backup', icon: Cog }
]

function applyTheme(t: AppSettings['theme']) {
  const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches)
  document.documentElement.dataset.theme = dark ? 'dark' : 'light'
  document.querySelector('meta[name=theme-color]')?.setAttribute('content', dark ? '#0a1420' : '#1f6feb')
}

function goBack() {
  const page = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/')[0]
  if (page === 'dashboard') return
  if (history.length > 1) history.back()
  else location.hash = '#/dashboard'
}

export default function App() {
  const [ready, setReady] = useState(false)
  const [fail, setFail] = useState<string | null>(null)
  const settings = useLiveQuery(() => getSettings(), [], undefined)
  const route = useRoute()
  const online = useOnline()
  const [rk, setRk] = useState(0)
  const [month, setMonth] = useState(currentMonth())
  const [search, setSearch] = useState('')
  const page0 = route[0]
  // Screens with typing forms or step-by-step flows are not refreshed by pulling, so nothing typed is ever lost.
  const canRefresh = ['dashboard', 'entry', 'reports', 'more', 'monthly', 'pending', 'calendar'].includes(page0) || (page0 === 'customers' && !['new', 'edit'].includes(route[1]) && route[2] !== 'edit') || (page0 === 'billing' && route[1] !== 'new') || (page0 === '' )
  const refresh = async () => {
    try {
      if (!db.isOpen()) await db.open()
      await Promise.all([db.customers.count(), getSettings()]) // proves the data can be read before the screen is rebuilt
      setRk(k => k + 1)
    } catch (e) {
      console.error(e)
      toast('Could not refresh. Please try again.', 'err')
      throw e
    }
  }
  const ptr = usePullToRefresh(refresh, canRefresh && ready && !!settings?.setupDone)

  useEffect(() => { setSearch('') }, [page0])
  useEffect(() => { ensureSeed().then(() => setReady(true)).catch(e => { console.error(e); setFail('The on-phone database could not be opened. Close other copies of the app and reload. If this continues, your browser may be blocking storage (private mode).') }) }, [])
  useEffect(() => { if (settings) { applyTheme(settings.theme); setCurrency(settings.currency) } }, [settings])
  useEffect(() => {
    const m = matchMedia('(prefers-color-scheme: dark)')
    const h = () => settings?.theme === 'system' && applyTheme('system')
    m.addEventListener('change', h); return () => m.removeEventListener('change', h)
  }, [settings?.theme])

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return
    let remove: (() => void) | undefined
    import('@capacitor/app').then(({ App: CapApp }) => {
      CapApp.addListener('backButton', () => {
        const page = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('/')[0]
        if (page === 'dashboard') CapApp.exitApp()
        else goBack()
      }).then(h => { remove = () => h.remove() })
    }).catch(() => {})
    return () => remove?.()
  }, [])

  if (fail) return <div className="setup"><div className="notice bad">{fail}</div></div>
  if (!ready || !settings) return <Loading />
  if (!settings.setupDone) return <><Setup /><ToastHost /></>

  const page = route[0]
  const screen = (() => {
    switch (page) {
      case 'customers': return <Customers route={route} />
      case 'entry': return <Entry />
      case 'billing': return <Billing route={route} />
      case 'payments': return <Payments preselect={Number(route[1]) || undefined} key={route[1]} />
      case 'messages': return <Messages />
      case 'reports': return <Reports />
      case 'products': return <Products />
      case 'settings': return <Settings />
      case 'more': return <More />
      case 'monthly': return <Monthly />
      case 'pending': return <PaymentPending />
      case 'calendar': return <CalendarScreen />
      default: return <Dashboard />
    }
  })()
  const mobileNav = [...NAV, { to: 'more', label: 'More', icon: Ellipsis }]
  const inMore = [...MORE_PAGES.map(m => m.to), 'more'].includes(page)
  const meta = headerMeta(route)
  const side = [...NAV.slice(0, 3).map(n => (n.to === 'entry' ? { ...n, label: 'Daily Entry' } : n)), ...NAV.slice(3), ...MORE_PAGES]

  return (
    <AppCtx.Provider value={{ month, setMonth, search, setSearch }}>
      <div className="shell">
        <nav className="side" aria-label="Main">
          <div className="brand"><div className="logo"><Milk size={20} /></div>Milk Delivery Manager</div>
          {side.map(n => <a key={n.to} href={`#/${n.to}`} className={page === n.to ? 'on' : ''}><n.icon size={20} />{n.label}</a>)}
          {canRefresh && <button className="side-refresh" onClick={ptr.run} disabled={ptr.busy} aria-label="Refresh data"><RefreshCw size={20} className={ptr.busy ? 'spinning' : ''} />Refresh</button>}
        </nav>
        <PullIndicator pull={ptr.pull} busy={ptr.busy} />
        <div className="col">
          <Header shop={settings.businessName} month={meta.month} search={meta.search} />
          <main className="main">
            {!online && <div className="offline">You are offline. Everything still works; your data is stored on this phone.</div>}
            <div key={rk}>{screen}</div>
          </main>
        </div>
        <nav className="bottom" aria-label="Main">
          {mobileNav.map(n => <a key={n.to} href={`#/${n.to}`} className={(n.to === 'more' ? inMore : page === n.to) ? 'on' : ''}><span className="ni"><n.icon /></span>{n.label}</a>)}
        </nav>
        <ToastHost /><ConfirmHost />
      </div>
    </AppCtx.Provider>
  )
}
export { db }
