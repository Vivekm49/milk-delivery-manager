import { ChevronLeft, ChevronRight, Milk, Search, X } from 'lucide-react'
import { addMonths, currentMonth, monthLabel } from '../lib/dates'
import { useApp } from '../lib/appctx'

const short = (m: string) => { const [y, mo] = m.split('-'); return `${monthLabel(m).slice(0, 3)} ${y}` }

export default function Header({ shop, month, search }: { shop: string; month: boolean; search: string | null }) {
  const app = useApp()
  const now = currentMonth()
  return (
    <header className="hdr">
      <div className="hdr-in">
        <div className="hdr-top">
          <div className="logo" aria-hidden><Milk size={24} /></div>
          <div className="hdr-title"><h1>{shop || 'Milk Delivery Manager'}</h1><div className="tag">Milk Delivery Manager</div></div>
          {month && (
            <div className="monthpill" role="group" aria-label="Month">
              <button aria-label="Previous month" onClick={() => app.setMonth(addMonths(app.month, -1))}><ChevronLeft size={20} /></button>
              <b>{short(app.month)}</b>
              <button aria-label="Next month" disabled={app.month >= now} onClick={() => app.setMonth(addMonths(app.month, 1))}><ChevronRight size={20} /></button>
            </div>
          )}
        </div>
        {search !== null && (
          <div className="hdr-search">
            <Search aria-hidden />
            <input type="search" value={app.search} onChange={e => app.setSearch(e.target.value)} placeholder={search} aria-label="Search customers" />
            {app.search && <button className="clr" aria-label="Clear search" onClick={() => app.setSearch('')}><X size={18} /></button>}
          </div>
        )}
      </div>
    </header>
  )
}
