import { useEffect, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { MessageCircle, Smartphone, Copy } from 'lucide-react'
import { db } from '../lib/db'
import { buildContext, renderTemplate, messageLink, logOpened, hasPhone, type Channel } from '../lib/messages'
import { currentMonth } from '../lib/dates'
import { toast } from '../lib/ui'
import type { Customer } from '../lib/types'

export default function QuickMessage({ customer }: { customer: Customer }) {
  const templates = useLiveQuery(() => db.templates.toArray(), [], [])
  const [tid, setTid] = useState<number>(0)
  const [text, setText] = useState('')
  useEffect(() => { if (!tid && templates.length) setTid(templates[0].id!) }, [templates, tid])
  useEffect(() => {
    const t = templates.find(x => x.id === tid)
    if (!t) return
    buildContext(customer, currentMonth()).then(ctx => setText(renderTemplate(t.body, ctx))).catch(() => setText(t.body))
  }, [tid, templates, customer])
  const open = (ch: Channel) => { logOpened(customer.id!, ch, text).catch(() => {}) }
  const copy = async () => { try { await navigator.clipboard.writeText(text); toast('Message copied', 'ok') } catch { toast('Could not copy. Select the text and copy it manually.', 'err') } }
  return (
    <div className="stack">
      <select className="in" value={tid} onChange={e => setTid(Number(e.target.value))} aria-label="Message template">{templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
      <textarea className="in" value={text} onChange={e => setText(e.target.value)} aria-label="Message text" />
      {!hasPhone(customer) && !hasPhone(customer, 'whatsapp') && <div className="notice warn">This customer has no phone number, so WhatsApp and SMS are turned off. Add a number in Edit.</div>}
      <div className="row wrap">
        {hasPhone(customer, 'whatsapp') ? <a className="btn green grow" href={messageLink('whatsapp', customer, text)} target="_blank" rel="noopener noreferrer" onClick={() => open('whatsapp')}><MessageCircle size={20} />WhatsApp</a> : <button className="btn grow" disabled><MessageCircle size={20} />WhatsApp</button>}
        {hasPhone(customer) ? <a className="btn primary grow" href={messageLink('sms', customer, text)} onClick={() => open('sms')}><Smartphone size={20} />SMS</a> : <button className="btn grow" disabled><Smartphone size={20} />SMS</button>}
        <button className="btn" onClick={copy} aria-label="Copy message"><Copy size={20} /></button>
      </div>
      <p className="sub">This opens WhatsApp or SMS with the message filled in. You press send there. If nothing opens, the app may not be installed; use Copy instead.</p>
    </div>
  )
}
