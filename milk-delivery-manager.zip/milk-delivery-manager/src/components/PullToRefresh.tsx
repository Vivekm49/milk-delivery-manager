import { useEffect, useRef, useState } from 'react'
import { RefreshCw } from 'lucide-react'

const THRESHOLD = 64
const MAX_PULL = 96
// Touches that start on these should keep their normal behaviour (typing, picking, sideways table scrolling, menus, dialogs).
const IGNORE = 'input, textarea, select, [contenteditable="true"], .table-wrap, .scrim, .menu, .no-ptr, .chips, .seg'

/**
 * Pull-to-refresh for touch screens. Only starts when the page is scrolled to the very top and the gesture
 * is mostly vertical, so normal scrolling, form fields and sideways swipes are left alone.
 * A second pull is ignored while a refresh is running (and for a short moment after).
 */
export function usePullToRefresh(onRefresh: () => Promise<void>, enabled: boolean) {
  const [pull, setPull] = useState(0)
  const [busy, setBusy] = useState(false)
  const st = useRef({ y: 0, x: 0, active: false, pull: 0, lock: false })
  const cb = useRef(onRefresh)
  cb.current = onRefresh

  useEffect(() => {
    if (!enabled) { setPull(0); return }
    const s = st.current
    const onStart = (e: TouchEvent) => {
      s.active = false; s.pull = 0
      if (s.lock || e.touches.length !== 1) return
      if ((window.scrollY || document.documentElement.scrollTop) > 0) return
      if ((e.target as Element | null)?.closest?.(IGNORE)) return
      s.y = e.touches[0].clientY; s.x = e.touches[0].clientX; s.active = true
    }
    const onMove = (e: TouchEvent) => {
      if (!s.active) return
      const dy = e.touches[0].clientY - s.y
      const dx = e.touches[0].clientX - s.x
      if (dy <= 0 || Math.abs(dx) > Math.abs(dy)) { if (s.pull === 0) s.active = false; return }
      if ((window.scrollY || document.documentElement.scrollTop) > 0) { s.active = false; setPull(0); return }
      s.pull = Math.min(MAX_PULL, dy * 0.5)
      if (e.cancelable) e.preventDefault() // stop the browser's own overscroll while we are showing ours
      setPull(s.pull)
    }
    const onEnd = async () => {
      if (!s.active) return
      s.active = false
      const done = s.pull >= THRESHOLD
      s.pull = 0
      if (!done || s.lock) { setPull(0); return }
      s.lock = true; setBusy(true); setPull(THRESHOLD)
      try { await cb.current() } catch { /* the caller shows the error message */ }
      finally { setBusy(false); setPull(0); setTimeout(() => { s.lock = false }, 600) }
    }
    window.addEventListener('touchstart', onStart, { passive: true })
    window.addEventListener('touchmove', onMove, { passive: false })
    window.addEventListener('touchend', onEnd)
    window.addEventListener('touchcancel', onEnd)
    return () => {
      window.removeEventListener('touchstart', onStart); window.removeEventListener('touchmove', onMove)
      window.removeEventListener('touchend', onEnd); window.removeEventListener('touchcancel', onEnd)
    }
  }, [enabled])

  /** Used by the desktop refresh button too, with the same duplicate protection. */
  const run = async () => {
    const s = st.current
    if (s.lock) return
    s.lock = true; setBusy(true)
    try { await cb.current() } catch { /* shown by caller */ } finally { setBusy(false); setTimeout(() => { s.lock = false }, 600) }
  }
  return { pull, busy, run }
}

export function PullIndicator({ pull, busy }: { pull: number; busy: boolean }) {
  if (!pull && !busy) return null
  const ready = pull >= THRESHOLD
  return (
    <div className="ptr" style={{ transform: `translate(-50%, ${Math.max(0, pull - 40)}px)`, opacity: Math.min(1, pull / 40 + (busy ? 1 : 0)) }} role="status" aria-live="polite" aria-label={busy ? 'Refreshing' : ready ? 'Release to refresh' : 'Pull to refresh'}>
      <RefreshCw size={20} className={busy ? 'spinning' : ''} style={busy ? undefined : { transform: `rotate(${pull * 3}deg)` }} />
    </div>
  )
}
