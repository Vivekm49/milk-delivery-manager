import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Check, Clock, CircleAlert, MoreVertical } from 'lucide-react'
import type { PayStatus } from '../lib/owed'
import { initials } from '../lib/ui'

/** Paid / Part paid / Unpaid tag, used on every screen so the wording and colours never differ. */
export function PayTag({ status }: { status: PayStatus }) {
  const kind = status === 'Paid' ? 'green' : status === 'Part paid' ? 'amber' : 'red'
  const Icon = status === 'Paid' ? Check : status === 'Part paid' ? Clock : CircleAlert
  return <span className={`badge ${kind}`}><Icon size={13} aria-hidden />{status}</span>
}

export function Avatar({ name, size = 40 }: { name: string; size?: number }) {
  return <div className="av" style={{ width: size, height: size, fontSize: size * 0.42, borderRadius: size * 0.3 }} aria-hidden>{initials(name).slice(0, 1)}</div>
}

export interface MenuItem { label: string; icon: ReactNode; onClick: () => void; disabled?: boolean; danger?: boolean }
export function Kebab({ name, items }: { name: string; items: MenuItem[] }) {
  const [open, setOpen] = useState(false)
  const [up, setUp] = useState(false)
  const [maxH, setMaxH] = useState(420)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const out = (e: Event) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('mousedown', out); document.addEventListener('touchstart', out); document.addEventListener('keydown', esc)
    return () => { document.removeEventListener('mousedown', out); document.removeEventListener('touchstart', out); document.removeEventListener('keydown', esc) }
  }, [open])
  const toggle = () => {
    if (!open && ref.current) {
      // Open towards the side that has more room, and never taller than that room (the bottom bar covers the last 70px).
      const r = ref.current.getBoundingClientRect()
      const top = document.querySelector('.hdr')?.getBoundingClientRect().bottom ?? 0
      const below = window.innerHeight - 76 - r.bottom, above = r.top - top - 8
      const need = items.length * 48 + 16
      const goUp = below < need && above > below
      setUp(goUp); setMaxH(Math.max(140, Math.floor(goUp ? above : below)))
    }
    setOpen(!open)
  }
  return (
    <div className="menu-wrap" ref={ref}>
      <button className="kebab" aria-label={`More actions for ${name}`} aria-haspopup="menu" aria-expanded={open} onClick={toggle}><MoreVertical size={20} /></button>
      {open && <div className={`menu ${up ? 'up' : ''}`} role="menu" style={{ maxHeight: maxH, overflowY: 'auto' }}>{items.map(it => <button key={it.label} role="menuitem" className={it.danger ? 'danger' : ''} disabled={it.disabled} onClick={() => { setOpen(false); it.onClick() }}>{it.icon}{it.label}</button>)}</div>}
    </div>
  )
}
