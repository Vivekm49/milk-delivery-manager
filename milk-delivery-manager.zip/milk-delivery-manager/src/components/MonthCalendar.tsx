import { daysBetween, monthEnd, monthStart, todayISO } from '../lib/dates'
import type { DayStatus } from '../lib/absent'

/** Delivered = green, Absent = red, Paused = amber, nothing entered = grey. Days after today stay grey. */
export default function MonthCalendar({ month, days }: { month: string; days: Map<string, DayStatus> }) {
  const [y, m] = month.split('-').map(Number)
  const lead = (new Date(y, m - 1, 1).getDay() + 6) % 7 // week starts on Monday
  const list = daysBetween(monthStart(month), monthEnd(month))
  const today = todayISO()
  return (
    <div>
      <div className="cal" role="grid" aria-label="Delivery calendar">
        {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => <div className="dn" key={i}>{d}</div>)}
        {Array.from({ length: lead }, (_, i) => <div className="cd e" key={`e${i}`} />)}
        {list.map(d => {
          const st = d > today ? 'none' : days.get(d) ?? 'none'
          const cls = st === 'delivered' ? 'd' : st === 'absent' ? 'a' : st === 'paused' ? 'p' : ''
          const label = st === 'delivered' ? 'delivered' : st === 'absent' ? 'absent' : st === 'paused' ? 'paused' : 'no entry'
          return <div key={d} className={`cd ${cls}`} role="gridcell" aria-label={`${Number(d.slice(8))}: ${label}`}>{Number(d.slice(8))}</div>
        })}
      </div>
      <div className="legend"><span><i style={{ background: 'var(--green-soft)' }} />Delivered</span><span><i style={{ background: 'var(--red-soft)' }} />Absent</span><span><i style={{ background: 'var(--amber-soft)' }} />Paused</span><span><i style={{ background: 'var(--line)' }} />No entry</span></div>
    </div>
  )
}
