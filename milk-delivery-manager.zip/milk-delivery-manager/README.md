# Milk Delivery Manager

Local-first milk delivery app (React + Dexie/IndexedDB + Capacitor). All data stays on the phone.

- `npm ci && npm run dev` - run in browser
- `npm test` - billing/money/backup tests + UI smoke test
- `npm run build` - production web build (PWA)
- APK is built automatically by `.github/workflows/build-apk.yml` on GitHub.
